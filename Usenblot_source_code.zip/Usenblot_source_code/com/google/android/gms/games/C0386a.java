package com.google.android.gms.games;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.util.TimeUtils;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value.Escaping;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.location.LocationStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

/* renamed from: com.google.android.gms.games.a */
public class C0386a implements Creator<GameEntity> {
    static void m830a(GameEntity gameEntity, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m491a(parcel, 1, gameEntity.getApplicationId(), false);
        C0265b.m491a(parcel, 2, gameEntity.getDisplayName(), false);
        C0265b.m491a(parcel, 3, gameEntity.getPrimaryCategory(), false);
        C0265b.m491a(parcel, 4, gameEntity.getSecondaryCategory(), false);
        C0265b.m491a(parcel, 5, gameEntity.getDescription(), false);
        C0265b.m491a(parcel, 6, gameEntity.getDeveloperName(), false);
        C0265b.m489a(parcel, 7, gameEntity.getIconImageUri(), i, false);
        C0265b.m489a(parcel, 8, gameEntity.getHiResImageUri(), i, false);
        C0265b.m489a(parcel, 9, gameEntity.getFeaturedImageUri(), i, false);
        C0265b.m494a(parcel, 10, gameEntity.isPlayEnabledGame());
        C0265b.m494a(parcel, 11, gameEntity.isInstanceInstalled());
        C0265b.m491a(parcel, 12, gameEntity.getInstancePackageName(), false);
        C0265b.m501c(parcel, 13, gameEntity.getGameplayAclStatus());
        C0265b.m501c(parcel, 14, gameEntity.getAchievementTotalCount());
        C0265b.m501c(parcel, 15, gameEntity.getLeaderboardCount());
        C0265b.m494a(parcel, 17, gameEntity.isTurnBasedMultiplayerEnabled());
        C0265b.m494a(parcel, 16, gameEntity.isRealTimeMultiplayerEnabled());
        C0265b.m501c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, gameEntity.getVersionCode());
        C0265b.m491a(parcel, 19, gameEntity.getHiResImageUrl(), false);
        C0265b.m491a(parcel, 18, gameEntity.getIconImageUrl(), false);
        C0265b.m494a(parcel, 21, gameEntity.isMuted());
        C0265b.m491a(parcel, 20, gameEntity.getFeaturedImageUrl(), false);
        C0265b.m481D(parcel, p);
    }

    public GameEntity[] aP(int i) {
        return new GameEntity[i];
    }

    public GameEntity aj(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        Uri uri = null;
        Uri uri2 = null;
        Uri uri3 = null;
        boolean z = false;
        boolean z2 = false;
        String str7 = null;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        boolean z3 = false;
        boolean z4 = false;
        String str8 = null;
        String str9 = null;
        String str10 = null;
        boolean z5 = false;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    str3 = C0264a.m463m(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    str4 = C0264a.m463m(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    str5 = C0264a.m463m(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    str6 = C0264a.m463m(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    uri = (Uri) C0264a.m446a(parcel, n, Uri.CREATOR);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    uri2 = (Uri) C0264a.m446a(parcel, n, Uri.CREATOR);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    uri3 = (Uri) C0264a.m446a(parcel, n, Uri.CREATOR);
                    break;
                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                    z = C0264a.m453c(parcel, n);
                    break;
                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                    z2 = C0264a.m453c(parcel, n);
                    break;
                case CommonStatusCodes.DATE_INVALID /*12*/:
                    str7 = C0264a.m463m(parcel, n);
                    break;
                case CommonStatusCodes.ERROR /*13*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_INTERRUPTED /*14*/:
                    i3 = C0264a.m457g(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_TIMEOUT /*15*/:
                    i4 = C0264a.m457g(parcel, n);
                    break;
                case Escaping.CONVERT_JS_VALUE_TO_EXPRESSION /*16*/:
                    z3 = C0264a.m453c(parcel, n);
                    break;
                case Escaping.TEXT /*17*/:
                    z4 = C0264a.m453c(parcel, n);
                    break;
                case 18:
                    str8 = C0264a.m463m(parcel, n);
                    break;
                case TimeUtils.HUNDRED_DAY_FIELD_LEN /*19*/:
                    str9 = C0264a.m463m(parcel, n);
                    break;
                case 20:
                    str10 = C0264a.m463m(parcel, n);
                    break;
                case 21:
                    z5 = C0264a.m453c(parcel, n);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new GameEntity(i, str, str2, str3, str4, str5, str6, uri, uri2, uri3, z, z2, str7, i2, i3, i4, z3, z4, str8, str9, str10, z5);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aj(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aP(x0);
    }
}
