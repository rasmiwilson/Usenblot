package com.google.android.gms.games.multiplayer.realtime;

import com.google.android.gms.common.data.C0253d;
import com.google.android.gms.common.data.DataHolder;

/* renamed from: com.google.android.gms.games.multiplayer.realtime.a */
public final class C0415a extends C0253d<Room> {
    public C0415a(DataHolder dataHolder) {
        super(dataHolder);
    }

    protected /* synthetic */ Object m881c(int i, int i2) {
        return m882d(i, i2);
    }

    protected Room m882d(int i, int i2) {
        return new C0416c(this.zU, i, i2);
    }

    protected String getPrimaryDataMarkerColumn() {
        return "external_match_id";
    }
}
