package com.google.android.gms.games.multiplayer;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.PlayerEntity;
import com.google.android.gms.location.LocationStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

/* renamed from: com.google.android.gms.games.multiplayer.c */
public class C0407c implements Creator<ParticipantEntity> {
    static void m866a(ParticipantEntity participantEntity, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m491a(parcel, 1, participantEntity.getParticipantId(), false);
        C0265b.m491a(parcel, 2, participantEntity.getDisplayName(), false);
        C0265b.m489a(parcel, 3, participantEntity.getIconImageUri(), i, false);
        C0265b.m489a(parcel, 4, participantEntity.getHiResImageUri(), i, false);
        C0265b.m501c(parcel, 5, participantEntity.getStatus());
        C0265b.m491a(parcel, 6, participantEntity.ge(), false);
        C0265b.m494a(parcel, 7, participantEntity.isConnectedToRoom());
        C0265b.m489a(parcel, 8, participantEntity.getPlayer(), i, false);
        C0265b.m501c(parcel, 9, participantEntity.getCapabilities());
        C0265b.m489a(parcel, 10, participantEntity.getResult(), i, false);
        C0265b.m491a(parcel, 11, participantEntity.getIconImageUrl(), false);
        C0265b.m491a(parcel, 12, participantEntity.getHiResImageUrl(), false);
        C0265b.m501c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, participantEntity.getVersionCode());
        C0265b.m481D(parcel, p);
    }

    public ParticipantEntity ao(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        String str = null;
        String str2 = null;
        Uri uri = null;
        Uri uri2 = null;
        int i2 = 0;
        String str3 = null;
        boolean z = false;
        PlayerEntity playerEntity = null;
        int i3 = 0;
        ParticipantResult participantResult = null;
        String str4 = null;
        String str5 = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    uri = (Uri) C0264a.m446a(parcel, n, Uri.CREATOR);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    uri2 = (Uri) C0264a.m446a(parcel, n, Uri.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    str3 = C0264a.m463m(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    z = C0264a.m453c(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    playerEntity = (PlayerEntity) C0264a.m446a(parcel, n, PlayerEntity.CREATOR);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    i3 = C0264a.m457g(parcel, n);
                    break;
                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                    participantResult = (ParticipantResult) C0264a.m446a(parcel, n, ParticipantResult.CREATOR);
                    break;
                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                    str4 = C0264a.m463m(parcel, n);
                    break;
                case CommonStatusCodes.DATE_INVALID /*12*/:
                    str5 = C0264a.m463m(parcel, n);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new ParticipantEntity(i, str, str2, uri, uri2, i2, str3, z, playerEntity, i3, participantResult, str4, str5);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public ParticipantEntity[] bb(int i) {
        return new ParticipantEntity[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return ao(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bb(x0);
    }
}
