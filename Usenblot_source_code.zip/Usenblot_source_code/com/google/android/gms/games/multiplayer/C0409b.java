package com.google.android.gms.games.multiplayer;

import android.os.Parcel;
import com.google.android.gms.common.data.C0200b;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.games.C0395b;
import com.google.android.gms.games.Game;
import com.google.android.gms.internal.er;
import java.util.ArrayList;

/* renamed from: com.google.android.gms.games.multiplayer.b */
public final class C0409b extends C0200b implements Invitation {
    private final Game IM;
    private final ArrayList<Participant> Ju;
    private final C0410d Jx;

    C0409b(DataHolder dataHolder, int i, int i2) {
        super(dataHolder, i);
        this.IM = new C0395b(dataHolder, i);
        this.Ju = new ArrayList(i2);
        String string = getString("external_inviter_id");
        Object obj = null;
        for (int i3 = 0; i3 < i2; i3++) {
            C0410d c0410d = new C0410d(this.zU, this.zW + i3);
            if (c0410d.getParticipantId().equals(string)) {
                obj = c0410d;
            }
            this.Ju.add(c0410d);
        }
        this.Jx = (C0410d) er.m1549b(obj, (Object) "Must have a valid inviter!");
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        return InvitationEntity.m863a(this, obj);
    }

    public Invitation freeze() {
        return new InvitationEntity(this);
    }

    public int getAvailableAutoMatchSlots() {
        return !getBoolean("has_automatch_criteria") ? 0 : getInteger("automatch_max_players");
    }

    public long getCreationTimestamp() {
        return Math.max(getLong("creation_timestamp"), getLong("last_modified_timestamp"));
    }

    public Game getGame() {
        return this.IM;
    }

    public String getInvitationId() {
        return getString("external_invitation_id");
    }

    public int getInvitationType() {
        return getInteger("type");
    }

    public Participant getInviter() {
        return this.Jx;
    }

    public ArrayList<Participant> getParticipants() {
        return this.Ju;
    }

    public int getVariant() {
        return getInteger("variant");
    }

    public int hashCode() {
        return InvitationEntity.m862a(this);
    }

    public String toString() {
        return InvitationEntity.m864b((Invitation) this);
    }

    public void writeToParcel(Parcel dest, int flags) {
        ((InvitationEntity) freeze()).writeToParcel(dest, flags);
    }
}
