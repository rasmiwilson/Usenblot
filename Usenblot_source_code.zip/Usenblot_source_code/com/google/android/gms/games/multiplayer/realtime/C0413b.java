package com.google.android.gms.games.multiplayer.realtime;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.multiplayer.ParticipantEntity;
import com.google.android.gms.location.LocationStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.ArrayList;

/* renamed from: com.google.android.gms.games.multiplayer.realtime.b */
public class C0413b implements Creator<RoomEntity> {
    static void m872a(RoomEntity roomEntity, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m491a(parcel, 1, roomEntity.getRoomId(), false);
        C0265b.m501c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, roomEntity.getVersionCode());
        C0265b.m491a(parcel, 2, roomEntity.getCreatorId(), false);
        C0265b.m485a(parcel, 3, roomEntity.getCreationTimestamp());
        C0265b.m501c(parcel, 4, roomEntity.getStatus());
        C0265b.m491a(parcel, 5, roomEntity.getDescription(), false);
        C0265b.m501c(parcel, 6, roomEntity.getVariant());
        C0265b.m486a(parcel, 7, roomEntity.getAutoMatchCriteria(), false);
        C0265b.m500b(parcel, 8, roomEntity.getParticipants(), false);
        C0265b.m501c(parcel, 9, roomEntity.getAutoMatchWaitEstimateSeconds());
        C0265b.m481D(parcel, p);
    }

    public RoomEntity aq(Parcel parcel) {
        int i = 0;
        ArrayList arrayList = null;
        int o = C0264a.m466o(parcel);
        long j = 0;
        Bundle bundle = null;
        int i2 = 0;
        String str = null;
        int i3 = 0;
        String str2 = null;
        String str3 = null;
        int i4 = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    str3 = C0264a.m463m(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    j = C0264a.m458h(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    i3 = C0264a.m457g(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    bundle = C0264a.m467o(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    arrayList = C0264a.m452c(parcel, n, ParticipantEntity.CREATOR);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i4 = C0264a.m457g(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new RoomEntity(i4, str3, str2, j, i3, str, i2, bundle, arrayList, i);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public RoomEntity[] bd(int i) {
        return new RoomEntity[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aq(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bd(x0);
    }
}
