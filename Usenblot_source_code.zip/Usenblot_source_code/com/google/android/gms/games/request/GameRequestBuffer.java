package com.google.android.gms.games.request;

import com.google.android.gms.common.data.C0253d;
import com.google.android.gms.common.data.DataHolder;

public final class GameRequestBuffer extends C0253d<GameRequest> {
    public GameRequestBuffer(DataHolder dataHolder) {
        super(dataHolder);
    }

    protected /* synthetic */ Object m893c(int i, int i2) {
        return getEntry(i, i2);
    }

    protected GameRequest getEntry(int rowIndex, int numChildren) {
        return new C0419a(this.zU, rowIndex, numChildren);
    }

    protected String getPrimaryDataMarkerColumn() {
        return "external_request_id";
    }
}
