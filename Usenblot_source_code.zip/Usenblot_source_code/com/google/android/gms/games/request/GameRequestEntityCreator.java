package com.google.android.gms.games.request;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GameEntity;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.PlayerEntity;
import com.google.android.gms.location.LocationStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.ArrayList;

public class GameRequestEntityCreator implements Creator<GameRequestEntity> {
    public static final int CONTENT_DESCRIPTION = 0;

    static void m898a(GameRequestEntity gameRequestEntity, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m489a(parcel, 1, gameRequestEntity.getGame(), i, false);
        C0265b.m501c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, gameRequestEntity.getVersionCode());
        C0265b.m489a(parcel, 2, gameRequestEntity.getSender(), i, false);
        C0265b.m495a(parcel, 3, gameRequestEntity.getData(), false);
        C0265b.m491a(parcel, 4, gameRequestEntity.getRequestId(), false);
        C0265b.m500b(parcel, 5, gameRequestEntity.fU(), false);
        C0265b.m501c(parcel, 7, gameRequestEntity.getType());
        C0265b.m485a(parcel, 9, gameRequestEntity.getCreationTimestamp());
        C0265b.m485a(parcel, 10, gameRequestEntity.getExpirationTimestamp());
        C0265b.m486a(parcel, 11, gameRequestEntity.gf(), false);
        C0265b.m481D(parcel, p);
    }

    public GameRequestEntity createFromParcel(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        GameEntity gameEntity = null;
        PlayerEntity playerEntity = null;
        byte[] bArr = null;
        String str = null;
        ArrayList arrayList = null;
        int i2 = 0;
        long j = 0;
        long j2 = 0;
        Bundle bundle = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    gameEntity = (GameEntity) C0264a.m446a(parcel, n, GameEntity.CREATOR);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    playerEntity = (PlayerEntity) C0264a.m446a(parcel, n, PlayerEntity.CREATOR);
                    break;
                case Error.BAD_CVC /*3*/:
                    bArr = C0264a.m468p(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    arrayList = C0264a.m452c(parcel, n, PlayerEntity.CREATOR);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    j = C0264a.m458h(parcel, n);
                    break;
                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                    j2 = C0264a.m458h(parcel, n);
                    break;
                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                    bundle = C0264a.m467o(parcel, n);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new GameRequestEntity(i, gameEntity, playerEntity, bArr, str, arrayList, i2, j, j2, bundle);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public GameRequestEntity[] newArray(int size) {
        return new GameRequestEntity[size];
    }
}
