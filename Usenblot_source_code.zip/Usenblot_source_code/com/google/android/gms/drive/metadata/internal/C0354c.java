package com.google.android.gms.drive.metadata.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.internal.fs;
import com.google.android.gms.internal.ft;
import com.google.android.gms.internal.fv;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.drive.metadata.internal.c */
public final class C0354c {
    private static Map<String, MetadataField<?>> Ej;

    static {
        Ej = new HashMap();
        C0354c.m766b(fs.El);
        C0354c.m766b(fs.TITLE);
        C0354c.m766b(fs.MIME_TYPE);
        C0354c.m766b(fs.STARRED);
        C0354c.m766b(fs.TRASHED);
        C0354c.m766b(fs.Em);
        C0354c.m766b(fs.IS_PINNED);
        C0354c.m766b(fs.En);
        C0354c.m766b(fs.Eo);
        C0354c.m766b(fs.PARENTS);
        C0354c.m766b(fs.Ep);
        C0354c.m766b(fs.Eq);
        C0354c.m766b(fs.Er);
        C0354c.m766b(fs.Es);
        C0354c.m766b(fs.Et);
        C0354c.m766b(fs.Eu);
        C0354c.m766b(fs.Ev);
        C0354c.m766b(fs.Ew);
        C0354c.m766b(fs.Ex);
        C0354c.m766b(fs.Ey);
        C0354c.m766b(fs.Ez);
        C0354c.m766b(fs.EA);
        C0354c.m766b(fs.EB);
        C0354c.m766b(fs.EC);
        C0354c.m766b(fs.ED);
        C0354c.m766b(ft.EG);
        C0354c.m766b(ft.EE);
        C0354c.m766b(ft.EF);
        C0354c.m766b(ft.EH);
        C0354c.m766b(ft.LAST_VIEWED_BY_ME);
        C0354c.m766b(fv.EJ);
        C0354c.m766b(fv.EK);
    }

    public static MetadataField<?> ar(String str) {
        return (MetadataField) Ej.get(str);
    }

    private static void m766b(MetadataField<?> metadataField) {
        if (Ej.containsKey(metadataField.getName())) {
            throw new IllegalArgumentException("Duplicate field name registered: " + metadataField.getName());
        }
        Ej.put(metadataField.getName(), metadataField);
    }

    public static Collection<MetadataField<?>> fg() {
        return Collections.unmodifiableCollection(Ej.values());
    }
}
