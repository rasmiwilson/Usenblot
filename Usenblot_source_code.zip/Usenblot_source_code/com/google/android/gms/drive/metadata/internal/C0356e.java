package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.MetadataField;

/* renamed from: com.google.android.gms.drive.metadata.internal.e */
public class C0356e extends MetadataField<Long> {
    public C0356e(String str, int i) {
        super(str, i);
    }

    protected void m773a(Bundle bundle, Long l) {
        bundle.putLong(getName(), l.longValue());
    }

    protected /* synthetic */ Object m775b(DataHolder dataHolder, int i, int i2) {
        return m777g(dataHolder, i, i2);
    }

    protected /* synthetic */ Object m776e(Bundle bundle) {
        return m778i(bundle);
    }

    protected Long m777g(DataHolder dataHolder, int i, int i2) {
        return Long.valueOf(dataHolder.getLong(getName(), i, i2));
    }

    protected Long m778i(Bundle bundle) {
        return Long.valueOf(bundle.getLong(getName()));
    }
}
