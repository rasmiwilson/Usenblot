package com.google.android.gms.drive.metadata.internal;

import android.os.Bundle;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.drive.metadata.MetadataField;

/* renamed from: com.google.android.gms.drive.metadata.internal.j */
public final class C0361j extends MetadataField<String> {
    public C0361j(String str, int i) {
        super(str, i);
    }

    protected void m795a(Bundle bundle, String str) {
        bundle.putString(getName(), str);
    }

    protected /* synthetic */ Object m796b(DataHolder dataHolder, int i, int i2) {
        return m798h(dataHolder, i, i2);
    }

    protected /* synthetic */ Object m797e(Bundle bundle) {
        return m799l(bundle);
    }

    protected String m798h(DataHolder dataHolder, int i, int i2) {
        return dataHolder.getString(getName(), i, i2);
    }

    protected String m799l(Bundle bundle) {
        return bundle.getString(getName());
    }
}
