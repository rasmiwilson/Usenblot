package com.google.android.gms.drive;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

/* renamed from: com.google.android.gms.drive.d */
public class C0272d implements Creator<DriveId> {
    static void m512a(DriveId driveId, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, driveId.wj);
        C0265b.m491a(parcel, 2, driveId.Dc, false);
        C0265b.m485a(parcel, 3, driveId.Dd);
        C0265b.m485a(parcel, 4, driveId.De);
        C0265b.m481D(parcel, p);
    }

    public DriveId[] ae(int i) {
        return new DriveId[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m513z(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ae(x0);
    }

    public DriveId m513z(Parcel parcel) {
        long j = 0;
        int o = C0264a.m466o(parcel);
        int i = 0;
        String str = null;
        long j2 = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    j2 = C0264a.m458h(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    j = C0264a.m458h(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new DriveId(i, str, j2, j);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }
}
