package com.google.android.gms.drive;

import android.content.IntentSender;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.drive.internal.C0310n;
import com.google.android.gms.drive.internal.OpenFileIntentSenderRequest;
import com.google.android.gms.internal.er;

public class OpenFileActivityBuilder {
    public static final String EXTRA_RESPONSE_DRIVE_ID = "response_drive_id";
    private String CX;
    private DriveId CY;
    private String[] Dk;

    public IntentSender build(GoogleApiClient apiClient) {
        er.m1549b(this.Dk, (Object) "setMimeType(String[]) must be called on this builder before calling build()");
        er.m1547a(apiClient.isConnected(), "Client must be connected");
        try {
            return ((C0310n) apiClient.m364a(Drive.va)).eT().m681a(new OpenFileIntentSenderRequest(this.CX, this.Dk, this.CY));
        } catch (Throwable e) {
            throw new RuntimeException("Unable to connect Drive Play Service", e);
        }
    }

    public OpenFileActivityBuilder setActivityStartFolder(DriveId folder) {
        this.CY = (DriveId) er.m1551f(folder);
        return this;
    }

    public OpenFileActivityBuilder setActivityTitle(String title) {
        this.CX = (String) er.m1551f(title);
        return this;
    }

    public OpenFileActivityBuilder setMimeType(String[] mimeTypes) {
        boolean z = mimeTypes != null && mimeTypes.length > 0;
        er.m1550b(z, (Object) "mimeTypes may not be null and must contain at least one value");
        this.Dk = mimeTypes;
        return this;
    }
}
