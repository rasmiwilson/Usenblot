package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi.MetadataBufferResult;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.DriveResource;
import com.google.android.gms.drive.DriveResource.MetadataResult;
import com.google.android.gms.drive.Metadata;
import com.google.android.gms.drive.MetadataBuffer;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.events.ChangeEvent;
import com.google.android.gms.drive.events.DriveEvent.Listener;
import com.google.android.gms.drive.internal.C0307l.C0303e;

/* renamed from: com.google.android.gms.drive.internal.r */
public class C0318r implements DriveResource {
    protected final DriveId CS;

    /* renamed from: com.google.android.gms.drive.internal.r.a */
    private abstract class C0329a extends C0289m<MetadataResult> {
        final /* synthetic */ C0318r DP;

        private C0329a(C0318r c0318r) {
            this.DP = c0318r;
        }

        public /* synthetic */ Result m658d(Status status) {
            return m659r(status);
        }

        public MetadataResult m659r(Status status) {
            return new C0337e(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.1 */
    class C03301 extends C0329a {
        final /* synthetic */ C0318r DP;

        C03301(C0318r c0318r) {
            this.DP = c0318r;
            super(null);
        }

        protected void m661a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m690a(new GetMetadataRequest(this.DP.CS), new C0336d(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.c */
    private abstract class C0331c extends C0289m<MetadataBufferResult> {
        final /* synthetic */ C0318r DP;

        private C0331c(C0318r c0318r) {
            this.DP = c0318r;
        }

        public /* synthetic */ Result m662d(Status status) {
            return m663o(status);
        }

        public MetadataBufferResult m663o(Status status) {
            return new C0303e(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.2 */
    class C03322 extends C0331c {
        final /* synthetic */ C0318r DP;

        C03322(C0318r c0318r) {
            this.DP = c0318r;
            super(null);
        }

        protected void m665a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m691a(new ListParentsRequest(this.DP.CS), new C0335b(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.f */
    private abstract class C0333f extends C0289m<MetadataResult> {
        final /* synthetic */ C0318r DP;

        private C0333f(C0318r c0318r) {
            this.DP = c0318r;
        }

        public /* synthetic */ Result m666d(Status status) {
            return m667r(status);
        }

        public MetadataResult m667r(Status status) {
            return new C0337e(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.3 */
    class C03343 extends C0333f {
        final /* synthetic */ MetadataChangeSet DK;
        final /* synthetic */ C0318r DP;

        C03343(C0318r c0318r, MetadataChangeSet metadataChangeSet) {
            this.DP = c0318r;
            this.DK = metadataChangeSet;
            super(null);
        }

        protected void m669a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m696a(new UpdateMetadataRequest(this.DP.CS, this.DK.eS()), new C0336d(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.b */
    private static class C0335b extends C0279c {
        private final C0182c<MetadataBufferResult> vj;

        public C0335b(C0182c<MetadataBufferResult> c0182c) {
            this.vj = c0182c;
        }

        public void m670a(OnListParentsResponse onListParentsResponse) throws RemoteException {
            this.vj.m196b(new C0303e(Status.zQ, new MetadataBuffer(onListParentsResponse.fd(), null)));
        }

        public void m671l(Status status) throws RemoteException {
            this.vj.m196b(new C0303e(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.d */
    private static class C0336d extends C0279c {
        private final C0182c<MetadataResult> vj;

        public C0336d(C0182c<MetadataResult> c0182c) {
            this.vj = c0182c;
        }

        public void m672a(OnMetadataResponse onMetadataResponse) throws RemoteException {
            this.vj.m196b(new C0337e(Status.zQ, new C0287j(onMetadataResponse.fe())));
        }

        public void m673l(Status status) throws RemoteException {
            this.vj.m196b(new C0337e(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.r.e */
    private static class C0337e implements MetadataResult {
        private final Metadata DQ;
        private final Status vl;

        public C0337e(Status status, Metadata metadata) {
            this.vl = status;
            this.DQ = metadata;
        }

        public Metadata getMetadata() {
            return this.DQ;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    protected C0318r(DriveId driveId) {
        this.CS = driveId;
    }

    public PendingResult<Status> addChangeListener(GoogleApiClient apiClient, Listener<ChangeEvent> listener) {
        return ((C0310n) apiClient.m364a(Drive.va)).m626a(apiClient, this.CS, 1, listener);
    }

    public DriveId getDriveId() {
        return this.CS;
    }

    public PendingResult<MetadataResult> getMetadata(GoogleApiClient apiClient) {
        return apiClient.m365a(new C03301(this));
    }

    public PendingResult<MetadataBufferResult> listParents(GoogleApiClient apiClient) {
        return apiClient.m365a(new C03322(this));
    }

    public PendingResult<Status> removeChangeListener(GoogleApiClient apiClient, Listener<ChangeEvent> listener) {
        return ((C0310n) apiClient.m364a(Drive.va)).m629b(apiClient, this.CS, 1, listener);
    }

    public PendingResult<MetadataResult> updateMetadata(GoogleApiClient apiClient, MetadataChangeSet changeSet) {
        if (changeSet != null) {
            return apiClient.m366b(new C03343(this, changeSet));
        }
        throw new IllegalArgumentException("ChangeSet must be provided.");
    }
}
