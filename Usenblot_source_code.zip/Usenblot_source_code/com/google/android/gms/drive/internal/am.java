package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;

public class am implements Creator<UpdateMetadataRequest> {
    static void m559a(UpdateMetadataRequest updateMetadataRequest, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, updateMetadataRequest.wj);
        C0265b.m489a(parcel, 2, updateMetadataRequest.Do, i, false);
        C0265b.m489a(parcel, 3, updateMetadataRequest.Dp, i, false);
        C0265b.m481D(parcel, p);
    }

    public UpdateMetadataRequest m560Z(Parcel parcel) {
        MetadataBundle metadataBundle = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        DriveId driveId = null;
        while (parcel.dataPosition() < o) {
            DriveId driveId2;
            int g;
            MetadataBundle metadataBundle2;
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    MetadataBundle metadataBundle3 = metadataBundle;
                    driveId2 = driveId;
                    g = C0264a.m457g(parcel, n);
                    metadataBundle2 = metadataBundle3;
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    g = i;
                    DriveId driveId3 = (DriveId) C0264a.m446a(parcel, n, DriveId.CREATOR);
                    metadataBundle2 = metadataBundle;
                    driveId2 = driveId3;
                    break;
                case Error.BAD_CVC /*3*/:
                    metadataBundle2 = (MetadataBundle) C0264a.m446a(parcel, n, MetadataBundle.CREATOR);
                    driveId2 = driveId;
                    g = i;
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    metadataBundle2 = metadataBundle;
                    driveId2 = driveId;
                    g = i;
                    break;
            }
            i = g;
            driveId = driveId2;
            metadataBundle = metadataBundle2;
        }
        if (parcel.dataPosition() == o) {
            return new UpdateMetadataRequest(i, driveId, metadataBundle);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public UpdateMetadataRequest[] aE(int i) {
        return new UpdateMetadataRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m560Z(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aE(x0);
    }
}
