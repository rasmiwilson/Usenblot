package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.DriveApi.MetadataBufferResult;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveFolder.DriveFileResult;
import com.google.android.gms.drive.DriveFolder.DriveFolderResult;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.query.Filters;
import com.google.android.gms.drive.query.Query;
import com.google.android.gms.drive.query.Query.Builder;
import com.google.android.gms.drive.query.SearchableField;

/* renamed from: com.google.android.gms.drive.internal.q */
public class C0328q extends C0318r implements DriveFolder {

    /* renamed from: com.google.android.gms.drive.internal.q.1 */
    class C03211 extends C0289m<DriveFileResult> {
        final /* synthetic */ MetadataChangeSet DK;
        final /* synthetic */ C0328q DM;
        final /* synthetic */ Contents Dw;

        C03211(C0328q c0328q, Contents contents, MetadataChangeSet metadataChangeSet) {
            this.DM = c0328q;
            this.Dw = contents;
            this.DK = metadataChangeSet;
        }

        protected void m647a(C0310n c0310n) throws RemoteException {
            this.Dw.close();
            c0310n.eT().m687a(new CreateFileRequest(this.DM.getDriveId(), this.DK.eS(), this.Dw), new C0324a(this));
        }

        public /* synthetic */ Result m648d(Status status) {
            return m649p(status);
        }

        public DriveFileResult m649p(Status status) {
            return new C0326d(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.q.c */
    private abstract class C0322c extends C0289m<DriveFolderResult> {
        final /* synthetic */ C0328q DM;

        private C0322c(C0328q c0328q) {
            this.DM = c0328q;
        }

        public /* synthetic */ Result m650d(Status status) {
            return m651q(status);
        }

        public DriveFolderResult m651q(Status status) {
            return new C0327e(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.q.2 */
    class C03232 extends C0322c {
        final /* synthetic */ MetadataChangeSet DK;
        final /* synthetic */ C0328q DM;

        C03232(C0328q c0328q, MetadataChangeSet metadataChangeSet) {
            this.DM = c0328q;
            this.DK = metadataChangeSet;
            super(null);
        }

        protected void m653a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m688a(new CreateFolderRequest(this.DM.getDriveId(), this.DK.eS()), new C0325b(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.q.a */
    private static class C0324a extends C0279c {
        private final C0182c<DriveFileResult> vj;

        public C0324a(C0182c<DriveFileResult> c0182c) {
            this.vj = c0182c;
        }

        public void m654a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
            this.vj.m196b(new C0326d(Status.zQ, new C0319o(onDriveIdResponse.getDriveId())));
        }

        public void m655l(Status status) throws RemoteException {
            this.vj.m196b(new C0326d(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.q.b */
    private static class C0325b extends C0279c {
        private final C0182c<DriveFolderResult> vj;

        public C0325b(C0182c<DriveFolderResult> c0182c) {
            this.vj = c0182c;
        }

        public void m656a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
            this.vj.m196b(new C0327e(Status.zQ, new C0328q(onDriveIdResponse.getDriveId())));
        }

        public void m657l(Status status) throws RemoteException {
            this.vj.m196b(new C0327e(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.q.d */
    private static class C0326d implements DriveFileResult {
        private final DriveFile DN;
        private final Status vl;

        public C0326d(Status status, DriveFile driveFile) {
            this.vl = status;
            this.DN = driveFile;
        }

        public DriveFile getDriveFile() {
            return this.DN;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.q.e */
    private static class C0327e implements DriveFolderResult {
        private final DriveFolder DO;
        private final Status vl;

        public C0327e(Status status, DriveFolder driveFolder) {
            this.vl = status;
            this.DO = driveFolder;
        }

        public DriveFolder getDriveFolder() {
            return this.DO;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    public C0328q(DriveId driveId) {
        super(driveId);
    }

    public PendingResult<DriveFileResult> createFile(GoogleApiClient apiClient, MetadataChangeSet changeSet, Contents contents) {
        if (changeSet == null) {
            throw new IllegalArgumentException("MetatadataChangeSet must be provided.");
        } else if (contents == null) {
            throw new IllegalArgumentException("Contents must be provided.");
        } else if (!DriveFolder.MIME_TYPE.equals(changeSet.getMimeType())) {
            return apiClient.m366b(new C03211(this, contents, changeSet));
        } else {
            throw new IllegalArgumentException("May not create folders (mimetype: application/vnd.google-apps.folder) using this method. Use DriveFolder.createFolder() instead.");
        }
    }

    public PendingResult<DriveFolderResult> createFolder(GoogleApiClient apiClient, MetadataChangeSet changeSet) {
        if (changeSet == null) {
            throw new IllegalArgumentException("MetatadataChangeSet must be provided.");
        } else if (changeSet.getMimeType() == null || changeSet.getMimeType().equals(DriveFolder.MIME_TYPE)) {
            return apiClient.m366b(new C03232(this, changeSet));
        } else {
            throw new IllegalArgumentException("The mimetype must be of type application/vnd.google-apps.folder");
        }
    }

    public PendingResult<MetadataBufferResult> listChildren(GoogleApiClient apiClient) {
        return queryChildren(apiClient, null);
    }

    public PendingResult<MetadataBufferResult> queryChildren(GoogleApiClient apiClient, Query query) {
        Builder addFilter = new Builder().addFilter(Filters.in(SearchableField.PARENTS, getDriveId()));
        if (query != null) {
            if (query.getFilter() != null) {
                addFilter.addFilter(query.getFilter());
            }
            addFilter.setPageToken(query.getPageToken());
        }
        return new C0307l().query(apiClient, addFilter.build());
    }
}
