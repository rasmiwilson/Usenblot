package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;

/* renamed from: com.google.android.gms.drive.internal.e */
public class C0282e implements Creator<CloseContentsRequest> {
    static void m565a(CloseContentsRequest closeContentsRequest, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, closeContentsRequest.wj);
        C0265b.m489a(parcel, 2, closeContentsRequest.Dq, i, false);
        C0265b.m490a(parcel, 3, closeContentsRequest.Dr, false);
        C0265b.m481D(parcel, p);
    }

    public CloseContentsRequest m566F(Parcel parcel) {
        Boolean bool = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        Contents contents = null;
        while (parcel.dataPosition() < o) {
            Contents contents2;
            int g;
            Boolean bool2;
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    Boolean bool3 = bool;
                    contents2 = contents;
                    g = C0264a.m457g(parcel, n);
                    bool2 = bool3;
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    g = i;
                    Contents contents3 = (Contents) C0264a.m446a(parcel, n, Contents.CREATOR);
                    bool2 = bool;
                    contents2 = contents3;
                    break;
                case Error.BAD_CVC /*3*/:
                    bool2 = C0264a.m454d(parcel, n);
                    contents2 = contents;
                    g = i;
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    bool2 = bool;
                    contents2 = contents;
                    g = i;
                    break;
            }
            i = g;
            contents = contents2;
            bool = bool2;
        }
        if (parcel.dataPosition() == o) {
            return new CloseContentsRequest(i, contents, bool);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public CloseContentsRequest[] ak(int i) {
        return new CloseContentsRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m566F(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ak(x0);
    }
}
