package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.Status;

public class ak extends C0279c {
    private final C0182c<Status> vj;

    public ak(C0182c<Status> c0182c) {
        this.vj = c0182c;
    }

    public void m556l(Status status) throws RemoteException {
        this.vj.m196b(status);
    }

    public void onSuccess() throws RemoteException {
        this.vj.m196b(Status.zQ);
    }
}
