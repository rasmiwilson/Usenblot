package com.google.android.gms.drive.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.events.C0275c;
import com.google.android.gms.drive.events.DriveEvent;
import com.google.android.gms.drive.events.DriveEvent.Listener;
import com.google.android.gms.drive.internal.C0307l.C0294j;
import com.google.android.gms.drive.internal.C0307l.C0306k;
import com.google.android.gms.drive.internal.C0344u.C0346a;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.eh;
import com.google.android.gms.internal.eh.C0556e;
import com.google.android.gms.internal.en;
import com.google.android.gms.internal.er;
import java.util.HashMap;
import java.util.Map;

/* renamed from: com.google.android.gms.drive.internal.n */
public class C0310n extends eh<C0344u> {
    private DriveId DA;
    final ConnectionCallbacks DB;
    Map<DriveId, Map<Listener<?>, C0342s<?>>> DC;
    private DriveId Dz;
    private final String vi;

    /* renamed from: com.google.android.gms.drive.internal.n.1 */
    class C03081 extends C0294j {
        final /* synthetic */ DriveId DD;
        final /* synthetic */ int DE;
        final /* synthetic */ C0342s DF;
        final /* synthetic */ C0310n DG;

        C03081(C0310n c0310n, DriveId driveId, int i, C0342s c0342s) {
            this.DG = c0310n;
            this.DD = driveId;
            this.DE = i;
            this.DF = c0342s;
        }

        protected void m607a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m682a(new AddEventListenerRequest(this.DD, this.DE), this.DF, null, new ak(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.n.2 */
    class C03092 extends C0294j {
        final /* synthetic */ DriveId DD;
        final /* synthetic */ int DE;
        final /* synthetic */ C0342s DF;
        final /* synthetic */ C0310n DG;

        C03092(C0310n c0310n, DriveId driveId, int i, C0342s c0342s) {
            this.DG = c0310n;
            this.DD = driveId;
            this.DE = i;
            this.DF = c0342s;
        }

        protected void m609a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m694a(new RemoveEventListenerRequest(this.DD, this.DE), this.DF, null, new ak(this));
        }
    }

    public C0310n(Context context, Looper looper, ee eeVar, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String[] strArr) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, strArr);
        this.DC = new HashMap();
        this.vi = (String) er.m1549b(eeVar.dR(), (Object) "Must call Api.ClientBuilder.setAccountName()");
        this.DB = connectionCallbacks;
    }

    protected C0344u m625C(IBinder iBinder) {
        return C0346a.m716D(iBinder);
    }

    <C extends DriveEvent> PendingResult<Status> m626a(GoogleApiClient googleApiClient, DriveId driveId, int i, Listener<C> listener) {
        PendingResult<Status> c0306k;
        er.m1550b(C0275c.m518a(i, driveId), (Object) "id");
        er.m1549b((Object) listener, (Object) "listener");
        er.m1547a(isConnected(), "Client must be connected");
        synchronized (this.DC) {
            Map map = (Map) this.DC.get(driveId);
            if (map == null) {
                map = new HashMap();
                this.DC.put(driveId, map);
            }
            if (map.containsKey(listener)) {
                c0306k = new C0306k(Status.zQ);
            } else {
                C0342s c0342s = new C0342s(getLooper(), i, listener);
                map.put(listener, c0342s);
                c0306k = googleApiClient.m366b(new C03081(this, driveId, i, c0342s));
            }
        }
        return c0306k;
    }

    protected void m627a(int i, IBinder iBinder, Bundle bundle) {
        if (bundle != null) {
            bundle.setClassLoader(getClass().getClassLoader());
            this.Dz = (DriveId) bundle.getParcelable("com.google.android.gms.drive.root_id");
            this.DA = (DriveId) bundle.getParcelable("com.google.android.gms.drive.appdata_id");
        }
        super.m619a(i, iBinder, bundle);
    }

    protected void m628a(en enVar, C0556e c0556e) throws RemoteException {
        String packageName = getContext().getPackageName();
        er.m1551f(c0556e);
        er.m1551f(packageName);
        er.m1551f(ea());
        enVar.m1497a(c0556e, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, packageName, ea(), this.vi, new Bundle());
    }

    protected String aF() {
        return "com.google.android.gms.drive.ApiService.START";
    }

    protected String aG() {
        return "com.google.android.gms.drive.internal.IDriveService";
    }

    PendingResult<Status> m629b(GoogleApiClient googleApiClient, DriveId driveId, int i, Listener<?> listener) {
        PendingResult<Status> c0306k;
        er.m1550b(C0275c.m518a(i, driveId), (Object) "id");
        er.m1549b((Object) listener, (Object) "listener");
        er.m1547a(isConnected(), "Client must be connected");
        synchronized (this.DC) {
            Map map = (Map) this.DC.get(driveId);
            if (map == null) {
                c0306k = new C0306k(Status.zQ);
            } else {
                C0342s c0342s = (C0342s) map.remove(listener);
                if (c0342s == null) {
                    c0306k = new C0306k(Status.zQ);
                } else {
                    if (map.isEmpty()) {
                        this.DC.remove(driveId);
                    }
                    c0306k = googleApiClient.m366b(new C03092(this, driveId, i, c0342s));
                }
            }
        }
        return c0306k;
    }

    public void disconnect() {
        C0344u c0344u = (C0344u) eb();
        if (c0344u != null) {
            try {
                c0344u.m689a(new DisconnectRequest());
            } catch (RemoteException e) {
            }
        }
        super.disconnect();
        this.DC.clear();
    }

    public C0344u eT() {
        return (C0344u) eb();
    }

    public DriveId eU() {
        return this.Dz;
    }

    public DriveId eV() {
        return this.DA;
    }

    protected /* synthetic */ IInterface m630p(IBinder iBinder) {
        return m625C(iBinder);
    }
}
