package com.google.android.gms.drive.internal;

import com.appsgeyser.sdk.configuration.Constants;
import com.google.ads.AdSize;
import com.google.android.gms.internal.jy;
import com.google.android.gms.internal.jz;
import com.google.android.gms.internal.kd;
import com.google.android.gms.internal.ke;
import com.google.android.gms.internal.kh;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.io.IOException;

/* renamed from: com.google.android.gms.drive.internal.y */
public final class C0350y extends ke {
    public static final C0350y[] DU;
    public String DV;
    public long DW;
    public long DX;
    private int DY;
    public int versionCode;

    static {
        DU = new C0350y[0];
    }

    public C0350y() {
        this.versionCode = 1;
        this.DV = Constants.PUBLISHER_NAME;
        this.DW = -1;
        this.DX = -1;
        this.DY = -1;
    }

    public static C0350y m734g(byte[] bArr) throws kd {
        return (C0350y) ke.m727a(new C0350y(), bArr);
    }

    public void m735a(jz jzVar) throws IOException {
        jzVar.m2585f(1, this.versionCode);
        jzVar.m2580b(2, this.DV);
        jzVar.m2582c(3, this.DW);
        jzVar.m2582c(4, this.DX);
    }

    public /* synthetic */ ke m736b(jy jyVar) throws IOException {
        return m738m(jyVar);
    }

    public int m737c() {
        int g = (((0 + jz.m2569g(1, this.versionCode)) + jz.m2570g(2, this.DV)) + jz.m2568e(3, this.DW)) + jz.m2568e(4, this.DX);
        this.DY = g;
        return g;
    }

    public int eW() {
        if (this.DY < 0) {
            m737c();
        }
        return this.DY;
    }

    public C0350y m738m(jy jyVar) throws IOException {
        while (true) {
            int ky = jyVar.ky();
            switch (ky) {
                case Base64Encoder.DEFAULT /*0*/:
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    this.versionCode = jyVar.kB();
                    continue;
                case 18:
                    this.DV = jyVar.readString();
                    continue;
                case 24:
                    this.DW = jyVar.kD();
                    continue;
                case AdSize.LANDSCAPE_AD_HEIGHT /*32*/:
                    this.DX = jyVar.kD();
                    continue;
                default:
                    if (!kh.m2600b(jyVar, ky)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }
}
