package com.google.android.gms.drive.internal;

import com.google.android.gms.common.api.C0239a.C0184a;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.drive.Drive;

/* renamed from: com.google.android.gms.drive.internal.m */
abstract class C0289m<R extends Result> extends C0184a<R, C0310n> {
    public C0289m() {
        super(Drive.va);
    }
}
