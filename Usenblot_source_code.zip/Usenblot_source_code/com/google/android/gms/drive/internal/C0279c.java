package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.internal.C0277v.C0278a;

/* renamed from: com.google.android.gms.drive.internal.c */
public class C0279c extends C0278a {
    public void m549a(OnContentsResponse onContentsResponse) throws RemoteException {
    }

    public void m550a(OnDownloadProgressResponse onDownloadProgressResponse) throws RemoteException {
    }

    public void m551a(OnDriveIdResponse onDriveIdResponse) throws RemoteException {
    }

    public void m552a(OnListEntriesResponse onListEntriesResponse) throws RemoteException {
    }

    public void m553a(OnListParentsResponse onListParentsResponse) throws RemoteException {
    }

    public void m554a(OnMetadataResponse onMetadataResponse) throws RemoteException {
    }

    public void m555l(Status status) throws RemoteException {
    }

    public void onSuccess() throws RemoteException {
    }
}
