package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;

public class ad implements Creator<OnListEntriesResponse> {
    static void m527a(OnListEntriesResponse onListEntriesResponse, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, onListEntriesResponse.wj);
        C0265b.m489a(parcel, 2, onListEntriesResponse.Ed, i, false);
        C0265b.m481D(parcel, p);
    }

    public OnListEntriesResponse m528R(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        DataHolder dataHolder = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    dataHolder = (DataHolder) C0264a.m446a(parcel, n, DataHolder.CREATOR);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new OnListEntriesResponse(i, dataHolder);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public OnListEntriesResponse[] aw(int i) {
        return new OnListEntriesResponse[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m528R(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aw(x0);
    }
}
