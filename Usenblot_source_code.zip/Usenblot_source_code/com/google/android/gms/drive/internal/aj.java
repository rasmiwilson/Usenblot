package com.google.android.gms.drive.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;

public class aj implements Creator<RemoveEventListenerRequest> {
    static void m539a(RemoveEventListenerRequest removeEventListenerRequest, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, removeEventListenerRequest.wj);
        C0265b.m489a(parcel, 2, removeEventListenerRequest.CS, i, false);
        C0265b.m501c(parcel, 3, removeEventListenerRequest.Dm);
        C0265b.m481D(parcel, p);
    }

    public RemoveEventListenerRequest m540X(Parcel parcel) {
        int i = 0;
        int o = C0264a.m466o(parcel);
        DriveId driveId = null;
        int i2 = 0;
        while (parcel.dataPosition() < o) {
            DriveId driveId2;
            int g;
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    int i3 = i;
                    driveId2 = driveId;
                    g = C0264a.m457g(parcel, n);
                    n = i3;
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    g = i2;
                    DriveId driveId3 = (DriveId) C0264a.m446a(parcel, n, DriveId.CREATOR);
                    n = i;
                    driveId2 = driveId3;
                    break;
                case Error.BAD_CVC /*3*/:
                    n = C0264a.m457g(parcel, n);
                    driveId2 = driveId;
                    g = i2;
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    n = i;
                    driveId2 = driveId;
                    g = i2;
                    break;
            }
            i2 = g;
            driveId = driveId2;
            i = n;
        }
        if (parcel.dataPosition() == o) {
            return new RemoveEventListenerRequest(i2, driveId, i);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public RemoveEventListenerRequest[] aC(int i) {
        return new RemoveEventListenerRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m540X(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aC(x0);
    }
}
