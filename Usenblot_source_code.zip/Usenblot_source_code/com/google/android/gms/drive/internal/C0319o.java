package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi.ContentsResult;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFile.DownloadProgressListener;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataChangeSet;
import com.google.android.gms.drive.internal.C0307l.C0300a;

/* renamed from: com.google.android.gms.drive.internal.o */
public class C0319o extends C0318r implements DriveFile {

    /* renamed from: com.google.android.gms.drive.internal.o.d */
    private abstract class C0311d extends C0289m<ContentsResult> {
        final /* synthetic */ C0319o DJ;

        private C0311d(C0319o c0319o) {
            this.DJ = c0319o;
        }

        public /* synthetic */ Result m631d(Status status) {
            return m632n(status);
        }

        public ContentsResult m632n(Status status) {
            return new C0300a(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.1 */
    class C03121 extends C0311d {
        final /* synthetic */ int DH;
        final /* synthetic */ DownloadProgressListener DI;
        final /* synthetic */ C0319o DJ;

        C03121(C0319o c0319o, int i, DownloadProgressListener downloadProgressListener) {
            this.DJ = c0319o;
            this.DH = i;
            this.DI = downloadProgressListener;
            super(null);
        }

        protected void m634a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m692a(new OpenContentsRequest(this.DJ.getDriveId(), this.DH), new C0317c(this, this.DI));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.b */
    private abstract class C0313b extends C0289m<Status> {
        final /* synthetic */ C0319o DJ;

        private C0313b(C0319o c0319o) {
            this.DJ = c0319o;
        }

        public /* synthetic */ Result m635d(Status status) {
            return m636f(status);
        }

        public Status m636f(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.2 */
    class C03142 extends C0313b {
        final /* synthetic */ C0319o DJ;
        final /* synthetic */ Contents Dw;

        C03142(C0319o c0319o, Contents contents) {
            this.DJ = c0319o;
            this.Dw = contents;
            super(null);
        }

        protected void m638a(C0310n c0310n) throws RemoteException {
            this.Dw.close();
            c0310n.eT().m685a(new CloseContentsRequest(this.Dw, true), new ak(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.a */
    private abstract class C0315a extends C0289m<Status> {
        final /* synthetic */ C0319o DJ;

        private C0315a(C0319o c0319o) {
            this.DJ = c0319o;
        }

        public /* synthetic */ Result m639d(Status status) {
            return m640f(status);
        }

        public Status m640f(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.3 */
    class C03163 extends C0315a {
        final /* synthetic */ C0319o DJ;
        final /* synthetic */ MetadataChangeSet DK;
        final /* synthetic */ Contents Dw;

        C03163(C0319o c0319o, Contents contents, MetadataChangeSet metadataChangeSet) {
            this.DJ = c0319o;
            this.Dw = contents;
            this.DK = metadataChangeSet;
            super(null);
        }

        protected void m642a(C0310n c0310n) throws RemoteException {
            this.Dw.close();
            c0310n.eT().m684a(new CloseContentsAndUpdateMetadataRequest(this.DJ.CS, this.DK.eS(), this.Dw), new ak(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.o.c */
    private static class C0317c extends C0279c {
        private final DownloadProgressListener DL;
        private final C0182c<ContentsResult> vj;

        public C0317c(C0182c<ContentsResult> c0182c, DownloadProgressListener downloadProgressListener) {
            this.vj = c0182c;
            this.DL = downloadProgressListener;
        }

        public void m643a(OnContentsResponse onContentsResponse) throws RemoteException {
            this.vj.m196b(new C0300a(Status.zQ, onContentsResponse.eX()));
        }

        public void m644a(OnDownloadProgressResponse onDownloadProgressResponse) throws RemoteException {
            if (this.DL != null) {
                this.DL.onProgress(onDownloadProgressResponse.eY(), onDownloadProgressResponse.eZ());
            }
        }

        public void m645l(Status status) throws RemoteException {
            this.vj.m196b(new C0300a(status, null));
        }
    }

    public C0319o(DriveId driveId) {
        super(driveId);
    }

    public PendingResult<Status> commitAndCloseContents(GoogleApiClient apiClient, Contents contents) {
        if (contents != null) {
            return apiClient.m366b(new C03142(this, contents));
        }
        throw new IllegalArgumentException("Contents must be provided.");
    }

    public PendingResult<Status> commitAndCloseContents(GoogleApiClient apiClient, Contents contents, MetadataChangeSet changeSet) {
        if (contents != null) {
            return apiClient.m366b(new C03163(this, contents, changeSet));
        }
        throw new IllegalArgumentException("Contents must be provided.");
    }

    public PendingResult<Status> discardContents(GoogleApiClient apiClient, Contents contents) {
        return Drive.DriveApi.discardContents(apiClient, contents);
    }

    public PendingResult<ContentsResult> openContents(GoogleApiClient apiClient, int mode, DownloadProgressListener listener) {
        if (mode == DriveFile.MODE_READ_ONLY || mode == DriveFile.MODE_WRITE_ONLY || mode == DriveFile.MODE_READ_WRITE) {
            return apiClient.m365a(new C03121(this, mode, listener));
        }
        throw new IllegalArgumentException("Invalid mode provided.");
    }
}
