package com.google.android.gms.drive.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.drive.Contents;
import com.google.android.gms.drive.CreateFileActivityBuilder;
import com.google.android.gms.drive.Drive;
import com.google.android.gms.drive.DriveApi;
import com.google.android.gms.drive.DriveApi.ContentsResult;
import com.google.android.gms.drive.DriveApi.DriveIdResult;
import com.google.android.gms.drive.DriveApi.MetadataBufferResult;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.drive.DriveFolder;
import com.google.android.gms.drive.DriveId;
import com.google.android.gms.drive.MetadataBuffer;
import com.google.android.gms.drive.OpenFileActivityBuilder;
import com.google.android.gms.drive.query.Query;

/* renamed from: com.google.android.gms.drive.internal.l */
public class C0307l implements DriveApi {

    /* renamed from: com.google.android.gms.drive.internal.l.i */
    abstract class C0290i extends C0289m<MetadataBufferResult> {
        final /* synthetic */ C0307l Dv;

        C0290i(C0307l c0307l) {
            this.Dv = c0307l;
        }

        public /* synthetic */ Result m578d(Status status) {
            return m579o(status);
        }

        public MetadataBufferResult m579o(Status status) {
            return new C0303e(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.1 */
    class C02911 extends C0290i {
        final /* synthetic */ Query Du;
        final /* synthetic */ C0307l Dv;

        C02911(C0307l c0307l, Query query) {
            this.Dv = c0307l;
            this.Du = query;
            super(c0307l);
        }

        protected void m581a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m693a(new QueryRequest(this.Du), new C0305h(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.g */
    abstract class C0292g extends C0289m<ContentsResult> {
        final /* synthetic */ C0307l Dv;

        C0292g(C0307l c0307l) {
            this.Dv = c0307l;
        }

        public /* synthetic */ Result m582d(Status status) {
            return m583n(status);
        }

        public ContentsResult m583n(Status status) {
            return new C0300a(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.2 */
    class C02932 extends C0292g {
        final /* synthetic */ C0307l Dv;

        C02932(C0307l c0307l) {
            this.Dv = c0307l;
            super(c0307l);
        }

        protected void m585a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m686a(new CreateContentsRequest(), new C0304f(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.j */
    static abstract class C0294j extends C0289m<Status> {
        C0294j() {
        }

        public /* synthetic */ Result m586d(Status status) {
            return m587f(status);
        }

        public Status m587f(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.3 */
    class C02953 extends C0294j {
        final /* synthetic */ C0307l Dv;
        final /* synthetic */ Contents Dw;

        C02953(C0307l c0307l, Contents contents) {
            this.Dv = c0307l;
            this.Dw = contents;
        }

        protected void m589a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m685a(new CloseContentsRequest(this.Dw, false), new ak(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.d */
    abstract class C0296d extends C0289m<DriveIdResult> {
        final /* synthetic */ C0307l Dv;

        C0296d(C0307l c0307l) {
            this.Dv = c0307l;
        }

        public /* synthetic */ Result m590d(Status status) {
            return m591m(status);
        }

        public DriveIdResult m591m(Status status) {
            return new C0302c(status, null);
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.4 */
    class C02974 extends C0296d {
        final /* synthetic */ C0307l Dv;
        final /* synthetic */ String Dx;

        C02974(C0307l c0307l, String str) {
            this.Dv = c0307l;
            this.Dx = str;
            super(c0307l);
        }

        protected void m593a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m690a(new GetMetadataRequest(DriveId.aq(this.Dx)), new C0301b(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.l */
    abstract class C0298l extends C0289m<Status> {
        final /* synthetic */ C0307l Dv;

        C0298l(C0307l c0307l) {
            this.Dv = c0307l;
        }

        public /* synthetic */ Result m594d(Status status) {
            return m595f(status);
        }

        public Status m595f(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.5 */
    class C02995 extends C0298l {
        final /* synthetic */ C0307l Dv;

        C02995(C0307l c0307l) {
            this.Dv = c0307l;
            super(c0307l);
        }

        protected void m597a(C0310n c0310n) throws RemoteException {
            c0310n.eT().m697a(new ak(this));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.a */
    static class C0300a implements ContentsResult {
        private final Contents CW;
        private final Status vl;

        public C0300a(Status status, Contents contents) {
            this.vl = status;
            this.CW = contents;
        }

        public Contents getContents() {
            return this.CW;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.b */
    private static class C0301b extends C0279c {
        private final C0182c<DriveIdResult> vj;

        public C0301b(C0182c<DriveIdResult> c0182c) {
            this.vj = c0182c;
        }

        public void m598a(OnMetadataResponse onMetadataResponse) throws RemoteException {
            this.vj.m196b(new C0302c(Status.zQ, new C0287j(onMetadataResponse.fe()).getDriveId()));
        }

        public void m599l(Status status) throws RemoteException {
            this.vj.m196b(new C0302c(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.c */
    static class C0302c implements DriveIdResult {
        private final DriveId CS;
        private final Status vl;

        public C0302c(Status status, DriveId driveId) {
            this.vl = status;
            this.CS = driveId;
        }

        public DriveId getDriveId() {
            return this.CS;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.e */
    static class C0303e implements MetadataBufferResult {
        private final MetadataBuffer Dy;
        private final Status vl;

        public C0303e(Status status, MetadataBuffer metadataBuffer) {
            this.vl = status;
            this.Dy = metadataBuffer;
        }

        public MetadataBuffer getMetadataBuffer() {
            return this.Dy;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.f */
    private static class C0304f extends C0279c {
        private final C0182c<ContentsResult> vj;

        public C0304f(C0182c<ContentsResult> c0182c) {
            this.vj = c0182c;
        }

        public void m600a(OnContentsResponse onContentsResponse) throws RemoteException {
            this.vj.m196b(new C0300a(Status.zQ, onContentsResponse.eX()));
        }

        public void m601l(Status status) throws RemoteException {
            this.vj.m196b(new C0300a(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.h */
    static class C0305h extends C0279c {
        private final C0182c<MetadataBufferResult> vj;

        public C0305h(C0182c<MetadataBufferResult> c0182c) {
            this.vj = c0182c;
        }

        public void m602a(OnListEntriesResponse onListEntriesResponse) throws RemoteException {
            this.vj.m196b(new C0303e(Status.zQ, new MetadataBuffer(onListEntriesResponse.fc(), null)));
        }

        public void m603l(Status status) throws RemoteException {
            this.vj.m196b(new C0303e(status, null));
        }
    }

    /* renamed from: com.google.android.gms.drive.internal.l.k */
    static class C0306k extends C0294j {
        C0306k(Status status) {
            m201a((Result) status);
        }

        protected void m605a(C0310n c0310n) {
        }
    }

    public PendingResult<Status> discardContents(GoogleApiClient apiClient, Contents contents) {
        return apiClient.m366b(new C02953(this, contents));
    }

    public PendingResult<DriveIdResult> fetchDriveId(GoogleApiClient apiClient, String resourceId) {
        return apiClient.m365a(new C02974(this, resourceId));
    }

    public DriveFolder getAppFolder(GoogleApiClient apiClient) {
        if (apiClient.isConnected()) {
            DriveId eV = ((C0310n) apiClient.m364a(Drive.va)).eV();
            return eV != null ? new C0328q(eV) : null;
        } else {
            throw new IllegalStateException("Client must be connected");
        }
    }

    public DriveFile getFile(GoogleApiClient apiClient, DriveId id) {
        if (id == null) {
            throw new IllegalArgumentException("Id must be provided.");
        } else if (apiClient.isConnected()) {
            return new C0319o(id);
        } else {
            throw new IllegalStateException("Client must be connected");
        }
    }

    public DriveFolder getFolder(GoogleApiClient apiClient, DriveId id) {
        if (id == null) {
            throw new IllegalArgumentException("Id must be provided.");
        } else if (apiClient.isConnected()) {
            return new C0328q(id);
        } else {
            throw new IllegalStateException("Client must be connected");
        }
    }

    public DriveFolder getRootFolder(GoogleApiClient apiClient) {
        if (apiClient.isConnected()) {
            return new C0328q(((C0310n) apiClient.m364a(Drive.va)).eU());
        }
        throw new IllegalStateException("Client must be connected");
    }

    public PendingResult<ContentsResult> newContents(GoogleApiClient apiClient) {
        return apiClient.m365a(new C02932(this));
    }

    public CreateFileActivityBuilder newCreateFileActivityBuilder() {
        return new CreateFileActivityBuilder();
    }

    public OpenFileActivityBuilder newOpenFileActivityBuilder() {
        return new OpenFileActivityBuilder();
    }

    public PendingResult<MetadataBufferResult> query(GoogleApiClient apiClient, Query query) {
        if (query != null) {
            return apiClient.m365a(new C02911(this, query));
        }
        throw new IllegalArgumentException("Query must be provided.");
    }

    public PendingResult<Status> requestSync(GoogleApiClient client) {
        return client.m366b(new C02995(this));
    }
}
