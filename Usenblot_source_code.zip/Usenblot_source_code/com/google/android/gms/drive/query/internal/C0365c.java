package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.location.LocationStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

/* renamed from: com.google.android.gms.drive.query.internal.c */
public class C0365c implements Creator<FilterHolder> {
    static void m803a(FilterHolder filterHolder, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m489a(parcel, 1, filterHolder.ER, i, false);
        C0265b.m501c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, filterHolder.wj);
        C0265b.m489a(parcel, 2, filterHolder.ES, i, false);
        C0265b.m489a(parcel, 3, filterHolder.ET, i, false);
        C0265b.m489a(parcel, 4, filterHolder.EU, i, false);
        C0265b.m489a(parcel, 5, filterHolder.EV, i, false);
        C0265b.m481D(parcel, p);
    }

    public FilterHolder[] aJ(int i) {
        return new FilterHolder[i];
    }

    public FilterHolder ae(Parcel parcel) {
        InFilter inFilter = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        NotFilter notFilter = null;
        LogicalFilter logicalFilter = null;
        FieldOnlyFilter fieldOnlyFilter = null;
        ComparisonFilter comparisonFilter = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    comparisonFilter = (ComparisonFilter) C0264a.m446a(parcel, n, ComparisonFilter.CREATOR);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    fieldOnlyFilter = (FieldOnlyFilter) C0264a.m446a(parcel, n, FieldOnlyFilter.CREATOR);
                    break;
                case Error.BAD_CVC /*3*/:
                    logicalFilter = (LogicalFilter) C0264a.m446a(parcel, n, LogicalFilter.CREATOR);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    notFilter = (NotFilter) C0264a.m446a(parcel, n, NotFilter.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    inFilter = (InFilter) C0264a.m446a(parcel, n, InFilter.CREATOR);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new FilterHolder(i, comparisonFilter, fieldOnlyFilter, logicalFilter, notFilter, inFilter);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return ae(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aJ(x0);
    }
}
