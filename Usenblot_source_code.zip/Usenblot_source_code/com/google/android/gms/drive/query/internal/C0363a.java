package com.google.android.gms.drive.query.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.drive.metadata.internal.MetadataBundle;
import com.google.android.gms.location.LocationStatusCodes;

/* renamed from: com.google.android.gms.drive.query.internal.a */
public class C0363a implements Creator<ComparisonFilter> {
    static void m801a(ComparisonFilter comparisonFilter, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, comparisonFilter.wj);
        C0265b.m489a(parcel, 1, comparisonFilter.EO, i, false);
        C0265b.m489a(parcel, 2, comparisonFilter.EP, i, false);
        C0265b.m481D(parcel, p);
    }

    public ComparisonFilter[] aH(int i) {
        return new ComparisonFilter[i];
    }

    public ComparisonFilter ac(Parcel parcel) {
        MetadataBundle metadataBundle = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        Operator operator = null;
        while (parcel.dataPosition() < o) {
            int i2;
            MetadataBundle metadataBundle2;
            Operator operator2;
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i2 = i;
                    Operator operator3 = (Operator) C0264a.m446a(parcel, n, Operator.CREATOR);
                    metadataBundle2 = metadataBundle;
                    operator2 = operator3;
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    metadataBundle2 = (MetadataBundle) C0264a.m446a(parcel, n, MetadataBundle.CREATOR);
                    operator2 = operator;
                    i2 = i;
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    MetadataBundle metadataBundle3 = metadataBundle;
                    operator2 = operator;
                    i2 = C0264a.m457g(parcel, n);
                    metadataBundle2 = metadataBundle3;
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    metadataBundle2 = metadataBundle;
                    operator2 = operator;
                    i2 = i;
                    break;
            }
            i = i2;
            operator = operator2;
            metadataBundle = metadataBundle2;
        }
        if (parcel.dataPosition() == o) {
            return new ComparisonFilter(i, operator, metadataBundle);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return ac(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aH(x0);
    }
}
