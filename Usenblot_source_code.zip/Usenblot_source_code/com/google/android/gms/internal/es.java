package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.view.View;
import com.google.android.gms.dynamic.C0383c;
import com.google.android.gms.dynamic.C0385e;
import com.google.android.gms.dynamic.C0385e.C0384a;
import com.google.android.gms.internal.eo.C0567a;

public final class es extends C0385e<eo> {
    private static final es Cg;

    static {
        Cg = new es();
    }

    private es() {
        super("com.google.android.gms.common.ui.SignInButtonCreatorImpl");
    }

    public static View m1554d(Context context, int i, int i2) throws C0384a {
        return Cg.m1555e(context, i, i2);
    }

    private View m1555e(Context context, int i, int i2) throws C0384a {
        try {
            return (View) C0383c.m826b(((eo) m829z(context)).m1539a(C0383c.m827h(context), i, i2));
        } catch (Throwable e) {
            throw new C0384a("Could not get button with size " + i + " and color " + i2, e);
        }
    }

    public eo m1556B(IBinder iBinder) {
        return C0567a.m1541A(iBinder);
    }

    public /* synthetic */ Object m1557d(IBinder iBinder) {
        return m1556B(iBinder);
    }
}
