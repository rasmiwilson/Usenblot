package com.google.android.gms.internal;

import android.util.Base64;

public final class fk {
    public static String m1646d(byte[] bArr) {
        return bArr == null ? null : Base64.encodeToString(bArr, 0);
    }

    public static String m1647e(byte[] bArr) {
        return bArr == null ? null : Base64.encodeToString(bArr, 10);
    }
}
