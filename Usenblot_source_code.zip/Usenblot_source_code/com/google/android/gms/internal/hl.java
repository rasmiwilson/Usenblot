package com.google.android.gms.internal;

import android.os.IInterface;

public interface hl<T extends IInterface> {
    void bm();

    T eb();
}
