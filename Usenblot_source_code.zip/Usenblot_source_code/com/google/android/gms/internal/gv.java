package com.google.android.gms.internal;

import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;

public final class gv {
    public static String aW(int i) {
        switch (i) {
            case Base64Encoder.DEFAULT /*0*/:
                return "TURN_STATUS_INVITED";
            case Base64Encoder.NO_PADDING /*1*/:
                return "TURN_STATUS_MY_TURN";
            case Base64Encoder.URL_SAFE /*2*/:
                return "TURN_STATUS_THEIR_TURN";
            case Error.BAD_CVC /*3*/:
                return "TURN_STATUS_COMPLETE";
            default:
                fz.m1918h("MatchTurnStatus", "Unknown match turn status: " + i);
                return "TURN_STATUS_UNKNOWN";
        }
    }
}
