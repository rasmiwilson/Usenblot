package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import com.google.android.gms.cast.ApplicationMetadata;
import com.google.android.gms.cast.Cast;
import com.google.android.gms.cast.Cast.ApplicationConnectionResult;
import com.google.android.gms.cast.Cast.Listener;
import com.google.android.gms.cast.Cast.MessageReceivedCallback;
import com.google.android.gms.cast.CastDevice;
import com.google.android.gms.cast.CastStatusCodes;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.ds.C0543a;
import com.google.android.gms.internal.dt.C0539a;
import com.google.android.gms.internal.eh.C0556e;
import com.google.android.gms.location.LocationStatusCodes;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

public final class dq extends eh<ds> {
    private static final du xE;
    private static final Object xU;
    private static final Object xV;
    private final Handler mHandler;
    private final Listener wz;
    private ApplicationMetadata xF;
    private final CastDevice xG;
    private final dt xH;
    private final Map<String, MessageReceivedCallback> xI;
    private final long xJ;
    private String xK;
    private boolean xL;
    private boolean xM;
    private final AtomicLong xN;
    private String xO;
    private String xP;
    private Bundle xQ;
    private Map<Long, C0182c<Status>> xR;
    private C0182c<ApplicationConnectionResult> xS;
    private C0182c<Status> xT;
    private double xe;
    private boolean xf;

    /* renamed from: com.google.android.gms.internal.dq.1 */
    class C05401 extends C0539a {
        final /* synthetic */ dq xW;

        /* renamed from: com.google.android.gms.internal.dq.1.1 */
        class C05361 implements Runnable {
            final /* synthetic */ int xX;
            final /* synthetic */ C05401 xY;

            C05361(C05401 c05401, int i) {
                this.xY = c05401;
                this.xX = i;
            }

            public void run() {
                if (this.xY.xW.wz != null) {
                    this.xY.xW.wz.onApplicationDisconnected(this.xX);
                }
            }
        }

        /* renamed from: com.google.android.gms.internal.dq.1.2 */
        class C05372 implements Runnable {
            final /* synthetic */ C05401 xY;
            final /* synthetic */ String xZ;
            final /* synthetic */ double xs;
            final /* synthetic */ boolean xt;

            C05372(C05401 c05401, String str, double d, boolean z) {
                this.xY = c05401;
                this.xZ = str;
                this.xs = d;
                this.xt = z;
            }

            public void run() {
                this.xY.xW.m1383a(this.xZ, this.xs, this.xt);
            }
        }

        /* renamed from: com.google.android.gms.internal.dq.1.3 */
        class C05383 implements Runnable {
            final /* synthetic */ String wp;
            final /* synthetic */ C05401 xY;
            final /* synthetic */ String ya;

            C05383(C05401 c05401, String str, String str2) {
                this.xY = c05401;
                this.wp = str;
                this.ya = str2;
            }

            public void run() {
                synchronized (this.xY.xW.xI) {
                    MessageReceivedCallback messageReceivedCallback = (MessageReceivedCallback) this.xY.xW.xI.get(this.wp);
                }
                if (messageReceivedCallback != null) {
                    messageReceivedCallback.onMessageReceived(this.xY.xW.xG, this.wp, this.ya);
                    return;
                }
                dq.xE.m1435b("Discarded message for unknown namespace '%s'", this.wp);
            }
        }

        C05401(dq dqVar) {
            this.xW = dqVar;
        }

        private boolean m1367D(int i) {
            synchronized (dq.xV) {
                if (this.xW.xT != null) {
                    this.xW.xT.m196b(new Status(i));
                    this.xW.xT = null;
                    return true;
                }
                return false;
            }
        }

        private void m1368b(long j, int i) {
            synchronized (this.xW.xR) {
                C0182c c0182c = (C0182c) this.xW.xR.remove(Long.valueOf(j));
            }
            if (c0182c != null) {
                c0182c.m196b(new Status(i));
            }
        }

        public void m1369A(int i) {
            synchronized (dq.xU) {
                if (this.xW.xS != null) {
                    this.xW.xS.m196b(new C0541a(new Status(i)));
                    this.xW.xS = null;
                }
            }
        }

        public void m1370B(int i) {
            m1367D(i);
        }

        public void m1371C(int i) {
            m1367D(i);
        }

        public void m1372a(ApplicationMetadata applicationMetadata, String str, String str2, boolean z) {
            this.xW.xF = applicationMetadata;
            this.xW.xO = applicationMetadata.getApplicationId();
            this.xW.xP = str2;
            synchronized (dq.xU) {
                if (this.xW.xS != null) {
                    this.xW.xS.m196b(new C0541a(new Status(0), applicationMetadata, str, str2, z));
                    this.xW.xS = null;
                }
            }
        }

        public void m1373a(String str, long j) {
            m1368b(j, 0);
        }

        public void m1374a(String str, long j, int i) {
            m1368b(j, i);
        }

        public void m1375b(String str, double d, boolean z) {
            this.xW.mHandler.post(new C05372(this, str, d, z));
        }

        public void m1376b(String str, byte[] bArr) {
            dq.xE.m1435b("IGNORING: Receive (type=binary, ns=%s) <%d bytes>", str, Integer.valueOf(bArr.length));
        }

        public void m1377d(String str, String str2) {
            dq.xE.m1435b("Receive (type=text, ns=%s) %s", str, str2);
            this.xW.mHandler.post(new C05383(this, str, str2));
        }

        public void onApplicationDisconnected(int statusCode) {
            this.xW.xO = null;
            this.xW.xP = null;
            if (!m1367D(statusCode) && this.xW.wz != null) {
                this.xW.mHandler.post(new C05361(this, statusCode));
            }
        }

        public void m1378z(int i) {
            dq.xE.m1435b("ICastDeviceControllerListener.onDisconnected: %d", Integer.valueOf(i));
            this.xW.xM = false;
            this.xW.xF = null;
            if (i != 0) {
                this.xW.m618O(2);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.dq.a */
    private static final class C0541a implements ApplicationConnectionResult {
        private final String pz;
        private final Status vl;
        private final ApplicationMetadata yb;
        private final String yc;
        private final boolean yd;

        public C0541a(Status status) {
            this(status, null, null, null, false);
        }

        public C0541a(Status status, ApplicationMetadata applicationMetadata, String str, String str2, boolean z) {
            this.vl = status;
            this.yb = applicationMetadata;
            this.yc = str;
            this.pz = str2;
            this.yd = z;
        }

        public ApplicationMetadata getApplicationMetadata() {
            return this.yb;
        }

        public String getApplicationStatus() {
            return this.yc;
        }

        public String getSessionId() {
            return this.pz;
        }

        public Status getStatus() {
            return this.vl;
        }

        public boolean getWasLaunched() {
            return this.yd;
        }
    }

    static {
        xE = new du("CastClientImpl");
        xU = new Object();
        xV = new Object();
    }

    public dq(Context context, Looper looper, CastDevice castDevice, long j, Listener listener, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, (String[]) null);
        this.xG = castDevice;
        this.wz = listener;
        this.xJ = j;
        this.mHandler = new Handler(looper);
        this.xI = new HashMap();
        this.xM = false;
        this.xF = null;
        this.xK = null;
        this.xe = 0.0d;
        this.xf = false;
        this.xN = new AtomicLong(0);
        this.xR = new HashMap();
        this.xH = new C05401(this);
    }

    private void m1383a(String str, double d, boolean z) {
        boolean z2;
        if (dr.m1409a(str, this.xK)) {
            z2 = false;
        } else {
            this.xK = str;
            int i = 1;
        }
        if (this.wz != null && (r0 != 0 || this.xL)) {
            this.wz.onApplicationStatusChanged();
        }
        if (d != this.xe) {
            this.xe = d;
            z2 = true;
        } else {
            z2 = false;
        }
        if (z != this.xf) {
            this.xf = z;
            z2 = true;
        }
        xE.m1435b("hasChange=%b, mFirstStatusUpdate=%b", Boolean.valueOf(z2), Boolean.valueOf(this.xL));
        if (this.wz != null && (z2 || this.xL)) {
            this.wz.onVolumeChanged();
        }
        this.xL = false;
    }

    private void m1390d(C0182c<ApplicationConnectionResult> c0182c) {
        synchronized (xU) {
            if (this.xS != null) {
                this.xS.m196b(new C0541a(new Status(CastStatusCodes.CANCELED)));
            }
            this.xS = c0182c;
        }
    }

    private void db() throws IllegalStateException {
        if (!this.xM) {
            throw new IllegalStateException("not connected to a device");
        }
    }

    private void m1393f(C0182c<Status> c0182c) {
        synchronized (xV) {
            if (this.xT != null) {
                c0182c.m196b(new Status(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE));
                return;
            }
            this.xT = c0182c;
        }
    }

    public void m1396Q(String str) throws IllegalArgumentException, RemoteException {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("Channel namespace cannot be null or empty");
        }
        synchronized (this.xI) {
            MessageReceivedCallback messageReceivedCallback = (MessageReceivedCallback) this.xI.remove(str);
        }
        if (messageReceivedCallback != null) {
            try {
                ((ds) eb()).m1414T(str);
            } catch (Throwable e) {
                xE.m1434a(e, "Error unregistering namespace (%s): %s", str, e.getMessage());
            }
        }
    }

    public void m1397a(double d) throws IllegalArgumentException, IllegalStateException, RemoteException {
        if (Double.isInfinite(d) || Double.isNaN(d)) {
            throw new IllegalArgumentException("Volume cannot be " + d);
        }
        ((ds) eb()).m1415a(d, this.xe, this.xf);
    }

    protected void m1398a(int i, IBinder iBinder, Bundle bundle) {
        if (i == 0 || i == LocationStatusCodes.GEOFENCE_TOO_MANY_GEOFENCES) {
            this.xM = true;
            this.xL = true;
        } else {
            this.xM = false;
        }
        if (i == LocationStatusCodes.GEOFENCE_TOO_MANY_GEOFENCES) {
            this.xQ = new Bundle();
            this.xQ.putBoolean(Cast.EXTRA_APP_NO_LONGER_RUNNING, true);
            i = 0;
        }
        super.m619a(i, iBinder, bundle);
    }

    protected void m1399a(en enVar, C0556e c0556e) throws RemoteException {
        Bundle bundle = new Bundle();
        xE.m1435b("getServiceFromBroker(): mLastApplicationId=%s, mLastSessionId=%s", this.xO, this.xP);
        this.xG.putInBundle(bundle);
        bundle.putLong("com.google.android.gms.cast.EXTRA_CAST_FLAGS", this.xJ);
        if (this.xO != null) {
            bundle.putString("last_application_id", this.xO);
            if (this.xP != null) {
                bundle.putString("last_session_id", this.xP);
            }
        }
        enVar.m1493a((em) c0556e, (int) GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), this.xH.asBinder(), bundle);
    }

    public void m1400a(String str, MessageReceivedCallback messageReceivedCallback) throws IllegalArgumentException, IllegalStateException, RemoteException {
        if (TextUtils.isEmpty(str)) {
            throw new IllegalArgumentException("Channel namespace cannot be null or empty");
        }
        m1396Q(str);
        if (messageReceivedCallback != null) {
            synchronized (this.xI) {
                this.xI.put(str, messageReceivedCallback);
            }
            ((ds) eb()).m1413S(str);
        }
    }

    public void m1401a(String str, C0182c<Status> c0182c) throws IllegalStateException, RemoteException {
        m1393f((C0182c) c0182c);
        ((ds) eb()).m1412R(str);
    }

    public void m1402a(String str, String str2, C0182c<Status> c0182c) throws IllegalArgumentException, IllegalStateException, RemoteException {
        if (TextUtils.isEmpty(str2)) {
            throw new IllegalArgumentException("The message payload cannot be null or empty");
        } else if (str == null || str.length() > Cast.MAX_NAMESPACE_LENGTH) {
            throw new IllegalArgumentException("Invalid namespace length");
        } else if (str2.length() > Cast.MAX_MESSAGE_LENGTH) {
            throw new IllegalArgumentException("Message exceeds maximum size");
        } else {
            db();
            long incrementAndGet = this.xN.incrementAndGet();
            ((ds) eb()).m1416a(str, str2, incrementAndGet);
            this.xR.put(Long.valueOf(incrementAndGet), c0182c);
        }
    }

    public void m1403a(String str, boolean z, C0182c<ApplicationConnectionResult> c0182c) throws IllegalStateException, RemoteException {
        m1390d((C0182c) c0182c);
        ((ds) eb()).m1420e(str, z);
    }

    protected String aF() {
        return "com.google.android.gms.cast.service.BIND_CAST_DEVICE_CONTROLLER_SERVICE";
    }

    protected String aG() {
        return "com.google.android.gms.cast.internal.ICastDeviceController";
    }

    public void m1404b(String str, String str2, C0182c<ApplicationConnectionResult> c0182c) throws IllegalStateException, RemoteException {
        m1390d((C0182c) c0182c);
        ((ds) eb()).m1419e(str, str2);
    }

    public Bundle cY() {
        if (this.xQ == null) {
            return super.cY();
        }
        Bundle bundle = this.xQ;
        this.xQ = null;
        return bundle;
    }

    public void cZ() throws IllegalStateException, RemoteException {
        ((ds) eb()).cZ();
    }

    public double da() throws IllegalStateException {
        db();
        return this.xe;
    }

    public void disconnect() {
        try {
            if (isConnected()) {
                synchronized (this.xI) {
                    this.xI.clear();
                }
                ((ds) eb()).disconnect();
            }
        } catch (RemoteException e) {
            try {
                xE.m1435b("Error while disconnecting the controller interface: %s", e.getMessage());
            } catch (Throwable th) {
                super.disconnect();
            }
        }
        super.disconnect();
    }

    public void m1405e(C0182c<Status> c0182c) throws IllegalStateException, RemoteException {
        m1393f((C0182c) c0182c);
        ((ds) eb()).df();
    }

    public ApplicationMetadata getApplicationMetadata() throws IllegalStateException {
        db();
        return this.xF;
    }

    public String getApplicationStatus() throws IllegalStateException {
        db();
        return this.xK;
    }

    public boolean isMute() throws IllegalStateException {
        db();
        return this.xf;
    }

    protected /* synthetic */ IInterface m1406p(IBinder iBinder) {
        return m1408v(iBinder);
    }

    public void m1407t(boolean z) throws IllegalStateException, RemoteException {
        ((ds) eb()).m1418a(z, this.xe, this.xf);
    }

    protected ds m1408v(IBinder iBinder) {
        return C0543a.m1430w(iBinder);
    }
}
