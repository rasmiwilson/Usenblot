package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.internal.hx.C0719a;
import com.google.android.gms.location.LocationStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public class hw implements Creator<C0719a> {
    static void m2398a(C0719a c0719a, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m491a(parcel, 1, c0719a.gt(), false);
        C0265b.m501c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, c0719a.wj);
        C0265b.m491a(parcel, 2, c0719a.getTag(), false);
        C0265b.m491a(parcel, 3, c0719a.gH(), false);
        C0265b.m501c(parcel, 4, c0719a.gI());
        C0265b.m481D(parcel, p);
    }

    public C0719a aA(Parcel parcel) {
        int i = 0;
        String str = null;
        int o = C0264a.m466o(parcel);
        String str2 = null;
        String str3 = null;
        int i2 = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    str3 = C0264a.m463m(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new C0719a(i2, str3, str2, str, i);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public C0719a[] bu(int i) {
        return new C0719a[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aA(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bu(x0);
    }
}
