package com.google.android.gms.internal;

import android.location.Location;

public final class av implements au {
    public Location m986a(long j) {
        return null;
    }

    public void init() {
    }
}
