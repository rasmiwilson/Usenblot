package com.google.android.gms.internal;

public final class fo {
    public static boolean ab(int i) {
        return i >= 3200000;
    }
}
