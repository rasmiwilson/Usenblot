package com.google.android.gms.internal;

public interface br {
    void m1061S();

    void m1062T();
}
