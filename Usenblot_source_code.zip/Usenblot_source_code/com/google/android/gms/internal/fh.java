package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.fb.C0587a;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

public class fh extends fb implements SafeParcelable {
    public static final fi CREATOR;
    private final fe CC;
    private final Parcel CJ;
    private final int CK;
    private int CL;
    private int CM;
    private final String mClassName;
    private final int wj;

    static {
        CREATOR = new fi();
    }

    fh(int i, Parcel parcel, fe feVar) {
        this.wj = i;
        this.CJ = (Parcel) er.m1551f(parcel);
        this.CK = 2;
        this.CC = feVar;
        if (this.CC == null) {
            this.mClassName = null;
        } else {
            this.mClassName = this.CC.eD();
        }
        this.CL = 2;
    }

    private fh(SafeParcelable safeParcelable, fe feVar, String str) {
        this.wj = 1;
        this.CJ = Parcel.obtain();
        safeParcelable.writeToParcel(this.CJ, 0);
        this.CK = 1;
        this.CC = (fe) er.m1551f(feVar);
        this.mClassName = (String) er.m1551f(str);
        this.CL = 2;
    }

    public static <T extends fb & SafeParcelable> fh m1625a(T t) {
        String canonicalName = t.getClass().getCanonicalName();
        return new fh((SafeParcelable) t, m1631b(t), canonicalName);
    }

    private static void m1626a(fe feVar, fb fbVar) {
        Class cls = fbVar.getClass();
        if (!feVar.m1618b(cls)) {
            HashMap en = fbVar.en();
            feVar.m1617a(cls, fbVar.en());
            for (String str : en.keySet()) {
                C0587a c0587a = (C0587a) en.get(str);
                Class ev = c0587a.ev();
                if (ev != null) {
                    try {
                        m1626a(feVar, (fb) ev.newInstance());
                    } catch (Throwable e) {
                        throw new IllegalStateException("Could not instantiate an object of type " + c0587a.ev().getCanonicalName(), e);
                    } catch (Throwable e2) {
                        throw new IllegalStateException("Could not access object of type " + c0587a.ev().getCanonicalName(), e2);
                    }
                }
            }
        }
    }

    private void m1627a(StringBuilder stringBuilder, int i, Object obj) {
        switch (i) {
            case Base64Encoder.DEFAULT /*0*/:
            case Base64Encoder.NO_PADDING /*1*/:
            case Base64Encoder.URL_SAFE /*2*/:
            case Error.BAD_CVC /*3*/:
            case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
            case Error.DECLINED /*5*/:
            case Error.OTHER /*6*/:
                stringBuilder.append(obj);
            case Error.AVS_DECLINE /*7*/:
                stringBuilder.append("\"").append(fp.ap(obj.toString())).append("\"");
            case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                stringBuilder.append("\"").append(fk.m1646d((byte[]) obj)).append("\"");
            case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                stringBuilder.append("\"").append(fk.m1647e((byte[]) obj));
                stringBuilder.append("\"");
            case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                fq.m1650a(stringBuilder, (HashMap) obj);
            case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                throw new IllegalArgumentException("Method does not accept concrete type.");
            default:
                throw new IllegalArgumentException("Unknown type = " + i);
        }
    }

    private void m1628a(StringBuilder stringBuilder, C0587a<?, ?> c0587a, Parcel parcel, int i) {
        switch (c0587a.em()) {
            case Base64Encoder.DEFAULT /*0*/:
                m1633b(stringBuilder, (C0587a) c0587a, m1606a(c0587a, Integer.valueOf(C0264a.m457g(parcel, i))));
            case Base64Encoder.NO_PADDING /*1*/:
                m1633b(stringBuilder, (C0587a) c0587a, m1606a(c0587a, C0264a.m459i(parcel, i)));
            case Base64Encoder.URL_SAFE /*2*/:
                m1633b(stringBuilder, (C0587a) c0587a, m1606a(c0587a, Long.valueOf(C0264a.m458h(parcel, i))));
            case Error.BAD_CVC /*3*/:
                m1633b(stringBuilder, (C0587a) c0587a, m1606a(c0587a, Float.valueOf(C0264a.m460j(parcel, i))));
            case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                m1633b(stringBuilder, (C0587a) c0587a, m1606a(c0587a, Double.valueOf(C0264a.m461k(parcel, i))));
            case Error.DECLINED /*5*/:
                m1633b(stringBuilder, (C0587a) c0587a, m1606a(c0587a, C0264a.m462l(parcel, i)));
            case Error.OTHER /*6*/:
                m1633b(stringBuilder, (C0587a) c0587a, m1606a(c0587a, Boolean.valueOf(C0264a.m453c(parcel, i))));
            case Error.AVS_DECLINE /*7*/:
                m1633b(stringBuilder, (C0587a) c0587a, m1606a(c0587a, C0264a.m463m(parcel, i)));
            case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
            case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                m1633b(stringBuilder, (C0587a) c0587a, m1606a(c0587a, C0264a.m468p(parcel, i)));
            case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                m1633b(stringBuilder, (C0587a) c0587a, m1606a(c0587a, m1635c(C0264a.m467o(parcel, i))));
            case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                throw new IllegalArgumentException("Method does not accept concrete type.");
            default:
                throw new IllegalArgumentException("Unknown field out type = " + c0587a.em());
        }
    }

    private void m1629a(StringBuilder stringBuilder, String str, C0587a<?, ?> c0587a, Parcel parcel, int i) {
        stringBuilder.append("\"").append(str).append("\":");
        if (c0587a.ex()) {
            m1628a(stringBuilder, c0587a, parcel, i);
        } else {
            m1632b(stringBuilder, c0587a, parcel, i);
        }
    }

    private void m1630a(StringBuilder stringBuilder, HashMap<String, C0587a<?, ?>> hashMap, Parcel parcel) {
        HashMap c = m1636c((HashMap) hashMap);
        stringBuilder.append('{');
        int o = C0264a.m466o(parcel);
        Object obj = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            Entry entry = (Entry) c.get(Integer.valueOf(C0264a.m444S(n)));
            if (entry != null) {
                if (obj != null) {
                    stringBuilder.append(",");
                }
                m1629a(stringBuilder, (String) entry.getKey(), (C0587a) entry.getValue(), parcel, n);
                obj = 1;
            }
        }
        if (parcel.dataPosition() != o) {
            throw new C0263a("Overread allowed size end=" + o, parcel);
        }
        stringBuilder.append('}');
    }

    private static fe m1631b(fb fbVar) {
        fe feVar = new fe(fbVar.getClass());
        m1626a(feVar, fbVar);
        feVar.eB();
        feVar.eA();
        return feVar;
    }

    private void m1632b(StringBuilder stringBuilder, C0587a<?, ?> c0587a, Parcel parcel, int i) {
        if (c0587a.es()) {
            stringBuilder.append("[");
            switch (c0587a.em()) {
                case Base64Encoder.DEFAULT /*0*/:
                    fj.m1641a(stringBuilder, C0264a.m470r(parcel, i));
                    break;
                case Base64Encoder.NO_PADDING /*1*/:
                    fj.m1643a(stringBuilder, C0264a.m472t(parcel, i));
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    fj.m1642a(stringBuilder, C0264a.m471s(parcel, i));
                    break;
                case Error.BAD_CVC /*3*/:
                    fj.m1640a(stringBuilder, C0264a.m473u(parcel, i));
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    fj.m1639a(stringBuilder, C0264a.m474v(parcel, i));
                    break;
                case Error.DECLINED /*5*/:
                    fj.m1643a(stringBuilder, C0264a.m475w(parcel, i));
                    break;
                case Error.OTHER /*6*/:
                    fj.m1645a(stringBuilder, C0264a.m469q(parcel, i));
                    break;
                case Error.AVS_DECLINE /*7*/:
                    fj.m1644a(stringBuilder, C0264a.m476x(parcel, i));
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                    throw new UnsupportedOperationException("List of type BASE64, BASE64_URL_SAFE, or STRING_MAP is not supported");
                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                    Parcel[] A = C0264a.m443A(parcel, i);
                    int length = A.length;
                    for (int i2 = 0; i2 < length; i2++) {
                        if (i2 > 0) {
                            stringBuilder.append(",");
                        }
                        A[i2].setDataPosition(0);
                        m1630a(stringBuilder, c0587a.ez(), A[i2]);
                    }
                    break;
                default:
                    throw new IllegalStateException("Unknown field type out.");
            }
            stringBuilder.append("]");
            return;
        }
        switch (c0587a.em()) {
            case Base64Encoder.DEFAULT /*0*/:
                stringBuilder.append(C0264a.m457g(parcel, i));
            case Base64Encoder.NO_PADDING /*1*/:
                stringBuilder.append(C0264a.m459i(parcel, i));
            case Base64Encoder.URL_SAFE /*2*/:
                stringBuilder.append(C0264a.m458h(parcel, i));
            case Error.BAD_CVC /*3*/:
                stringBuilder.append(C0264a.m460j(parcel, i));
            case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                stringBuilder.append(C0264a.m461k(parcel, i));
            case Error.DECLINED /*5*/:
                stringBuilder.append(C0264a.m462l(parcel, i));
            case Error.OTHER /*6*/:
                stringBuilder.append(C0264a.m453c(parcel, i));
            case Error.AVS_DECLINE /*7*/:
                stringBuilder.append("\"").append(fp.ap(C0264a.m463m(parcel, i))).append("\"");
            case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                stringBuilder.append("\"").append(fk.m1646d(C0264a.m468p(parcel, i))).append("\"");
            case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                stringBuilder.append("\"").append(fk.m1647e(C0264a.m468p(parcel, i)));
                stringBuilder.append("\"");
            case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                Bundle o = C0264a.m467o(parcel, i);
                Set<String> keySet = o.keySet();
                keySet.size();
                stringBuilder.append("{");
                int i3 = 1;
                for (String str : keySet) {
                    if (i3 == 0) {
                        stringBuilder.append(",");
                    }
                    stringBuilder.append("\"").append(str).append("\"");
                    stringBuilder.append(":");
                    stringBuilder.append("\"").append(fp.ap(o.getString(str))).append("\"");
                    i3 = 0;
                }
                stringBuilder.append("}");
            case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                Parcel z = C0264a.m478z(parcel, i);
                z.setDataPosition(0);
                m1630a(stringBuilder, c0587a.ez(), z);
            default:
                throw new IllegalStateException("Unknown field type out");
        }
    }

    private void m1633b(StringBuilder stringBuilder, C0587a<?, ?> c0587a, Object obj) {
        if (c0587a.er()) {
            m1634b(stringBuilder, (C0587a) c0587a, (ArrayList) obj);
        } else {
            m1627a(stringBuilder, c0587a.el(), obj);
        }
    }

    private void m1634b(StringBuilder stringBuilder, C0587a<?, ?> c0587a, ArrayList<?> arrayList) {
        stringBuilder.append("[");
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (i != 0) {
                stringBuilder.append(",");
            }
            m1627a(stringBuilder, c0587a.el(), arrayList.get(i));
        }
        stringBuilder.append("]");
    }

    public static HashMap<String, String> m1635c(Bundle bundle) {
        HashMap<String, String> hashMap = new HashMap();
        for (String str : bundle.keySet()) {
            hashMap.put(str, bundle.getString(str));
        }
        return hashMap;
    }

    private static HashMap<Integer, Entry<String, C0587a<?, ?>>> m1636c(HashMap<String, C0587a<?, ?>> hashMap) {
        HashMap<Integer, Entry<String, C0587a<?, ?>>> hashMap2 = new HashMap();
        for (Entry entry : hashMap.entrySet()) {
            hashMap2.put(Integer.valueOf(((C0587a) entry.getValue()).eu()), entry);
        }
        return hashMap2;
    }

    protected Object ak(String str) {
        throw new UnsupportedOperationException("Converting to JSON does not require this method.");
    }

    protected boolean al(String str) {
        throw new UnsupportedOperationException("Converting to JSON does not require this method.");
    }

    public int describeContents() {
        fi fiVar = CREATOR;
        return 0;
    }

    public Parcel eF() {
        switch (this.CL) {
            case Base64Encoder.DEFAULT /*0*/:
                this.CM = C0265b.m503p(this.CJ);
                C0265b.m481D(this.CJ, this.CM);
                this.CL = 2;
                break;
            case Base64Encoder.NO_PADDING /*1*/:
                C0265b.m481D(this.CJ, this.CM);
                this.CL = 2;
                break;
        }
        return this.CJ;
    }

    fe eG() {
        switch (this.CK) {
            case Base64Encoder.DEFAULT /*0*/:
                return null;
            case Base64Encoder.NO_PADDING /*1*/:
                return this.CC;
            case Base64Encoder.URL_SAFE /*2*/:
                return this.CC;
            default:
                throw new IllegalStateException("Invalid creation type: " + this.CK);
        }
    }

    public HashMap<String, C0587a<?, ?>> en() {
        return this.CC == null ? null : this.CC.ao(this.mClassName);
    }

    public int getVersionCode() {
        return this.wj;
    }

    public String toString() {
        er.m1549b(this.CC, (Object) "Cannot convert to JSON on client side.");
        Parcel eF = eF();
        eF.setDataPosition(0);
        StringBuilder stringBuilder = new StringBuilder(100);
        m1630a(stringBuilder, this.CC.ao(this.mClassName), eF);
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel out, int flags) {
        fi fiVar = CREATOR;
        fi.m1637a(this, out, flags);
    }
}
