package com.google.android.gms.internal;

import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import com.appsgeyser.sdk.configuration.Constants;
import com.google.ads.AdSize;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value.Escaping;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.io.IOException;

/* renamed from: com.google.android.gms.internal.d */
public interface C0508d {

    /* renamed from: com.google.android.gms.internal.d.a */
    public static final class C0507a extends ka<C0507a> {
        private static volatile C0507a[] fX;
        public String fY;
        public C0507a[] fZ;
        public C0507a[] ga;
        public C0507a[] gb;
        public String gc;
        public String gd;
        public long ge;
        public boolean gf;
        public C0507a[] gg;
        public int[] gh;
        public boolean gi;
        public int type;

        public C0507a() {
            m1265s();
        }

        public static C0507a[] m1260r() {
            if (fX == null) {
                synchronized (kc.aah) {
                    if (fX == null) {
                        fX = new C0507a[0];
                    }
                }
            }
            return fX;
        }

        public void m1261a(jz jzVar) throws IOException {
            int i = 0;
            jzVar.m2585f(1, this.type);
            if (!this.fY.equals(Constants.PUBLISHER_NAME)) {
                jzVar.m2580b(2, this.fY);
            }
            if (this.fZ != null && this.fZ.length > 0) {
                for (ke keVar : this.fZ) {
                    if (keVar != null) {
                        jzVar.m2576a(3, keVar);
                    }
                }
            }
            if (this.ga != null && this.ga.length > 0) {
                for (ke keVar2 : this.ga) {
                    if (keVar2 != null) {
                        jzVar.m2576a(4, keVar2);
                    }
                }
            }
            if (this.gb != null && this.gb.length > 0) {
                for (ke keVar22 : this.gb) {
                    if (keVar22 != null) {
                        jzVar.m2576a(5, keVar22);
                    }
                }
            }
            if (!this.gc.equals(Constants.PUBLISHER_NAME)) {
                jzVar.m2580b(6, this.gc);
            }
            if (!this.gd.equals(Constants.PUBLISHER_NAME)) {
                jzVar.m2580b(7, this.gd);
            }
            if (this.ge != 0) {
                jzVar.m2579b(8, this.ge);
            }
            if (this.gi) {
                jzVar.m2577a(9, this.gi);
            }
            if (this.gh != null && this.gh.length > 0) {
                for (int f : this.gh) {
                    jzVar.m2585f(10, f);
                }
            }
            if (this.gg != null && this.gg.length > 0) {
                while (i < this.gg.length) {
                    ke keVar3 = this.gg[i];
                    if (keVar3 != null) {
                        jzVar.m2576a(11, keVar3);
                    }
                    i++;
                }
            }
            if (this.gf) {
                jzVar.m2577a(12, this.gf);
            }
            super.m1098a(jzVar);
        }

        public /* synthetic */ ke m1262b(jy jyVar) throws IOException {
            return m1264l(jyVar);
        }

        public int m1263c() {
            int i;
            int i2 = 0;
            int c = super.m1100c() + jz.m2569g(1, this.type);
            if (!this.fY.equals(Constants.PUBLISHER_NAME)) {
                c += jz.m2570g(2, this.fY);
            }
            if (this.fZ != null && this.fZ.length > 0) {
                i = c;
                for (ke keVar : this.fZ) {
                    if (keVar != null) {
                        i += jz.m2562b(3, keVar);
                    }
                }
                c = i;
            }
            if (this.ga != null && this.ga.length > 0) {
                i = c;
                for (ke keVar2 : this.ga) {
                    if (keVar2 != null) {
                        i += jz.m2562b(4, keVar2);
                    }
                }
                c = i;
            }
            if (this.gb != null && this.gb.length > 0) {
                i = c;
                for (ke keVar22 : this.gb) {
                    if (keVar22 != null) {
                        i += jz.m2562b(5, keVar22);
                    }
                }
                c = i;
            }
            if (!this.gc.equals(Constants.PUBLISHER_NAME)) {
                c += jz.m2570g(6, this.gc);
            }
            if (!this.gd.equals(Constants.PUBLISHER_NAME)) {
                c += jz.m2570g(7, this.gd);
            }
            if (this.ge != 0) {
                c += jz.m2566d(8, this.ge);
            }
            if (this.gi) {
                c += jz.m2563b(9, this.gi);
            }
            if (this.gh != null && this.gh.length > 0) {
                int i3 = 0;
                for (int cC : this.gh) {
                    i3 += jz.cC(cC);
                }
                c = (c + i3) + (this.gh.length * 1);
            }
            if (this.gg != null && this.gg.length > 0) {
                while (i2 < this.gg.length) {
                    ke keVar3 = this.gg[i2];
                    if (keVar3 != null) {
                        c += jz.m2562b(11, keVar3);
                    }
                    i2++;
                }
            }
            if (this.gf) {
                c += jz.m2563b(12, this.gf);
            }
            this.DY = c;
            return c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0507a)) {
                return false;
            }
            C0507a c0507a = (C0507a) o;
            if (this.type != c0507a.type) {
                return false;
            }
            if (this.fY == null) {
                if (c0507a.fY != null) {
                    return false;
                }
            } else if (!this.fY.equals(c0507a.fY)) {
                return false;
            }
            if (!kc.equals(this.fZ, c0507a.fZ) || !kc.equals(this.ga, c0507a.ga) || !kc.equals(this.gb, c0507a.gb)) {
                return false;
            }
            if (this.gc == null) {
                if (c0507a.gc != null) {
                    return false;
                }
            } else if (!this.gc.equals(c0507a.gc)) {
                return false;
            }
            if (this.gd == null) {
                if (c0507a.gd != null) {
                    return false;
                }
            } else if (!this.gd.equals(c0507a.gd)) {
                return false;
            }
            return (this.ge == c0507a.ge && this.gf == c0507a.gf && kc.equals(this.gg, c0507a.gg) && kc.equals(this.gh, c0507a.gh) && this.gi == c0507a.gi) ? (this.aae == null || this.aae.isEmpty()) ? c0507a.aae == null || c0507a.aae.isEmpty() : this.aae.equals(c0507a.aae) : false;
        }

        public int hashCode() {
            int i = 1231;
            int i2 = 0;
            int hashCode = ((((((this.gf ? 1231 : 1237) + (((((this.gd == null ? 0 : this.gd.hashCode()) + (((this.gc == null ? 0 : this.gc.hashCode()) + (((((((((this.fY == null ? 0 : this.fY.hashCode()) + ((this.type + 527) * 31)) * 31) + kc.hashCode(this.fZ)) * 31) + kc.hashCode(this.ga)) * 31) + kc.hashCode(this.gb)) * 31)) * 31)) * 31) + ((int) (this.ge ^ (this.ge >>> 32)))) * 31)) * 31) + kc.hashCode(this.gg)) * 31) + kc.hashCode(this.gh)) * 31;
            if (!this.gi) {
                i = 1237;
            }
            hashCode = (hashCode + i) * 31;
            if (!(this.aae == null || this.aae.isEmpty())) {
                i2 = this.aae.hashCode();
            }
            return hashCode + i2;
        }

        public C0507a m1264l(jy jyVar) throws IOException {
            while (true) {
                int ky = jyVar.ky();
                int c;
                Object obj;
                int i;
                switch (ky) {
                    case Base64Encoder.DEFAULT /*0*/:
                        break;
                    case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                        ky = jyVar.kB();
                        switch (ky) {
                            case Base64Encoder.NO_PADDING /*1*/:
                            case Base64Encoder.URL_SAFE /*2*/:
                            case Error.BAD_CVC /*3*/:
                            case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                            case Error.DECLINED /*5*/:
                            case Error.OTHER /*6*/:
                            case Error.AVS_DECLINE /*7*/:
                            case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                                this.type = ky;
                                break;
                            default:
                                continue;
                        }
                    case 18:
                        this.fY = jyVar.readString();
                        continue;
                    case 26:
                        c = kh.m2601c(jyVar, 26);
                        ky = this.fZ == null ? 0 : this.fZ.length;
                        obj = new C0507a[(c + ky)];
                        if (ky != 0) {
                            System.arraycopy(this.fZ, 0, obj, 0, ky);
                        }
                        while (ky < obj.length - 1) {
                            obj[ky] = new C0507a();
                            jyVar.m2554a(obj[ky]);
                            jyVar.ky();
                            ky++;
                        }
                        obj[ky] = new C0507a();
                        jyVar.m2554a(obj[ky]);
                        this.fZ = obj;
                        continue;
                    case 34:
                        c = kh.m2601c(jyVar, 34);
                        ky = this.ga == null ? 0 : this.ga.length;
                        obj = new C0507a[(c + ky)];
                        if (ky != 0) {
                            System.arraycopy(this.ga, 0, obj, 0, ky);
                        }
                        while (ky < obj.length - 1) {
                            obj[ky] = new C0507a();
                            jyVar.m2554a(obj[ky]);
                            jyVar.ky();
                            ky++;
                        }
                        obj[ky] = new C0507a();
                        jyVar.m2554a(obj[ky]);
                        this.ga = obj;
                        continue;
                    case 42:
                        c = kh.m2601c(jyVar, 42);
                        ky = this.gb == null ? 0 : this.gb.length;
                        obj = new C0507a[(c + ky)];
                        if (ky != 0) {
                            System.arraycopy(this.gb, 0, obj, 0, ky);
                        }
                        while (ky < obj.length - 1) {
                            obj[ky] = new C0507a();
                            jyVar.m2554a(obj[ky]);
                            jyVar.ky();
                            ky++;
                        }
                        obj[ky] = new C0507a();
                        jyVar.m2554a(obj[ky]);
                        this.gb = obj;
                        continue;
                    case AdSize.PORTRAIT_AD_HEIGHT /*50*/:
                        this.gc = jyVar.readString();
                        continue;
                    case 58:
                        this.gd = jyVar.readString();
                        continue;
                    case AccessibilityNodeInfoCompat.ACTION_ACCESSIBILITY_FOCUS /*64*/:
                        this.ge = jyVar.kA();
                        continue;
                    case 72:
                        this.gi = jyVar.kC();
                        continue;
                    case 80:
                        int c2 = kh.m2601c(jyVar, 80);
                        Object obj2 = new int[c2];
                        i = 0;
                        c = 0;
                        while (i < c2) {
                            if (i != 0) {
                                jyVar.ky();
                            }
                            int kB = jyVar.kB();
                            switch (kB) {
                                case Base64Encoder.NO_PADDING /*1*/:
                                case Base64Encoder.URL_SAFE /*2*/:
                                case Error.BAD_CVC /*3*/:
                                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                                case Error.DECLINED /*5*/:
                                case Error.OTHER /*6*/:
                                case Error.AVS_DECLINE /*7*/:
                                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                                case CommonStatusCodes.DATE_INVALID /*12*/:
                                case CommonStatusCodes.ERROR /*13*/:
                                case GamesStatusCodes.STATUS_INTERRUPTED /*14*/:
                                case GamesStatusCodes.STATUS_TIMEOUT /*15*/:
                                case Escaping.CONVERT_JS_VALUE_TO_EXPRESSION /*16*/:
                                case Escaping.TEXT /*17*/:
                                    ky = c + 1;
                                    obj2[c] = kB;
                                    break;
                                default:
                                    ky = c;
                                    break;
                            }
                            i++;
                            c = ky;
                        }
                        if (c != 0) {
                            ky = this.gh == null ? 0 : this.gh.length;
                            if (ky != 0 || c != obj2.length) {
                                Object obj3 = new int[(ky + c)];
                                if (ky != 0) {
                                    System.arraycopy(this.gh, 0, obj3, 0, ky);
                                }
                                System.arraycopy(obj2, 0, obj3, ky, c);
                                this.gh = obj3;
                                break;
                            }
                            this.gh = obj2;
                            break;
                        }
                        continue;
                    case 82:
                        i = jyVar.cw(jyVar.kE());
                        c = jyVar.getPosition();
                        ky = 0;
                        while (jyVar.kJ() > 0) {
                            switch (jyVar.kB()) {
                                case Base64Encoder.NO_PADDING /*1*/:
                                case Base64Encoder.URL_SAFE /*2*/:
                                case Error.BAD_CVC /*3*/:
                                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                                case Error.DECLINED /*5*/:
                                case Error.OTHER /*6*/:
                                case Error.AVS_DECLINE /*7*/:
                                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                                case CommonStatusCodes.DATE_INVALID /*12*/:
                                case CommonStatusCodes.ERROR /*13*/:
                                case GamesStatusCodes.STATUS_INTERRUPTED /*14*/:
                                case GamesStatusCodes.STATUS_TIMEOUT /*15*/:
                                case Escaping.CONVERT_JS_VALUE_TO_EXPRESSION /*16*/:
                                case Escaping.TEXT /*17*/:
                                    ky++;
                                    break;
                                default:
                                    break;
                            }
                        }
                        if (ky != 0) {
                            jyVar.cy(c);
                            c = this.gh == null ? 0 : this.gh.length;
                            Object obj4 = new int[(ky + c)];
                            if (c != 0) {
                                System.arraycopy(this.gh, 0, obj4, 0, c);
                            }
                            while (jyVar.kJ() > 0) {
                                int kB2 = jyVar.kB();
                                switch (kB2) {
                                    case Base64Encoder.NO_PADDING /*1*/:
                                    case Base64Encoder.URL_SAFE /*2*/:
                                    case Error.BAD_CVC /*3*/:
                                    case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                                    case Error.DECLINED /*5*/:
                                    case Error.OTHER /*6*/:
                                    case Error.AVS_DECLINE /*7*/:
                                    case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                                    case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                                    case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                                    case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                                    case CommonStatusCodes.DATE_INVALID /*12*/:
                                    case CommonStatusCodes.ERROR /*13*/:
                                    case GamesStatusCodes.STATUS_INTERRUPTED /*14*/:
                                    case GamesStatusCodes.STATUS_TIMEOUT /*15*/:
                                    case Escaping.CONVERT_JS_VALUE_TO_EXPRESSION /*16*/:
                                    case Escaping.TEXT /*17*/:
                                        ky = c + 1;
                                        obj4[c] = kB2;
                                        c = ky;
                                        break;
                                    default:
                                        break;
                                }
                            }
                            this.gh = obj4;
                        }
                        jyVar.cx(i);
                        continue;
                    case AdSize.LARGE_AD_HEIGHT /*90*/:
                        c = kh.m2601c(jyVar, 90);
                        ky = this.gg == null ? 0 : this.gg.length;
                        obj = new C0507a[(c + ky)];
                        if (ky != 0) {
                            System.arraycopy(this.gg, 0, obj, 0, ky);
                        }
                        while (ky < obj.length - 1) {
                            obj[ky] = new C0507a();
                            jyVar.m2554a(obj[ky]);
                            jyVar.ky();
                            ky++;
                        }
                        obj[ky] = new C0507a();
                        jyVar.m2554a(obj[ky]);
                        this.gg = obj;
                        continue;
                    case 96:
                        this.gf = jyVar.kC();
                        continue;
                    default:
                        if (!m1099a(jyVar, ky)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }

        public C0507a m1265s() {
            this.type = 1;
            this.fY = Constants.PUBLISHER_NAME;
            this.fZ = C0507a.m1260r();
            this.ga = C0507a.m1260r();
            this.gb = C0507a.m1260r();
            this.gc = Constants.PUBLISHER_NAME;
            this.gd = Constants.PUBLISHER_NAME;
            this.ge = 0;
            this.gf = false;
            this.gg = C0507a.m1260r();
            this.gh = kh.aaj;
            this.gi = false;
            this.aae = null;
            this.DY = -1;
            return this;
        }
    }
}
