package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public class ac implements Creator<ab> {
    static void m918a(ab abVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, abVar.versionCode);
        C0265b.m491a(parcel, 2, abVar.ln, false);
        C0265b.m501c(parcel, 3, abVar.height);
        C0265b.m501c(parcel, 4, abVar.heightPixels);
        C0265b.m494a(parcel, 5, abVar.lo);
        C0265b.m501c(parcel, 6, abVar.width);
        C0265b.m501c(parcel, 7, abVar.widthPixels);
        C0265b.m496a(parcel, 8, abVar.lp, i, false);
        C0265b.m481D(parcel, p);
    }

    public ab m919b(Parcel parcel) {
        ab[] abVarArr = null;
        int i = 0;
        int o = C0264a.m466o(parcel);
        int i2 = 0;
        boolean z = false;
        int i3 = 0;
        int i4 = 0;
        String str = null;
        int i5 = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i5 = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    i4 = C0264a.m457g(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    i3 = C0264a.m457g(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    z = C0264a.m453c(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    abVarArr = (ab[]) C0264a.m451b(parcel, n, ab.CREATOR);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new ab(i5, str, i4, i3, z, i2, i, abVarArr);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public ab[] m920c(int i) {
        return new ab[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m919b(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m920c(x0);
    }
}
