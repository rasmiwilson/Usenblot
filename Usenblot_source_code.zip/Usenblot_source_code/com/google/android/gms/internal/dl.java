package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.appstate.AppStateBuffer;
import com.google.android.gms.appstate.AppStateManager.StateConflictResult;
import com.google.android.gms.appstate.AppStateManager.StateDeletedResult;
import com.google.android.gms.appstate.AppStateManager.StateListResult;
import com.google.android.gms.appstate.AppStateManager.StateLoadedResult;
import com.google.android.gms.appstate.AppStateManager.StateResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.dn.C0534a;
import com.google.android.gms.internal.eh.C0523b;
import com.google.android.gms.internal.eh.C0526d;
import com.google.android.gms.internal.eh.C0556e;

public final class dl extends eh<dn> {
    private final String vi;

    /* renamed from: com.google.android.gms.internal.dl.a */
    final class C0522a extends dk {
        private final C0182c<StateDeletedResult> vj;
        final /* synthetic */ dl vk;

        public C0522a(dl dlVar, C0182c<StateDeletedResult> c0182c) {
            this.vk = dlVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Result holder must not be null");
        }

        public void m1314b(int i, int i2) {
            this.vk.m620a(new C0524b(this.vk, this.vj, new Status(i), i2));
        }
    }

    /* renamed from: com.google.android.gms.internal.dl.b */
    final class C0524b extends C0523b<C0182c<StateDeletedResult>> implements StateDeletedResult {
        final /* synthetic */ dl vk;
        private final Status vl;
        private final int vm;

        public C0524b(dl dlVar, C0182c<StateDeletedResult> c0182c, Status status, int i) {
            this.vk = dlVar;
            super(dlVar, c0182c);
            this.vl = status;
            this.vm = i;
        }

        public /* synthetic */ void m1316a(Object obj) {
            m1317c((C0182c) obj);
        }

        public void m1317c(C0182c<StateDeletedResult> c0182c) {
            c0182c.m196b(this);
        }

        protected void cP() {
        }

        public int getStateKey() {
            return this.vm;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    /* renamed from: com.google.android.gms.internal.dl.c */
    final class C0525c extends dk {
        private final C0182c<StateListResult> vj;
        final /* synthetic */ dl vk;

        public C0525c(dl dlVar, C0182c<StateListResult> c0182c) {
            this.vk = dlVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Result holder must not be null");
        }

        public void m1318a(DataHolder dataHolder) {
            this.vk.m620a(new C0527d(this.vk, this.vj, new Status(dataHolder.getStatusCode()), dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.internal.dl.d */
    final class C0527d extends C0526d<C0182c<StateListResult>> implements StateListResult {
        final /* synthetic */ dl vk;
        private final Status vl;
        private final AppStateBuffer vn;

        public C0527d(dl dlVar, C0182c<StateListResult> c0182c, Status status, DataHolder dataHolder) {
            this.vk = dlVar;
            super(dlVar, c0182c, dataHolder);
            this.vl = status;
            this.vn = new AppStateBuffer(dataHolder);
        }

        public void m1321a(C0182c<StateListResult> c0182c, DataHolder dataHolder) {
            c0182c.m196b(this);
        }

        public AppStateBuffer getStateBuffer() {
            return this.vn;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    /* renamed from: com.google.android.gms.internal.dl.e */
    final class C0528e extends dk {
        private final C0182c<StateResult> vj;
        final /* synthetic */ dl vk;

        public C0528e(dl dlVar, C0182c<StateResult> c0182c) {
            this.vk = dlVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Result holder must not be null");
        }

        public void m1323a(int i, DataHolder dataHolder) {
            this.vk.m620a(new C0529f(this.vk, this.vj, i, dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.internal.dl.f */
    final class C0529f extends C0526d<C0182c<StateResult>> implements StateConflictResult, StateLoadedResult, StateResult {
        final /* synthetic */ dl vk;
        private final Status vl;
        private final int vm;
        private final AppStateBuffer vn;

        public C0529f(dl dlVar, C0182c<StateResult> c0182c, int i, DataHolder dataHolder) {
            this.vk = dlVar;
            super(dlVar, c0182c, dataHolder);
            this.vm = i;
            this.vl = new Status(dataHolder.getStatusCode());
            this.vn = new AppStateBuffer(dataHolder);
        }

        private boolean cQ() {
            return this.vl.getStatusCode() == GamesStatusCodes.STATUS_REQUEST_UPDATE_PARTIAL_SUCCESS;
        }

        public void m1324a(C0182c<StateResult> c0182c, DataHolder dataHolder) {
            c0182c.m196b(this);
        }

        public StateConflictResult getConflictResult() {
            return cQ() ? this : null;
        }

        public StateLoadedResult getLoadedResult() {
            return cQ() ? null : this;
        }

        public byte[] getLocalData() {
            return this.vn.getCount() == 0 ? null : this.vn.get(0).getLocalData();
        }

        public String getResolvedVersion() {
            return this.vn.getCount() == 0 ? null : this.vn.get(0).getConflictVersion();
        }

        public byte[] getServerData() {
            return this.vn.getCount() == 0 ? null : this.vn.get(0).getConflictData();
        }

        public int getStateKey() {
            return this.vm;
        }

        public Status getStatus() {
            return this.vl;
        }

        public void release() {
            this.vn.close();
        }
    }

    /* renamed from: com.google.android.gms.internal.dl.g */
    final class C0530g extends dk {
        C0182c<Status> vj;
        final /* synthetic */ dl vk;

        public C0530g(dl dlVar, C0182c<Status> c0182c) {
            this.vk = dlVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void cM() {
            this.vk.m620a(new C0531h(this.vk, this.vj, new Status(0)));
        }
    }

    /* renamed from: com.google.android.gms.internal.dl.h */
    final class C0531h extends C0523b<C0182c<Status>> {
        final /* synthetic */ dl vk;
        private final Status vl;

        public C0531h(dl dlVar, C0182c<Status> c0182c, Status status) {
            this.vk = dlVar;
            super(dlVar, c0182c);
            this.vl = status;
        }

        public /* synthetic */ void m1326a(Object obj) {
            m1327c((C0182c) obj);
        }

        public void m1327c(C0182c<Status> c0182c) {
            c0182c.m196b(this.vl);
        }

        protected void cP() {
        }
    }

    public dl(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String str, String[] strArr) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, strArr);
        this.vi = (String) er.m1551f(str);
    }

    public void m1328a(C0182c<StateListResult> c0182c) {
        try {
            ((dn) eb()).m1342a(new C0525c(this, c0182c));
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m1329a(C0182c<StateDeletedResult> c0182c, int i) {
        try {
            ((dn) eb()).m1347b(new C0522a(this, c0182c), i);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m1330a(C0182c<StateResult> c0182c, int i, String str, byte[] bArr) {
        try {
            ((dn) eb()).m1344a(new C0528e(this, c0182c), i, str, bArr);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m1331a(C0182c<StateResult> c0182c, int i, byte[] bArr) {
        if (c0182c == null) {
            dm dmVar = null;
        } else {
            Object c0528e = new C0528e(this, c0182c);
        }
        try {
            ((dn) eb()).m1345a(dmVar, i, bArr);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    protected void m1332a(en enVar, C0556e c0556e) throws RemoteException {
        enVar.m1494a((em) c0556e, (int) GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), this.vi, ea());
    }

    protected String aF() {
        return "com.google.android.gms.appstate.service.START";
    }

    protected String aG() {
        return "com.google.android.gms.appstate.internal.IAppStateService";
    }

    public void m1333b(C0182c<Status> c0182c) {
        try {
            ((dn) eb()).m1346b(new C0530g(this, c0182c));
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    public void m1334b(C0182c<StateResult> c0182c, int i) {
        try {
            ((dn) eb()).m1343a(new C0528e(this, c0182c), i);
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
        }
    }

    protected void m1335b(String... strArr) {
        boolean z = false;
        for (String equals : strArr) {
            if (equals.equals(Scopes.APP_STATE)) {
                z = true;
            }
        }
        er.m1547a(z, String.format("App State APIs requires %s to function.", new Object[]{Scopes.APP_STATE}));
    }

    public int cN() {
        try {
            return ((dn) eb()).cN();
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
            return 2;
        }
    }

    public int cO() {
        try {
            return ((dn) eb()).cO();
        } catch (RemoteException e) {
            Log.w("AppStateClient", "service died");
            return 2;
        }
    }

    protected /* synthetic */ IInterface m1336p(IBinder iBinder) {
        return m1337s(iBinder);
    }

    protected dn m1337s(IBinder iBinder) {
        return C0534a.m1356u(iBinder);
    }
}
