package com.google.android.gms.internal;

import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public final class gr {
    public static boolean isValid(int result) {
        switch (result) {
            case Base64Encoder.DEFAULT /*0*/:
            case Base64Encoder.NO_PADDING /*1*/:
            case Base64Encoder.URL_SAFE /*2*/:
            case Error.BAD_CVC /*3*/:
            case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
            case Error.DECLINED /*5*/:
                return true;
            default:
                return false;
        }
    }
}
