package com.google.android.gms.internal;

import android.support.v4.media.TransportMediator;
import android.support.v4.view.MotionEventCompat;
import com.google.android.gms.cast.Cast;
import java.io.IOException;
import java.io.UnsupportedEncodingException;

public final class jz {
    private final int aad;
    private final byte[] buffer;
    private int position;

    /* renamed from: com.google.android.gms.internal.jz.a */
    public static class C0767a extends IOException {
        C0767a(int i, int i2) {
            super("CodedOutputStream was writing to a flat byte array and ran out of space (pos " + i + " limit " + i2 + ").");
        }
    }

    private jz(byte[] bArr, int i, int i2) {
        this.buffer = bArr;
        this.position = i;
        this.aad = i + i2;
    }

    public static int m2557A(long j) {
        return m2559C(m2560D(j));
    }

    public static int m2558B(boolean z) {
        return 1;
    }

    public static int m2559C(long j) {
        return (-128 & j) == 0 ? 1 : (-16384 & j) == 0 ? 2 : (-2097152 & j) == 0 ? 3 : (-268435456 & j) == 0 ? 4 : (-34359738368L & j) == 0 ? 5 : (-4398046511104L & j) == 0 ? 6 : (-562949953421312L & j) == 0 ? 7 : (-72057594037927936L & j) == 0 ? 8 : (Long.MIN_VALUE & j) == 0 ? 9 : 10;
    }

    public static long m2560D(long j) {
        return (j << 1) ^ (j >> 63);
    }

    public static int m2561b(int i, float f) {
        return cE(i) + m2567e(f);
    }

    public static int m2562b(int i, ke keVar) {
        return cE(i) + m2565c(keVar);
    }

    public static int m2563b(int i, boolean z) {
        return cE(i) + m2558B(z);
    }

    public static jz m2564b(byte[] bArr, int i, int i2) {
        return new jz(bArr, i, i2);
    }

    public static int bQ(String str) {
        try {
            byte[] bytes = str.getBytes("UTF-8");
            return bytes.length + cG(bytes.length);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException("UTF-8 not supported.");
        }
    }

    public static int m2565c(ke keVar) {
        int c = keVar.m733c();
        return c + cG(c);
    }

    public static int cC(int i) {
        return i >= 0 ? cG(i) : 10;
    }

    public static int cE(int i) {
        return cG(kh.m2602i(i, 0));
    }

    public static int cG(int i) {
        return (i & -128) == 0 ? 1 : (i & -16384) == 0 ? 2 : (-2097152 & i) == 0 ? 3 : (-268435456 & i) == 0 ? 4 : 5;
    }

    public static int m2566d(int i, long j) {
        return cE(i) + m2572z(j);
    }

    public static int m2567e(float f) {
        return 4;
    }

    public static int m2568e(int i, long j) {
        return cE(i) + m2557A(j);
    }

    public static int m2569g(int i, int i2) {
        return cE(i) + cC(i2);
    }

    public static int m2570g(int i, String str) {
        return cE(i) + bQ(str);
    }

    public static jz m2571o(byte[] bArr) {
        return m2564b(bArr, 0, bArr.length);
    }

    public static int m2572z(long j) {
        return m2559C(j);
    }

    public void m2573A(boolean z) throws IOException {
        cD(z ? 1 : 0);
    }

    public void m2574B(long j) throws IOException {
        while ((-128 & j) != 0) {
            cD((((int) j) & TransportMediator.KEYCODE_MEDIA_PAUSE) | Cast.MAX_NAMESPACE_LENGTH);
            j >>>= 7;
        }
        cD((int) j);
    }

    public void m2575a(int i, float f) throws IOException {
        m2586h(i, 5);
        m2584d(f);
    }

    public void m2576a(int i, ke keVar) throws IOException {
        m2586h(i, 2);
        m2581b(keVar);
    }

    public void m2577a(int i, boolean z) throws IOException {
        m2586h(i, 0);
        m2573A(z);
    }

    public void m2578b(byte b) throws IOException {
        if (this.position == this.aad) {
            throw new C0767a(this.position, this.aad);
        }
        byte[] bArr = this.buffer;
        int i = this.position;
        this.position = i + 1;
        bArr[i] = b;
    }

    public void m2579b(int i, long j) throws IOException {
        m2586h(i, 0);
        m2588x(j);
    }

    public void m2580b(int i, String str) throws IOException {
        m2586h(i, 2);
        bP(str);
    }

    public void m2581b(ke keVar) throws IOException {
        cF(keVar.eW());
        keVar.m731a(this);
    }

    public void bP(String str) throws IOException {
        byte[] bytes = str.getBytes("UTF-8");
        cF(bytes.length);
        m2587p(bytes);
    }

    public void m2582c(int i, long j) throws IOException {
        m2586h(i, 0);
        m2589y(j);
    }

    public void m2583c(byte[] bArr, int i, int i2) throws IOException {
        if (this.aad - this.position >= i2) {
            System.arraycopy(bArr, i, this.buffer, this.position, i2);
            this.position += i2;
            return;
        }
        throw new C0767a(this.position, this.aad);
    }

    public void cB(int i) throws IOException {
        if (i >= 0) {
            cF(i);
        } else {
            m2574B((long) i);
        }
    }

    public void cD(int i) throws IOException {
        m2578b((byte) i);
    }

    public void cF(int i) throws IOException {
        while ((i & -128) != 0) {
            cD((i & TransportMediator.KEYCODE_MEDIA_PAUSE) | Cast.MAX_NAMESPACE_LENGTH);
            i >>>= 7;
        }
        cD(i);
    }

    public void cH(int i) throws IOException {
        cD(i & MotionEventCompat.ACTION_MASK);
        cD((i >> 8) & MotionEventCompat.ACTION_MASK);
        cD((i >> 16) & MotionEventCompat.ACTION_MASK);
        cD((i >> 24) & MotionEventCompat.ACTION_MASK);
    }

    public void m2584d(float f) throws IOException {
        cH(Float.floatToIntBits(f));
    }

    public void m2585f(int i, int i2) throws IOException {
        m2586h(i, 0);
        cB(i2);
    }

    public void m2586h(int i, int i2) throws IOException {
        cF(kh.m2602i(i, i2));
    }

    public int kM() {
        return this.aad - this.position;
    }

    public void kN() {
        if (kM() != 0) {
            throw new IllegalStateException("Did not write as much data as expected.");
        }
    }

    public void m2587p(byte[] bArr) throws IOException {
        m2583c(bArr, 0, bArr.length);
    }

    public void m2588x(long j) throws IOException {
        m2574B(j);
    }

    public void m2589y(long j) throws IOException {
        m2574B(m2560D(j));
    }
}
