package com.google.android.gms.internal;

public final class gq {
    public static String aW(int i) {
        switch (i) {
            case Base64Encoder.DEFAULT /*0*/:
                return "PUBLIC";
            case Base64Encoder.NO_PADDING /*1*/:
                return "SOCIAL";
            default:
                throw new IllegalArgumentException("Unknown leaderboard collection: " + i);
        }
    }
}
