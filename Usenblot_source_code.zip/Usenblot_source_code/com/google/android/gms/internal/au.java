package com.google.android.gms.internal;

import android.location.Location;

public interface au {
    Location m985a(long j);

    void init();
}
