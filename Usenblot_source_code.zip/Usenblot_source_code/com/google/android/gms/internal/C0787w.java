package com.google.android.gms.internal;

import java.lang.ref.WeakReference;

/* renamed from: com.google.android.gms.internal.w */
public final class C0787w {
    private final Runnable kW;
    private C0790z kX;
    private boolean kY;

    /* renamed from: com.google.android.gms.internal.w.1 */
    class C07861 implements Runnable {
        private final WeakReference<C0785v> kZ;
        final /* synthetic */ C0785v la;
        final /* synthetic */ C0787w lb;

        C07861(C0787w c0787w, C0785v c0785v) {
            this.lb = c0787w;
            this.la = c0785v;
            this.kZ = new WeakReference(this.la);
        }

        public void run() {
            this.lb.kY = false;
            C0785v c0785v = (C0785v) this.kZ.get();
            if (c0785v != null) {
                c0785v.m2667b(this.lb.kX);
            }
        }
    }

    public C0787w(C0785v c0785v) {
        this.kY = false;
        this.kW = new C07861(this, c0785v);
    }

    public void m2670a(C0790z c0790z, long j) {
        if (this.kY) {
            da.m1273w("An ad refresh is already scheduled.");
            return;
        }
        da.m1271u("Scheduling ad refresh " + j + " milliseconds from now.");
        this.kX = c0790z;
        this.kY = true;
        cz.pT.postDelayed(this.kW, j);
    }

    public void cancel() {
        cz.pT.removeCallbacks(this.kW);
    }

    public void m2671d(C0790z c0790z) {
        m2670a(c0790z, 60000);
    }
}
