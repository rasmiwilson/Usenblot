package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.ContentProviderClient;
import android.content.Context;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.location.C0708a;
import com.google.android.gms.location.C0708a.C0709a;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import java.util.HashMap;

public class hh {
    private final hl<hg> Lk;
    private ContentProviderClient Ll;
    private boolean Lm;
    private HashMap<LocationListener, C0710b> Ln;
    private final Context mContext;

    /* renamed from: com.google.android.gms.internal.hh.a */
    private static class C0707a extends Handler {
        private final LocationListener Lo;

        public C0707a(LocationListener locationListener) {
            this.Lo = locationListener;
        }

        public C0707a(LocationListener locationListener, Looper looper) {
            super(looper);
            this.Lo = locationListener;
        }

        public void handleMessage(Message msg) {
            switch (msg.what) {
                case Base64Encoder.NO_PADDING /*1*/:
                    this.Lo.onLocationChanged(new Location((Location) msg.obj));
                default:
                    Log.e("LocationClientHelper", "unknown message in LocationHandler.handleMessage");
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.hh.b */
    private static class C0710b extends C0709a {
        private Handler Lp;

        C0710b(LocationListener locationListener, Looper looper) {
            this.Lp = looper == null ? new C0707a(locationListener) : new C0707a(locationListener, looper);
        }

        public void onLocationChanged(Location location) {
            if (this.Lp == null) {
                Log.e("LocationClientHelper", "Received a location in client after calling removeLocationUpdates.");
                return;
            }
            Message obtain = Message.obtain();
            obtain.what = 1;
            obtain.obj = location;
            this.Lp.sendMessage(obtain);
        }

        public void release() {
            this.Lp = null;
        }
    }

    public hh(Context context, hl<hg> hlVar) {
        this.Ll = null;
        this.Lm = false;
        this.Ln = new HashMap();
        this.mContext = context;
        this.Lk = hlVar;
    }

    public Location getLastLocation() {
        this.Lk.bm();
        try {
            return ((hg) this.Lk.eb()).aF(this.mContext.getPackageName());
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public void gl() {
        if (this.Lm) {
            setMockMode(false);
        }
    }

    public void removeAllListeners() {
        try {
            synchronized (this.Ln) {
                for (C0708a c0708a : this.Ln.values()) {
                    if (c0708a != null) {
                        ((hg) this.Lk.eb()).m2348a(c0708a);
                    }
                }
                this.Ln.clear();
            }
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public void removeLocationUpdates(PendingIntent callbackIntent) {
        this.Lk.bm();
        try {
            ((hg) this.Lk.eb()).m2337a(callbackIntent);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public void removeLocationUpdates(LocationListener listener) {
        this.Lk.bm();
        er.m1549b((Object) listener, (Object) "Invalid null listener");
        synchronized (this.Ln) {
            C0708a c0708a = (C0710b) this.Ln.remove(listener);
            if (this.Ll != null && this.Ln.isEmpty()) {
                this.Ll.release();
                this.Ll = null;
            }
            if (c0708a != null) {
                c0708a.release();
                try {
                    ((hg) this.Lk.eb()).m2348a(c0708a);
                } catch (Throwable e) {
                    throw new IllegalStateException(e);
                }
            }
        }
    }

    public void requestLocationUpdates(LocationRequest request, PendingIntent callbackIntent) {
        this.Lk.bm();
        try {
            ((hg) this.Lk.eb()).m2345a(request, callbackIntent);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public void requestLocationUpdates(LocationRequest request, LocationListener listener, Looper looper) {
        this.Lk.bm();
        if (looper == null) {
            er.m1549b(Looper.myLooper(), (Object) "Can't create handler inside thread that has not called Looper.prepare()");
        }
        synchronized (this.Ln) {
            C0708a c0710b;
            C0710b c0710b2 = (C0710b) this.Ln.get(listener);
            if (c0710b2 == null) {
                c0710b = new C0710b(listener, looper);
            } else {
                Object obj = c0710b2;
            }
            this.Ln.put(listener, c0710b);
            try {
                ((hg) this.Lk.eb()).m2347a(request, c0710b, this.mContext.getPackageName());
            } catch (Throwable e) {
                throw new IllegalStateException(e);
            }
        }
    }

    public void setMockLocation(Location mockLocation) {
        this.Lk.bm();
        try {
            ((hg) this.Lk.eb()).setMockLocation(mockLocation);
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public void setMockMode(boolean isMockMode) {
        this.Lk.bm();
        try {
            ((hg) this.Lk.eb()).setMockMode(isMockMode);
            this.Lm = isMockMode;
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }
}
