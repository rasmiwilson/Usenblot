package com.google.android.gms.internal;

import com.google.android.gms.internal.bc.C0449a;
import com.google.android.gms.internal.bh.C0447a;

public final class ba extends C0447a {
    private C0449a mA;
    private az mB;
    private final Object mg;

    public ba() {
        this.mg = new Object();
    }

    public void m996O() {
        synchronized (this.mg) {
            if (this.mB != null) {
                this.mB.m989U();
            }
        }
    }

    public void m997a(az azVar) {
        synchronized (this.mg) {
            this.mB = azVar;
        }
    }

    public void m998a(C0449a c0449a) {
        synchronized (this.mg) {
            this.mA = c0449a;
        }
    }

    public void onAdClosed() {
        synchronized (this.mg) {
            if (this.mB != null) {
                this.mB.m990V();
            }
        }
    }

    public void onAdFailedToLoad(int error) {
        synchronized (this.mg) {
            if (this.mA != null) {
                this.mA.m999f(error == 3 ? 1 : 2);
                this.mA = null;
            }
        }
    }

    public void onAdLeftApplication() {
        synchronized (this.mg) {
            if (this.mB != null) {
                this.mB.m991W();
            }
        }
    }

    public void onAdLoaded() {
        synchronized (this.mg) {
            if (this.mA != null) {
                this.mA.m999f(0);
                this.mA = null;
                return;
            }
            if (this.mB != null) {
                this.mB.m993Y();
            }
        }
    }

    public void onAdOpened() {
        synchronized (this.mg) {
            if (this.mB != null) {
                this.mB.m992X();
            }
        }
    }
}
