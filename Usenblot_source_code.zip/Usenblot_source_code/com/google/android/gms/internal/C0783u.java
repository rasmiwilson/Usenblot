package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.u */
public interface C0783u {
    void m2643O();
}
