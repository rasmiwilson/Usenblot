package com.google.android.gms.internal;

import android.location.Location;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.List;

public class aa implements Creator<C0790z> {
    static void m912a(C0790z c0790z, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, c0790z.versionCode);
        C0265b.m485a(parcel, 2, c0790z.le);
        C0265b.m486a(parcel, 3, c0790z.extras, false);
        C0265b.m501c(parcel, 4, c0790z.lf);
        C0265b.m492a(parcel, 5, c0790z.lg, false);
        C0265b.m494a(parcel, 6, c0790z.lh);
        C0265b.m501c(parcel, 7, c0790z.tagForChildDirectedTreatment);
        C0265b.m494a(parcel, 8, c0790z.li);
        C0265b.m491a(parcel, 9, c0790z.lj, false);
        C0265b.m489a(parcel, 10, c0790z.lk, i, false);
        C0265b.m489a(parcel, 11, c0790z.ll, i, false);
        C0265b.m491a(parcel, 12, c0790z.lm, false);
        C0265b.m481D(parcel, p);
    }

    public C0790z m913a(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        long j = 0;
        Bundle bundle = null;
        int i2 = 0;
        List list = null;
        boolean z = false;
        int i3 = 0;
        boolean z2 = false;
        String str = null;
        am amVar = null;
        Location location = null;
        String str2 = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    j = C0264a.m458h(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    bundle = C0264a.m467o(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    list = C0264a.m477y(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    z = C0264a.m453c(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    i3 = C0264a.m457g(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    z2 = C0264a.m453c(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                    amVar = (am) C0264a.m446a(parcel, n, am.CREATOR);
                    break;
                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                    location = (Location) C0264a.m446a(parcel, n, Location.CREATOR);
                    break;
                case CommonStatusCodes.DATE_INVALID /*12*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new C0790z(i, j, bundle, i2, list, z, i3, z2, str, amVar, location, str2);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public C0790z[] m914b(int i) {
        return new C0790z[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m913a(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m914b(x0);
    }
}
