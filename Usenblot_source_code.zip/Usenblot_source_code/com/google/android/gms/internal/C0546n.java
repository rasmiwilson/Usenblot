package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.n */
public interface C0546n {
    String m1450a(byte[] bArr, boolean z);

    byte[] m1451a(String str, boolean z) throws IllegalArgumentException;
}
