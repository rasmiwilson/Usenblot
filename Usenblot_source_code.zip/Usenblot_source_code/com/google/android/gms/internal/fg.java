package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.internal.fe.C0588a;
import com.google.android.gms.internal.fe.C0589b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import java.util.ArrayList;

public class fg implements Creator<C0588a> {
    static void m1622a(C0588a c0588a, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, c0588a.versionCode);
        C0265b.m491a(parcel, 2, c0588a.className, false);
        C0265b.m500b(parcel, 3, c0588a.CH, false);
        C0265b.m481D(parcel, p);
    }

    public C0588a[] m1623Z(int i) {
        return new C0588a[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1624w(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1623Z(x0);
    }

    public C0588a m1624w(Parcel parcel) {
        ArrayList arrayList = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    arrayList = C0264a.m452c(parcel, n, C0589b.CREATOR);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new C0588a(i, str, arrayList);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }
}
