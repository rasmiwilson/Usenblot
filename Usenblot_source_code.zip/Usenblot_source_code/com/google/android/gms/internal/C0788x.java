package com.google.android.gms.internal;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.internal.af.C0431a;

/* renamed from: com.google.android.gms.internal.x */
public final class C0788x extends C0431a {
    private final AdListener lc;

    public C0788x(AdListener adListener) {
        this.lc = adListener;
    }

    public void onAdClosed() {
        this.lc.onAdClosed();
    }

    public void onAdFailedToLoad(int errorCode) {
        this.lc.onAdFailedToLoad(errorCode);
    }

    public void onAdLeftApplication() {
        this.lc.onAdLeftApplication();
    }

    public void onAdLoaded() {
        this.lc.onAdLoaded();
    }

    public void onAdOpened() {
        this.lc.onAdOpened();
    }
}
