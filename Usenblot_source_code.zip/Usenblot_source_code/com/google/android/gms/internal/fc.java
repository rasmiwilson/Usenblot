package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.fb.C0587a;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public class fc implements Creator<C0587a> {
    static void m1609a(C0587a c0587a, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, c0587a.getVersionCode());
        C0265b.m501c(parcel, 2, c0587a.el());
        C0265b.m494a(parcel, 3, c0587a.er());
        C0265b.m501c(parcel, 4, c0587a.em());
        C0265b.m494a(parcel, 5, c0587a.es());
        C0265b.m491a(parcel, 6, c0587a.et(), false);
        C0265b.m501c(parcel, 7, c0587a.eu());
        C0265b.m491a(parcel, 8, c0587a.ew(), false);
        C0265b.m489a(parcel, 9, c0587a.ey(), i, false);
        C0265b.m481D(parcel, p);
    }

    public C0587a[] m1610W(int i) {
        return new C0587a[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1611t(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1610W(x0);
    }

    public C0587a m1611t(Parcel parcel) {
        ew ewVar = null;
        int i = 0;
        int o = C0264a.m466o(parcel);
        String str = null;
        String str2 = null;
        boolean z = false;
        int i2 = 0;
        boolean z2 = false;
        int i3 = 0;
        int i4 = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i4 = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    i3 = C0264a.m457g(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    z2 = C0264a.m453c(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    z = C0264a.m453c(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    ewVar = (ew) C0264a.m446a(parcel, n, ew.CREATOR);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new C0587a(i4, i3, z2, i2, z, str2, i, str, ewVar);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }
}
