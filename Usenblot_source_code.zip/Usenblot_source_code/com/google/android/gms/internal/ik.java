package com.google.android.gms.internal;

import android.net.Uri;
import com.google.android.gms.common.api.Api.C0179b;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.plus.Moments;
import com.google.android.gms.plus.Moments.LoadMomentsResult;
import com.google.android.gms.plus.Plus.C0730a;
import com.google.android.gms.plus.internal.C0946e;
import com.google.android.gms.plus.model.moments.Moment;
import com.google.android.gms.plus.model.moments.MomentBuffer;

public final class ik implements Moments {
    private final C0179b<C0946e> Rw;

    /* renamed from: com.google.android.gms.internal.ik.a */
    private static abstract class C0734a extends C0730a<LoadMomentsResult> {

        /* renamed from: com.google.android.gms.internal.ik.a.1 */
        class C07411 implements LoadMomentsResult {
            final /* synthetic */ C0734a RF;
            final /* synthetic */ Status vb;

            C07411(C0734a c0734a, Status status) {
                this.RF = c0734a;
                this.vb = status;
            }

            public MomentBuffer getMomentBuffer() {
                return null;
            }

            public String getNextPageToken() {
                return null;
            }

            public Status getStatus() {
                return this.vb;
            }

            public String getUpdated() {
                return null;
            }

            public void release() {
            }
        }

        C0734a(C0179b<C0946e> c0179b) {
            super(c0179b);
        }

        public LoadMomentsResult m2434M(Status status) {
            return new C07411(this, status);
        }

        public /* synthetic */ Result m2435d(Status status) {
            return m2434M(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.ik.1 */
    class C07351 extends C0734a {
        final /* synthetic */ ik Ry;

        C07351(ik ikVar, C0179b c0179b) {
            this.Ry = ikVar;
            super(c0179b);
        }

        protected void m2437a(C0946e c0946e) {
            c0946e.m2906i(this);
        }
    }

    /* renamed from: com.google.android.gms.internal.ik.2 */
    class C07362 extends C0734a {
        final /* synthetic */ int HW;
        final /* synthetic */ Uri RA;
        final /* synthetic */ String RB;
        final /* synthetic */ String RC;
        final /* synthetic */ ik Ry;
        final /* synthetic */ String Rz;

        C07362(ik ikVar, C0179b c0179b, int i, String str, Uri uri, String str2, String str3) {
            this.Ry = ikVar;
            this.HW = i;
            this.Rz = str;
            this.RA = uri;
            this.RB = str2;
            this.RC = str3;
            super(c0179b);
        }

        protected void m2439a(C0946e c0946e) {
            c0946e.m2901a(this, this.HW, this.Rz, this.RA, this.RB, this.RC);
        }
    }

    /* renamed from: com.google.android.gms.internal.ik.c */
    private static abstract class C0737c extends C0730a<Status> {
        C0737c(C0179b<C0946e> c0179b) {
            super(c0179b);
        }

        public /* synthetic */ Result m2440d(Status status) {
            return m2441f(status);
        }

        public Status m2441f(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.ik.3 */
    class C07383 extends C0737c {
        final /* synthetic */ Moment RD;
        final /* synthetic */ ik Ry;

        C07383(ik ikVar, C0179b c0179b, Moment moment) {
            this.Ry = ikVar;
            this.RD = moment;
            super(c0179b);
        }

        protected void m2443a(C0946e c0946e) {
            c0946e.m2902a((C0182c) this, this.RD);
        }
    }

    /* renamed from: com.google.android.gms.internal.ik.b */
    private static abstract class C0739b extends C0730a<Status> {
        C0739b(C0179b<C0946e> c0179b) {
            super(c0179b);
        }

        public /* synthetic */ Result m2444d(Status status) {
            return m2445f(status);
        }

        public Status m2445f(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.ik.4 */
    class C07404 extends C0739b {
        final /* synthetic */ String RE;
        final /* synthetic */ ik Ry;

        C07404(ik ikVar, C0179b c0179b, String str) {
            this.Ry = ikVar;
            this.RE = str;
            super(c0179b);
        }

        protected void m2447a(C0946e c0946e) {
            c0946e.removeMoment(this.RE);
            m201a(Status.zQ);
        }
    }

    public ik(C0179b<C0946e> c0179b) {
        this.Rw = c0179b;
    }

    public PendingResult<LoadMomentsResult> load(GoogleApiClient googleApiClient) {
        return googleApiClient.m365a(new C07351(this, this.Rw));
    }

    public PendingResult<LoadMomentsResult> load(GoogleApiClient googleApiClient, int maxResults, String pageToken, Uri targetUrl, String type, String userId) {
        return googleApiClient.m365a(new C07362(this, this.Rw, maxResults, pageToken, targetUrl, type, userId));
    }

    public PendingResult<Status> remove(GoogleApiClient googleApiClient, String momentId) {
        return googleApiClient.m366b(new C07404(this, this.Rw, momentId));
    }

    public PendingResult<Status> write(GoogleApiClient googleApiClient, Moment moment) {
        return googleApiClient.m366b(new C07383(this, this.Rw, moment));
    }
}
