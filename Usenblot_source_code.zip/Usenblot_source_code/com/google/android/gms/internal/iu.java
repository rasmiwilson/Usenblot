package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.internal.ir.C0752b;
import com.google.android.gms.internal.ir.C0752b.C0750a;
import com.google.android.gms.internal.ir.C0752b.C0751b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.HashSet;
import java.util.Set;

public class iu implements Creator<C0752b> {
    static void m2490a(C0752b c0752b, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        Set hB = c0752b.hB();
        if (hB.contains(Integer.valueOf(1))) {
            C0265b.m501c(parcel, 1, c0752b.getVersionCode());
        }
        if (hB.contains(Integer.valueOf(2))) {
            C0265b.m489a(parcel, 2, c0752b.m2474if(), i, true);
        }
        if (hB.contains(Integer.valueOf(3))) {
            C0265b.m489a(parcel, 3, c0752b.ig(), i, true);
        }
        if (hB.contains(Integer.valueOf(4))) {
            C0265b.m501c(parcel, 4, c0752b.getLayout());
        }
        C0265b.m481D(parcel, p);
    }

    public C0752b aK(Parcel parcel) {
        C0751b c0751b = null;
        int i = 0;
        int o = C0264a.m466o(parcel);
        Set hashSet = new HashSet();
        C0750a c0750a = null;
        int i2 = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i2 = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    C0750a c0750a2 = (C0750a) C0264a.m446a(parcel, n, C0750a.CREATOR);
                    hashSet.add(Integer.valueOf(2));
                    c0750a = c0750a2;
                    break;
                case Error.BAD_CVC /*3*/:
                    C0751b c0751b2 = (C0751b) C0264a.m446a(parcel, n, C0751b.CREATOR);
                    hashSet.add(Integer.valueOf(3));
                    c0751b = c0751b2;
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    i = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(4));
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new C0752b(hashSet, i2, c0750a, c0751b, i);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public C0752b[] bH(int i) {
        return new C0752b[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aK(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bH(x0);
    }
}
