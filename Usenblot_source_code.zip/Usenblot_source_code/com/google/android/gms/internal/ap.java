package com.google.android.gms.internal;

public interface ap {
    void onAppEvent(String str, String str2);
}
