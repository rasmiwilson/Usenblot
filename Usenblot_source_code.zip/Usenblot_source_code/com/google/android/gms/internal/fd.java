package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.internal.fb.C0587a;
import com.google.android.gms.internal.fe.C0589b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;

public class fd implements Creator<C0589b> {
    static void m1612a(C0589b c0589b, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, c0589b.versionCode);
        C0265b.m491a(parcel, 2, c0589b.eX, false);
        C0265b.m489a(parcel, 3, c0589b.CI, i, false);
        C0265b.m481D(parcel, p);
    }

    public C0589b[] m1613X(int i) {
        return new C0589b[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1614u(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1613X(x0);
    }

    public C0589b m1614u(Parcel parcel) {
        C0587a c0587a = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    c0587a = (C0587a) C0264a.m446a(parcel, n, C0587a.CREATOR);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new C0589b(i, str, c0587a);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }
}
