package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public class dc implements Creator<db> {
    static void m1274a(db dbVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, dbVar.versionCode);
        C0265b.m491a(parcel, 2, dbVar.pU, false);
        C0265b.m501c(parcel, 3, dbVar.pV);
        C0265b.m501c(parcel, 4, dbVar.pW);
        C0265b.m494a(parcel, 5, dbVar.pX);
        C0265b.m481D(parcel, p);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1275h(x0);
    }

    public db m1275h(Parcel parcel) {
        boolean z = false;
        int o = C0264a.m466o(parcel);
        String str = null;
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i3 = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    z = C0264a.m453c(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new db(i3, str, i2, i, z);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1276o(x0);
    }

    public db[] m1276o(int i) {
        return new db[i];
    }
}
