package com.google.android.gms.internal;

import org.json.JSONObject;

public interface dx {
    void m330a(long j, int i, JSONObject jSONObject);

    void m331k(long j);
}
