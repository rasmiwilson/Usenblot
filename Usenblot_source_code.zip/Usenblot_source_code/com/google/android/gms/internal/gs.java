package com.google.android.gms.internal;

public final class gs {
    public static String aW(int i) {
        switch (i) {
            case Base64Encoder.NO_PADDING /*1*/:
                return "GIFT";
            case Base64Encoder.URL_SAFE /*2*/:
                return "WISH";
            default:
                fz.m1918h("RequestType", "Unknown request type: " + i);
                return "UNKNOWN_TYPE";
        }
    }
}
