package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public class bp implements Creator<bq> {
    static void m1056a(bq bqVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, bqVar.versionCode);
        C0265b.m489a(parcel, 2, bqVar.nr, i, false);
        C0265b.m487a(parcel, 3, bqVar.at(), false);
        C0265b.m487a(parcel, 4, bqVar.au(), false);
        C0265b.m487a(parcel, 5, bqVar.av(), false);
        C0265b.m487a(parcel, 6, bqVar.aw(), false);
        C0265b.m491a(parcel, 7, bqVar.nw, false);
        C0265b.m494a(parcel, 8, bqVar.nx);
        C0265b.m491a(parcel, 9, bqVar.ny, false);
        C0265b.m487a(parcel, 10, bqVar.ax(), false);
        C0265b.m501c(parcel, 11, bqVar.orientation);
        C0265b.m501c(parcel, 12, bqVar.nA);
        C0265b.m491a(parcel, 13, bqVar.mZ, false);
        C0265b.m489a(parcel, 14, bqVar.kN, i, false);
        C0265b.m481D(parcel, p);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1057e(x0);
    }

    public bq m1057e(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        bn bnVar = null;
        IBinder iBinder = null;
        IBinder iBinder2 = null;
        IBinder iBinder3 = null;
        IBinder iBinder4 = null;
        String str = null;
        boolean z = false;
        String str2 = null;
        IBinder iBinder5 = null;
        int i2 = 0;
        int i3 = 0;
        String str3 = null;
        db dbVar = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    bnVar = (bn) C0264a.m446a(parcel, n, bn.CREATOR);
                    break;
                case Error.BAD_CVC /*3*/:
                    iBinder = C0264a.m465n(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    iBinder2 = C0264a.m465n(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    iBinder3 = C0264a.m465n(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    iBinder4 = C0264a.m465n(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    z = C0264a.m453c(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                    iBinder5 = C0264a.m465n(parcel, n);
                    break;
                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case CommonStatusCodes.DATE_INVALID /*12*/:
                    i3 = C0264a.m457g(parcel, n);
                    break;
                case CommonStatusCodes.ERROR /*13*/:
                    str3 = C0264a.m463m(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_INTERRUPTED /*14*/:
                    dbVar = (db) C0264a.m446a(parcel, n, db.CREATOR);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new bq(i, bnVar, iBinder, iBinder2, iBinder3, iBinder4, str, z, str2, iBinder5, i2, i3, str3, dbVar);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public bq[] m1058j(int i) {
        return new bq[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1058j(x0);
    }
}
