package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.C0179b;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.plus.Account;
import com.google.android.gms.plus.Plus.C0730a;
import com.google.android.gms.plus.internal.C0946e;

public final class ii implements Account {
    private final C0179b<C0946e> Rw;

    /* renamed from: com.google.android.gms.internal.ii.a */
    private static abstract class C0731a extends C0730a<Status> {
        C0731a(C0179b<C0946e> c0179b) {
            super(c0179b);
        }

        public /* synthetic */ Result m2429d(Status status) {
            return m2430f(status);
        }

        public Status m2430f(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.internal.ii.1 */
    class C07321 extends C0731a {
        final /* synthetic */ ii Rx;

        C07321(ii iiVar, C0179b c0179b) {
            this.Rx = iiVar;
            super(c0179b);
        }

        protected void m2432a(C0946e c0946e) {
            c0946e.m2909k(this);
        }
    }

    public ii(C0179b<C0946e> c0179b) {
        this.Rw = c0179b;
    }

    private static C0946e m2433a(GoogleApiClient googleApiClient, C0179b<C0946e> c0179b) {
        boolean z = true;
        er.m1550b(googleApiClient != null, (Object) "GoogleApiClient parameter is required.");
        er.m1547a(googleApiClient.isConnected(), "GoogleApiClient must be connected.");
        C0946e c0946e = (C0946e) googleApiClient.m364a((C0179b) c0179b);
        if (c0946e == null) {
            z = false;
        }
        er.m1547a(z, "GoogleApiClient is not configured to use the Plus.API Api. Pass this into GoogleApiClient.Builder#addApi() to use this feature.");
        return c0946e;
    }

    public void clearDefaultAccount(GoogleApiClient googleApiClient) {
        m2433a(googleApiClient, this.Rw).clearDefaultAccount();
    }

    public String getAccountName(GoogleApiClient googleApiClient) {
        return m2433a(googleApiClient, this.Rw).getAccountName();
    }

    public PendingResult<Status> revokeAccessAndDisconnect(GoogleApiClient googleApiClient) {
        return googleApiClient.m366b(new C07321(this, this.Rw));
    }
}
