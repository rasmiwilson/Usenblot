package com.google.android.gms.internal;

import android.content.Context;
import android.view.MotionEvent;

/* renamed from: com.google.android.gms.internal.h */
public interface C0695h {
    String m2316a(Context context);

    String m2317a(Context context, String str);

    void m2318a(int i, int i2, int i3);

    void m2319a(MotionEvent motionEvent);
}
