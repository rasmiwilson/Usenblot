package com.google.android.gms.internal;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import com.google.android.gms.cast.Cast;
import java.util.HashMap;
import java.util.Map;

public final class aq {
    public static final ar lW;
    public static final ar lX;
    public static final ar lY;
    public static final ar lZ;
    public static final ar ma;
    public static final ar mb;
    public static final ar mc;
    public static final ar md;
    public static final ar me;

    /* renamed from: com.google.android.gms.internal.aq.1 */
    static class C04381 implements ar {
        C04381() {
        }

        public void m973a(dd ddVar, Map<String, String> map) {
            String str = (String) map.get("urls");
            if (str == null) {
                da.m1273w("URLs missing in canOpenURLs GMSG.");
                return;
            }
            String[] split = str.split(",");
            Map hashMap = new HashMap();
            PackageManager packageManager = ddVar.getContext().getPackageManager();
            for (String str2 : split) {
                String[] split2 = str2.split(";", 2);
                hashMap.put(str2, Boolean.valueOf(packageManager.resolveActivity(new Intent(split2.length > 1 ? split2[1].trim() : "android.intent.action.VIEW", Uri.parse(split2[0].trim())), Cast.MAX_MESSAGE_LENGTH) != null));
            }
            ddVar.m1282a("openableURLs", hashMap);
        }
    }

    /* renamed from: com.google.android.gms.internal.aq.2 */
    static class C04392 implements ar {
        C04392() {
        }

        public void m974a(dd ddVar, Map<String, String> map) {
            String str = (String) map.get("u");
            if (str == null) {
                da.m1273w("URL missing from click GMSG.");
                return;
            }
            Uri a;
            Uri parse = Uri.parse(str);
            try {
                C0770l bc = ddVar.bc();
                if (bc != null && bc.m2607a(parse)) {
                    a = bc.m2605a(parse, ddVar.getContext());
                    new cy(ddVar.getContext(), ddVar.bd().pU, a.toString()).start();
                }
            } catch (C0771m e) {
                da.m1273w("Unable to append parameter to URL: " + str);
            }
            a = parse;
            new cy(ddVar.getContext(), ddVar.bd().pU, a.toString()).start();
        }
    }

    /* renamed from: com.google.android.gms.internal.aq.3 */
    static class C04403 implements ar {
        C04403() {
        }

        public void m975a(dd ddVar, Map<String, String> map) {
            bo ba = ddVar.ba();
            if (ba == null) {
                da.m1273w("A GMSG tried to close something that wasn't an overlay.");
            } else {
                ba.close();
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.aq.4 */
    static class C04414 implements ar {
        C04414() {
        }

        public void m976a(dd ddVar, Map<String, String> map) {
            bo ba = ddVar.ba();
            if (ba == null) {
                da.m1273w("A GMSG tried to use a custom close button on something that wasn't an overlay.");
            } else {
                ba.m1055g("1".equals(map.get("custom_close")));
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.aq.5 */
    static class C04425 implements ar {
        C04425() {
        }

        public void m977a(dd ddVar, Map<String, String> map) {
            String str = (String) map.get("u");
            if (str == null) {
                da.m1273w("URL missing from httpTrack GMSG.");
            } else {
                new cy(ddVar.getContext(), ddVar.bd().pU, str).start();
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.aq.6 */
    static class C04436 implements ar {
        C04436() {
        }

        public void m978a(dd ddVar, Map<String, String> map) {
            da.m1271u("Received log message: " + ((String) map.get("string")));
        }
    }

    /* renamed from: com.google.android.gms.internal.aq.7 */
    static class C04447 implements ar {
        C04447() {
        }

        public void m979a(dd ddVar, Map<String, String> map) {
            String str = (String) map.get("ty");
            String str2 = (String) map.get("td");
            try {
                int parseInt = Integer.parseInt((String) map.get("tx"));
                int parseInt2 = Integer.parseInt(str);
                int parseInt3 = Integer.parseInt(str2);
                C0770l bc = ddVar.bc();
                if (bc != null) {
                    bc.m2608y().m2318a(parseInt, parseInt2, parseInt3);
                }
            } catch (NumberFormatException e) {
                da.m1273w("Could not parse touch parameters from gmsg.");
            }
        }
    }

    static {
        lW = new C04381();
        lX = new C04392();
        lY = new C04403();
        lZ = new C04414();
        ma = new C04425();
        mb = new C04436();
        mc = new as();
        md = new C04447();
        me = new at();
    }
}
