package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Intent;
import android.os.IBinder;
import com.google.android.gms.dynamic.C0383c;
import com.google.android.gms.dynamic.C0385e;
import com.google.android.gms.internal.bw.C0469a;
import com.google.android.gms.internal.bx.C0475a;

public final class bv extends C0385e<bx> {
    private static final bv nL;

    /* renamed from: com.google.android.gms.internal.bv.a */
    private static final class C0472a extends Exception {
        public C0472a(String str) {
            super(str);
        }
    }

    static {
        nL = new bv();
    }

    private bv() {
        super("com.google.android.gms.ads.AdOverlayCreatorImpl");
    }

    public static bw m1073a(Activity activity) {
        try {
            if (!m1074b(activity)) {
                return nL.m1075c(activity);
            }
            da.m1269s("Using AdOverlay from the client jar.");
            return new bo(activity);
        } catch (C0472a e) {
            da.m1273w(e.getMessage());
            return null;
        }
    }

    private static boolean m1074b(Activity activity) throws C0472a {
        Intent intent = activity.getIntent();
        if (intent.hasExtra("com.google.android.gms.ads.internal.overlay.useClientJar")) {
            return intent.getBooleanExtra("com.google.android.gms.ads.internal.overlay.useClientJar", false);
        }
        throw new C0472a("Ad overlay requires the useClientJar flag in intent extras.");
    }

    private bw m1075c(Activity activity) {
        try {
            return C0469a.m1047m(((bx) m829z(activity)).m1078a(C0383c.m827h(activity)));
        } catch (Throwable e) {
            da.m1267b("Could not create remote AdOverlay.", e);
            return null;
        } catch (Throwable e2) {
            da.m1267b("Could not create remote AdOverlay.", e2);
            return null;
        }
    }

    protected /* synthetic */ Object m1076d(IBinder iBinder) {
        return m1077l(iBinder);
    }

    protected bx m1077l(IBinder iBinder) {
        return C0475a.m1080n(iBinder);
    }
}
