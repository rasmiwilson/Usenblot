package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import java.io.IOException;

/* renamed from: com.google.android.gms.internal.k */
public class C0769k extends C0760j {

    /* renamed from: com.google.android.gms.internal.k.a */
    class C0768a {
        private String kl;
        private boolean km;
        final /* synthetic */ C0769k kn;

        public C0768a(C0769k c0769k, String str, boolean z) {
            this.kn = c0769k;
            this.kl = str;
            this.km = z;
        }

        public String getId() {
            return this.kl;
        }

        public boolean isLimitAdTrackingEnabled() {
            return this.km;
        }
    }

    private C0769k(Context context, C0546n c0546n, C0772o c0772o) {
        super(context, c0546n, c0772o);
    }

    public static C0769k m2590a(String str, Context context) {
        C0546n c0547e = new C0547e();
        C0760j.m2498a(str, context, c0547e);
        return new C0769k(context, c0547e, new C0775q(239));
    }

    protected void m2591b(Context context) {
        long j = 1;
        super.m2506b(context);
        try {
            C0768a f = m2592f(context);
            try {
                if (!f.isLimitAdTrackingEnabled()) {
                    j = 0;
                }
                m2407a(28, j);
                String id = f.getId();
                if (id != null) {
                    m2408a(30, id);
                }
            } catch (IOException e) {
            }
        } catch (GooglePlayServicesNotAvailableException e2) {
        } catch (IOException e3) {
            m2407a(28, 1);
        }
    }

    C0768a m2592f(Context context) throws IOException, GooglePlayServicesNotAvailableException {
        int i = 0;
        try {
            String str;
            Info advertisingIdInfo = AdvertisingIdClient.getAdvertisingIdInfo(context);
            String id = advertisingIdInfo.getId();
            if (id == null || !id.matches("^[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}$")) {
                str = id;
            } else {
                byte[] bArr = new byte[16];
                int i2 = 0;
                while (i < id.length()) {
                    if (i == 8 || i == 13 || i == 18 || i == 23) {
                        i++;
                    }
                    bArr[i2] = (byte) ((Character.digit(id.charAt(i), 16) << 4) + Character.digit(id.charAt(i + 1), 16));
                    i2++;
                    i += 2;
                }
                str = this.ka.m1450a(bArr, true);
            }
            return new C0768a(this, str, advertisingIdInfo.isLimitAdTrackingEnabled());
        } catch (Throwable e) {
            throw new IOException(e);
        }
    }
}
