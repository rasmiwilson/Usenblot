package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.HashSet;
import java.util.Set;

public class ip implements Creator<io> {
    static void m2465a(io ioVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        Set hB = ioVar.hB();
        if (hB.contains(Integer.valueOf(1))) {
            C0265b.m501c(parcel, 1, ioVar.getVersionCode());
        }
        if (hB.contains(Integer.valueOf(2))) {
            C0265b.m491a(parcel, 2, ioVar.getId(), true);
        }
        if (hB.contains(Integer.valueOf(4))) {
            C0265b.m489a(parcel, 4, ioVar.hS(), i, true);
        }
        if (hB.contains(Integer.valueOf(5))) {
            C0265b.m491a(parcel, 5, ioVar.getStartDate(), true);
        }
        if (hB.contains(Integer.valueOf(6))) {
            C0265b.m489a(parcel, 6, ioVar.hT(), i, true);
        }
        if (hB.contains(Integer.valueOf(7))) {
            C0265b.m491a(parcel, 7, ioVar.getType(), true);
        }
        C0265b.m481D(parcel, p);
    }

    public io aH(Parcel parcel) {
        String str = null;
        int o = C0264a.m466o(parcel);
        Set hashSet = new HashSet();
        int i = 0;
        im imVar = null;
        String str2 = null;
        im imVar2 = null;
        String str3 = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            im imVar3;
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str3 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    imVar3 = (im) C0264a.m446a(parcel, n, im.CREATOR);
                    hashSet.add(Integer.valueOf(4));
                    imVar2 = imVar3;
                    break;
                case Error.DECLINED /*5*/:
                    str2 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(5));
                    break;
                case Error.OTHER /*6*/:
                    imVar3 = (im) C0264a.m446a(parcel, n, im.CREATOR);
                    hashSet.add(Integer.valueOf(6));
                    imVar = imVar3;
                    break;
                case Error.AVS_DECLINE /*7*/:
                    str = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(7));
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new io(hashSet, i, str3, imVar2, str2, imVar, str);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public io[] bE(int i) {
        return new io[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aH(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bE(x0);
    }
}
