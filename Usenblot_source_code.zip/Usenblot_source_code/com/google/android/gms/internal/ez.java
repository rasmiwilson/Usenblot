package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.internal.ey.C0570a;
import java.util.ArrayList;

public class ez implements Creator<ey> {
    static void m1573a(ey eyVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, eyVar.getVersionCode());
        C0265b.m500b(parcel, 2, eyVar.ek(), false);
        C0265b.m481D(parcel, p);
    }

    public ey[] m1574U(int i) {
        return new ey[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1575r(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1574U(x0);
    }

    public ey m1575r(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        ArrayList arrayList = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    arrayList = C0264a.m452c(parcel, n, C0570a.CREATOR);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new ey(i, arrayList);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }
}
