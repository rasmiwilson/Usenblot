package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.m */
public class C0771m extends Exception {
    public C0771m(String str) {
        super(str);
    }
}
