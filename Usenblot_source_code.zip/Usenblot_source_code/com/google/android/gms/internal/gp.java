package com.google.android.gms.internal;

import android.content.Intent;
import android.os.Bundle;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.Games.C0389a;
import com.google.android.gms.games.multiplayer.ParticipantResult;
import com.google.android.gms.games.multiplayer.turnbased.LoadMatchesResponse;
import com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchUpdateReceivedListener;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatch;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatchConfig;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.CancelMatchResult;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.InitiateMatchResult;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.LeaveMatchResult;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.LoadMatchResult;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.LoadMatchesResult;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.UpdateMatchResult;
import java.util.List;

public final class gp implements TurnBasedMultiplayer {

    /* renamed from: com.google.android.gms.internal.gp.e */
    private static abstract class C0674e extends C0389a<LoadMatchesResult> {

        /* renamed from: com.google.android.gms.internal.gp.e.1 */
        class C06931 implements LoadMatchesResult {
            final /* synthetic */ C0674e IC;
            final /* synthetic */ Status vb;

            C06931(C0674e c0674e, Status status) {
                this.IC = c0674e;
                this.vb = status;
            }

            public LoadMatchesResponse getMatches() {
                return new LoadMatchesResponse(new Bundle());
            }

            public Status getStatus() {
                return this.vb;
            }

            public void release() {
            }
        }

        private C0674e() {
        }

        public LoadMatchesResult m2282H(Status status) {
            return new C06931(this, status);
        }

        public /* synthetic */ Result m2283d(Status status) {
            return m2282H(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.10 */
    class AnonymousClass10 extends C0674e {
        final /* synthetic */ gp Iq;
        final /* synthetic */ int Iw;
        final /* synthetic */ int[] Ix;

        AnonymousClass10(gp gpVar, int i, int[] iArr) {
            this.Iq = gpVar;
            this.Iw = i;
            this.Ix = iArr;
            super();
        }

        protected void m2285a(fx fxVar) {
            fxVar.m1870a((C0182c) this, this.Iw, this.Ix);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.b */
    private static abstract class C0675b extends C0389a<InitiateMatchResult> {

        /* renamed from: com.google.android.gms.internal.gp.b.1 */
        class C06901 implements InitiateMatchResult {
            final /* synthetic */ C0675b Iz;
            final /* synthetic */ Status vb;

            C06901(C0675b c0675b, Status status) {
                this.Iz = c0675b;
                this.vb = status;
            }

            public TurnBasedMatch getMatch() {
                return null;
            }

            public Status getStatus() {
                return this.vb;
            }
        }

        private C0675b() {
        }

        public InitiateMatchResult m2286E(Status status) {
            return new C06901(this, status);
        }

        public /* synthetic */ Result m2287d(Status status) {
            return m2286E(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.1 */
    class C06761 extends C0675b {
        final /* synthetic */ TurnBasedMatchConfig Ip;
        final /* synthetic */ gp Iq;

        C06761(gp gpVar, TurnBasedMatchConfig turnBasedMatchConfig) {
            this.Iq = gpVar;
            this.Ip = turnBasedMatchConfig;
            super();
        }

        protected void m2289a(fx fxVar) {
            fxVar.m1872a((C0182c) this, this.Ip);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.d */
    private static abstract class C0677d extends C0389a<LoadMatchResult> {

        /* renamed from: com.google.android.gms.internal.gp.d.1 */
        class C06921 implements LoadMatchResult {
            final /* synthetic */ C0677d IB;
            final /* synthetic */ Status vb;

            C06921(C0677d c0677d, Status status) {
                this.IB = c0677d;
                this.vb = status;
            }

            public TurnBasedMatch getMatch() {
                return null;
            }

            public Status getStatus() {
                return this.vb;
            }
        }

        private C0677d() {
        }

        public LoadMatchResult m2290G(Status status) {
            return new C06921(this, status);
        }

        public /* synthetic */ Result m2291d(Status status) {
            return m2290G(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.2 */
    class C06782 extends C0677d {
        final /* synthetic */ gp Iq;
        final /* synthetic */ String Ir;

        C06782(gp gpVar, String str) {
            this.Iq = gpVar;
            this.Ir = str;
            super();
        }

        protected void m2293a(fx fxVar) {
            fxVar.m1910h(this, this.Ir);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.3 */
    class C06793 extends C0675b {
        final /* synthetic */ gp Iq;
        final /* synthetic */ String Ir;

        C06793(gp gpVar, String str) {
            this.Iq = gpVar;
            this.Ir = str;
            super();
        }

        protected void m2295a(fx fxVar) {
            fxVar.m1904d((C0182c) this, this.Ir);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.4 */
    class C06804 extends C0675b {
        final /* synthetic */ gp Iq;
        final /* synthetic */ String Is;

        C06804(gp gpVar, String str) {
            this.Iq = gpVar;
            this.Is = str;
            super();
        }

        protected void m2297a(fx fxVar) {
            fxVar.m1906e(this, this.Is);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.f */
    private static abstract class C0681f extends C0389a<UpdateMatchResult> {

        /* renamed from: com.google.android.gms.internal.gp.f.1 */
        class C06941 implements UpdateMatchResult {
            final /* synthetic */ C0681f IE;
            final /* synthetic */ Status vb;

            C06941(C0681f c0681f, Status status) {
                this.IE = c0681f;
                this.vb = status;
            }

            public TurnBasedMatch getMatch() {
                return null;
            }

            public Status getStatus() {
                return this.vb;
            }
        }

        private C0681f() {
        }

        public UpdateMatchResult m2298I(Status status) {
            return new C06941(this, status);
        }

        public /* synthetic */ Result m2299d(Status status) {
            return m2298I(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.5 */
    class C06825 extends C0681f {
        final /* synthetic */ gp Iq;
        final /* synthetic */ String Ir;
        final /* synthetic */ byte[] It;
        final /* synthetic */ String Iu;
        final /* synthetic */ ParticipantResult[] Iv;

        C06825(gp gpVar, String str, byte[] bArr, String str2, ParticipantResult[] participantResultArr) {
            this.Iq = gpVar;
            this.Ir = str;
            this.It = bArr;
            this.Iu = str2;
            this.Iv = participantResultArr;
            super();
        }

        protected void m2301a(fx fxVar) {
            fxVar.m1881a((C0182c) this, this.Ir, this.It, this.Iu, this.Iv);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.6 */
    class C06836 extends C0681f {
        final /* synthetic */ gp Iq;
        final /* synthetic */ String Ir;
        final /* synthetic */ byte[] It;
        final /* synthetic */ ParticipantResult[] Iv;

        C06836(gp gpVar, String str, byte[] bArr, ParticipantResult[] participantResultArr) {
            this.Iq = gpVar;
            this.Ir = str;
            this.It = bArr;
            this.Iv = participantResultArr;
            super();
        }

        protected void m2303a(fx fxVar) {
            fxVar.m1882a((C0182c) this, this.Ir, this.It, this.Iv);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.c */
    private static abstract class C0684c extends C0389a<LeaveMatchResult> {

        /* renamed from: com.google.android.gms.internal.gp.c.1 */
        class C06911 implements LeaveMatchResult {
            final /* synthetic */ C0684c IA;
            final /* synthetic */ Status vb;

            C06911(C0684c c0684c, Status status) {
                this.IA = c0684c;
                this.vb = status;
            }

            public TurnBasedMatch getMatch() {
                return null;
            }

            public Status getStatus() {
                return this.vb;
            }
        }

        private C0684c() {
        }

        public LeaveMatchResult m2304F(Status status) {
            return new C06911(this, status);
        }

        public /* synthetic */ Result m2305d(Status status) {
            return m2304F(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.7 */
    class C06857 extends C0684c {
        final /* synthetic */ gp Iq;
        final /* synthetic */ String Ir;

        C06857(gp gpVar, String str) {
            this.Iq = gpVar;
            this.Ir = str;
            super();
        }

        protected void m2307a(fx fxVar) {
            fxVar.m1907f(this, this.Ir);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.8 */
    class C06868 extends C0684c {
        final /* synthetic */ gp Iq;
        final /* synthetic */ String Ir;
        final /* synthetic */ String Iu;

        C06868(gp gpVar, String str, String str2) {
            this.Iq = gpVar;
            this.Ir = str;
            this.Iu = str2;
            super();
        }

        protected void m2309a(fx fxVar) {
            fxVar.m1878a((C0182c) this, this.Ir, this.Iu);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.a */
    private static abstract class C0687a extends C0389a<CancelMatchResult> {
        private final String uS;

        /* renamed from: com.google.android.gms.internal.gp.a.1 */
        class C06891 implements CancelMatchResult {
            final /* synthetic */ C0687a Iy;
            final /* synthetic */ Status vb;

            C06891(C0687a c0687a, Status status) {
                this.Iy = c0687a;
                this.vb = status;
            }

            public String getMatchId() {
                return this.Iy.uS;
            }

            public Status getStatus() {
                return this.vb;
            }
        }

        public C0687a(String str) {
            this.uS = str;
        }

        public CancelMatchResult m2311D(Status status) {
            return new C06891(this, status);
        }

        public /* synthetic */ Result m2312d(Status status) {
            return m2311D(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.gp.9 */
    class C06889 extends C0687a {
        final /* synthetic */ gp Iq;
        final /* synthetic */ String Ir;

        C06889(gp gpVar, String str, String str2) {
            this.Iq = gpVar;
            this.Ir = str2;
            super(str);
        }

        protected void m2314a(fx fxVar) {
            fxVar.m1909g(this, this.Ir);
        }
    }

    public PendingResult<InitiateMatchResult> acceptInvitation(GoogleApiClient apiClient, String invitationId) {
        return apiClient.m366b(new C06804(this, invitationId));
    }

    public PendingResult<CancelMatchResult> cancelMatch(GoogleApiClient apiClient, String matchId) {
        return apiClient.m366b(new C06889(this, matchId, matchId));
    }

    public PendingResult<InitiateMatchResult> createMatch(GoogleApiClient apiClient, TurnBasedMatchConfig config) {
        return apiClient.m366b(new C06761(this, config));
    }

    public void declineInvitation(GoogleApiClient apiClient, String invitationId) {
        Games.m843c(apiClient).m1913m(invitationId, 1);
    }

    public void dismissInvitation(GoogleApiClient apiClient, String invitationId) {
        Games.m843c(apiClient).m1912l(invitationId, 1);
    }

    public void dismissMatch(GoogleApiClient apiClient, String matchId) {
        Games.m843c(apiClient).av(matchId);
    }

    public PendingResult<UpdateMatchResult> finishMatch(GoogleApiClient apiClient, String matchId) {
        return finishMatch(apiClient, matchId, null, (ParticipantResult[]) null);
    }

    public PendingResult<UpdateMatchResult> finishMatch(GoogleApiClient apiClient, String matchId, byte[] matchData, List<ParticipantResult> results) {
        return finishMatch(apiClient, matchId, matchData, results == null ? null : (ParticipantResult[]) results.toArray(new ParticipantResult[results.size()]));
    }

    public PendingResult<UpdateMatchResult> finishMatch(GoogleApiClient apiClient, String matchId, byte[] matchData, ParticipantResult... results) {
        return apiClient.m366b(new C06836(this, matchId, matchData, results));
    }

    public Intent getInboxIntent(GoogleApiClient apiClient) {
        return Games.m843c(apiClient).ft();
    }

    public int getMaxMatchDataSize(GoogleApiClient apiClient) {
        return Games.m843c(apiClient).fC();
    }

    public Intent getSelectOpponentsIntent(GoogleApiClient apiClient, int minPlayers, int maxPlayers) {
        return Games.m843c(apiClient).m1863a(minPlayers, maxPlayers, true);
    }

    public Intent getSelectOpponentsIntent(GoogleApiClient apiClient, int minPlayers, int maxPlayers, boolean allowAutomatch) {
        return Games.m843c(apiClient).m1863a(minPlayers, maxPlayers, allowAutomatch);
    }

    public PendingResult<LeaveMatchResult> leaveMatch(GoogleApiClient apiClient, String matchId) {
        return apiClient.m366b(new C06857(this, matchId));
    }

    public PendingResult<LeaveMatchResult> leaveMatchDuringTurn(GoogleApiClient apiClient, String matchId, String pendingParticipantId) {
        return apiClient.m366b(new C06868(this, matchId, pendingParticipantId));
    }

    public PendingResult<LoadMatchResult> loadMatch(GoogleApiClient apiClient, String matchId) {
        return apiClient.m365a(new C06782(this, matchId));
    }

    public PendingResult<LoadMatchesResult> loadMatchesByStatus(GoogleApiClient apiClient, int invitationSortOrder, int[] matchTurnStatuses) {
        return apiClient.m365a(new AnonymousClass10(this, invitationSortOrder, matchTurnStatuses));
    }

    public PendingResult<LoadMatchesResult> loadMatchesByStatus(GoogleApiClient apiClient, int[] matchTurnStatuses) {
        return loadMatchesByStatus(apiClient, 0, matchTurnStatuses);
    }

    public void registerMatchUpdateListener(GoogleApiClient apiClient, OnTurnBasedMatchUpdateReceivedListener listener) {
        Games.m843c(apiClient).m1888a(listener);
    }

    public PendingResult<InitiateMatchResult> rematch(GoogleApiClient apiClient, String matchId) {
        return apiClient.m366b(new C06793(this, matchId));
    }

    public PendingResult<UpdateMatchResult> takeTurn(GoogleApiClient apiClient, String matchId, byte[] matchData, String pendingParticipantId) {
        return takeTurn(apiClient, matchId, matchData, pendingParticipantId, (ParticipantResult[]) null);
    }

    public PendingResult<UpdateMatchResult> takeTurn(GoogleApiClient apiClient, String matchId, byte[] matchData, String pendingParticipantId, List<ParticipantResult> results) {
        return takeTurn(apiClient, matchId, matchData, pendingParticipantId, results == null ? null : (ParticipantResult[]) results.toArray(new ParticipantResult[results.size()]));
    }

    public PendingResult<UpdateMatchResult> takeTurn(GoogleApiClient apiClient, String matchId, byte[] matchData, String pendingParticipantId, ParticipantResult... results) {
        return apiClient.m366b(new C06825(this, matchId, matchData, pendingParticipantId, results));
    }

    public void unregisterMatchUpdateListener(GoogleApiClient apiClient) {
        Games.m843c(apiClient).fw();
    }
}
