package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.util.TimeUtils;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value.Escaping;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.ir.C0749a;
import com.google.android.gms.internal.ir.C0752b;
import com.google.android.gms.internal.ir.C0753c;
import com.google.android.gms.internal.ir.C0754d;
import com.google.android.gms.internal.ir.C0756f;
import com.google.android.gms.internal.ir.C0757g;
import com.google.android.gms.internal.ir.C0758h;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class is implements Creator<ir> {
    static void m2488a(ir irVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        Set hB = irVar.hB();
        if (hB.contains(Integer.valueOf(1))) {
            C0265b.m501c(parcel, 1, irVar.getVersionCode());
        }
        if (hB.contains(Integer.valueOf(2))) {
            C0265b.m491a(parcel, 2, irVar.getAboutMe(), true);
        }
        if (hB.contains(Integer.valueOf(3))) {
            C0265b.m489a(parcel, 3, irVar.hW(), i, true);
        }
        if (hB.contains(Integer.valueOf(4))) {
            C0265b.m491a(parcel, 4, irVar.getBirthday(), true);
        }
        if (hB.contains(Integer.valueOf(5))) {
            C0265b.m491a(parcel, 5, irVar.getBraggingRights(), true);
        }
        if (hB.contains(Integer.valueOf(6))) {
            C0265b.m501c(parcel, 6, irVar.getCircledByCount());
        }
        if (hB.contains(Integer.valueOf(7))) {
            C0265b.m489a(parcel, 7, irVar.hX(), i, true);
        }
        if (hB.contains(Integer.valueOf(8))) {
            C0265b.m491a(parcel, 8, irVar.getCurrentLocation(), true);
        }
        if (hB.contains(Integer.valueOf(9))) {
            C0265b.m491a(parcel, 9, irVar.getDisplayName(), true);
        }
        if (hB.contains(Integer.valueOf(12))) {
            C0265b.m501c(parcel, 12, irVar.getGender());
        }
        if (hB.contains(Integer.valueOf(14))) {
            C0265b.m491a(parcel, 14, irVar.getId(), true);
        }
        if (hB.contains(Integer.valueOf(15))) {
            C0265b.m489a(parcel, 15, irVar.hY(), i, true);
        }
        if (hB.contains(Integer.valueOf(16))) {
            C0265b.m494a(parcel, 16, irVar.isPlusUser());
        }
        if (hB.contains(Integer.valueOf(19))) {
            C0265b.m489a(parcel, 19, irVar.hZ(), i, true);
        }
        if (hB.contains(Integer.valueOf(18))) {
            C0265b.m491a(parcel, 18, irVar.getLanguage(), true);
        }
        if (hB.contains(Integer.valueOf(21))) {
            C0265b.m501c(parcel, 21, irVar.getObjectType());
        }
        if (hB.contains(Integer.valueOf(20))) {
            C0265b.m491a(parcel, 20, irVar.getNickname(), true);
        }
        if (hB.contains(Integer.valueOf(23))) {
            C0265b.m500b(parcel, 23, irVar.ib(), true);
        }
        if (hB.contains(Integer.valueOf(22))) {
            C0265b.m500b(parcel, 22, irVar.ia(), true);
        }
        if (hB.contains(Integer.valueOf(25))) {
            C0265b.m501c(parcel, 25, irVar.getRelationshipStatus());
        }
        if (hB.contains(Integer.valueOf(24))) {
            C0265b.m501c(parcel, 24, irVar.getPlusOneCount());
        }
        if (hB.contains(Integer.valueOf(27))) {
            C0265b.m491a(parcel, 27, irVar.getUrl(), true);
        }
        if (hB.contains(Integer.valueOf(26))) {
            C0265b.m491a(parcel, 26, irVar.getTagline(), true);
        }
        if (hB.contains(Integer.valueOf(29))) {
            C0265b.m494a(parcel, 29, irVar.isVerified());
        }
        if (hB.contains(Integer.valueOf(28))) {
            C0265b.m500b(parcel, 28, irVar.ic(), true);
        }
        C0265b.m481D(parcel, p);
    }

    public ir aI(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        Set hashSet = new HashSet();
        int i = 0;
        String str = null;
        C0749a c0749a = null;
        String str2 = null;
        String str3 = null;
        int i2 = 0;
        C0752b c0752b = null;
        String str4 = null;
        String str5 = null;
        int i3 = 0;
        String str6 = null;
        C0753c c0753c = null;
        boolean z = false;
        String str7 = null;
        C0754d c0754d = null;
        String str8 = null;
        int i4 = 0;
        List list = null;
        List list2 = null;
        int i5 = 0;
        int i6 = 0;
        String str9 = null;
        String str10 = null;
        List list3 = null;
        boolean z2 = false;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case Error.BAD_CVC /*3*/:
                    C0749a c0749a2 = (C0749a) C0264a.m446a(parcel, n, C0749a.CREATOR);
                    hashSet.add(Integer.valueOf(3));
                    c0749a = c0749a2;
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    str2 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(4));
                    break;
                case Error.DECLINED /*5*/:
                    str3 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(5));
                    break;
                case Error.OTHER /*6*/:
                    i2 = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(6));
                    break;
                case Error.AVS_DECLINE /*7*/:
                    C0752b c0752b2 = (C0752b) C0264a.m446a(parcel, n, C0752b.CREATOR);
                    hashSet.add(Integer.valueOf(7));
                    c0752b = c0752b2;
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    str4 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(8));
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    str5 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(9));
                    break;
                case CommonStatusCodes.DATE_INVALID /*12*/:
                    i3 = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(12));
                    break;
                case GamesStatusCodes.STATUS_INTERRUPTED /*14*/:
                    str6 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(14));
                    break;
                case GamesStatusCodes.STATUS_TIMEOUT /*15*/:
                    C0753c c0753c2 = (C0753c) C0264a.m446a(parcel, n, C0753c.CREATOR);
                    hashSet.add(Integer.valueOf(15));
                    c0753c = c0753c2;
                    break;
                case Escaping.CONVERT_JS_VALUE_TO_EXPRESSION /*16*/:
                    z = C0264a.m453c(parcel, n);
                    hashSet.add(Integer.valueOf(16));
                    break;
                case 18:
                    str7 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(18));
                    break;
                case TimeUtils.HUNDRED_DAY_FIELD_LEN /*19*/:
                    C0754d c0754d2 = (C0754d) C0264a.m446a(parcel, n, C0754d.CREATOR);
                    hashSet.add(Integer.valueOf(19));
                    c0754d = c0754d2;
                    break;
                case 20:
                    str8 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(20));
                    break;
                case 21:
                    i4 = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(21));
                    break;
                case 22:
                    list = C0264a.m452c(parcel, n, C0756f.CREATOR);
                    hashSet.add(Integer.valueOf(22));
                    break;
                case 23:
                    list2 = C0264a.m452c(parcel, n, C0757g.CREATOR);
                    hashSet.add(Integer.valueOf(23));
                    break;
                case 24:
                    i5 = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(24));
                    break;
                case 25:
                    i6 = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(25));
                    break;
                case 26:
                    str9 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(26));
                    break;
                case 27:
                    str10 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(27));
                    break;
                case 28:
                    list3 = C0264a.m452c(parcel, n, C0758h.CREATOR);
                    hashSet.add(Integer.valueOf(28));
                    break;
                case 29:
                    z2 = C0264a.m453c(parcel, n);
                    hashSet.add(Integer.valueOf(29));
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new ir(hashSet, i, str, c0749a, str2, str3, i2, c0752b, str4, str5, i3, str6, c0753c, z, str7, c0754d, str8, i4, list, list2, i5, i6, str9, str10, list3, z2);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public ir[] bF(int i) {
        return new ir[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aI(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bF(x0);
    }
}
