package com.google.android.gms.internal;

public final class gu {
    public static String aW(int i) {
        switch (i) {
            case Base64Encoder.DEFAULT /*0*/:
                return "DAILY";
            case Base64Encoder.NO_PADDING /*1*/:
                return "WEEKLY";
            case Base64Encoder.URL_SAFE /*2*/:
                return "ALL_TIME";
            default:
                throw new IllegalArgumentException("Unknown time span " + i);
        }
    }
}
