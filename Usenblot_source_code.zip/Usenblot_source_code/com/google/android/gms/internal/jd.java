package com.google.android.gms.internal;

import com.google.android.gms.internal.C0492c.C0487f;
import com.google.android.gms.internal.C0492c.C0491j;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.io.IOException;

public interface jd {

    /* renamed from: com.google.android.gms.internal.jd.a */
    public static final class C0761a extends ka<C0761a> {
        public long Yb;
        public C0491j Yc;
        public C0487f fV;

        public C0761a() {
            kw();
        }

        public static C0761a m2510l(byte[] bArr) throws kd {
            return (C0761a) ke.m727a(new C0761a(), bArr);
        }

        public void m2511a(jz jzVar) throws IOException {
            jzVar.m2579b(1, this.Yb);
            if (this.fV != null) {
                jzVar.m2576a(2, this.fV);
            }
            if (this.Yc != null) {
                jzVar.m2576a(3, this.Yc);
            }
            super.m1098a(jzVar);
        }

        public /* synthetic */ ke m2512b(jy jyVar) throws IOException {
            return m2514n(jyVar);
        }

        public int m2513c() {
            int c = super.m1100c() + jz.m2566d(1, this.Yb);
            if (this.fV != null) {
                c += jz.m2562b(2, this.fV);
            }
            if (this.Yc != null) {
                c += jz.m2562b(3, this.Yc);
            }
            this.DY = c;
            return c;
        }

        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            if (!(o instanceof C0761a)) {
                return false;
            }
            C0761a c0761a = (C0761a) o;
            if (this.Yb != c0761a.Yb) {
                return false;
            }
            if (this.fV == null) {
                if (c0761a.fV != null) {
                    return false;
                }
            } else if (!this.fV.equals(c0761a.fV)) {
                return false;
            }
            if (this.Yc == null) {
                if (c0761a.Yc != null) {
                    return false;
                }
            } else if (!this.Yc.equals(c0761a.Yc)) {
                return false;
            }
            return (this.aae == null || this.aae.isEmpty()) ? c0761a.aae == null || c0761a.aae.isEmpty() : this.aae.equals(c0761a.aae);
        }

        public int hashCode() {
            int i = 0;
            int hashCode = ((this.Yc == null ? 0 : this.Yc.hashCode()) + (((this.fV == null ? 0 : this.fV.hashCode()) + ((((int) (this.Yb ^ (this.Yb >>> 32))) + 527) * 31)) * 31)) * 31;
            if (!(this.aae == null || this.aae.isEmpty())) {
                i = this.aae.hashCode();
            }
            return hashCode + i;
        }

        public C0761a kw() {
            this.Yb = 0;
            this.fV = null;
            this.Yc = null;
            this.aae = null;
            this.DY = -1;
            return this;
        }

        public C0761a m2514n(jy jyVar) throws IOException {
            while (true) {
                int ky = jyVar.ky();
                switch (ky) {
                    case Base64Encoder.DEFAULT /*0*/:
                        break;
                    case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                        this.Yb = jyVar.kA();
                        continue;
                    case 18:
                        if (this.fV == null) {
                            this.fV = new C0487f();
                        }
                        jyVar.m2554a(this.fV);
                        continue;
                    case 26:
                        if (this.Yc == null) {
                            this.Yc = new C0491j();
                        }
                        jyVar.m2554a(this.Yc);
                        continue;
                    default:
                        if (!m1099a(jyVar, ky)) {
                            break;
                        }
                        continue;
                }
                return this;
            }
        }
    }
}
