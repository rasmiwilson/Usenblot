package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.internal.ir.C0754d;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.HashSet;
import java.util.Set;

public class iy implements Creator<C0754d> {
    static void m2494a(C0754d c0754d, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        Set hB = c0754d.hB();
        if (hB.contains(Integer.valueOf(1))) {
            C0265b.m501c(parcel, 1, c0754d.getVersionCode());
        }
        if (hB.contains(Integer.valueOf(2))) {
            C0265b.m491a(parcel, 2, c0754d.getFamilyName(), true);
        }
        if (hB.contains(Integer.valueOf(3))) {
            C0265b.m491a(parcel, 3, c0754d.getFormatted(), true);
        }
        if (hB.contains(Integer.valueOf(4))) {
            C0265b.m491a(parcel, 4, c0754d.getGivenName(), true);
        }
        if (hB.contains(Integer.valueOf(5))) {
            C0265b.m491a(parcel, 5, c0754d.getHonorificPrefix(), true);
        }
        if (hB.contains(Integer.valueOf(6))) {
            C0265b.m491a(parcel, 6, c0754d.getHonorificSuffix(), true);
        }
        if (hB.contains(Integer.valueOf(7))) {
            C0265b.m491a(parcel, 7, c0754d.getMiddleName(), true);
        }
        C0265b.m481D(parcel, p);
    }

    public C0754d aO(Parcel parcel) {
        String str = null;
        int o = C0264a.m466o(parcel);
        Set hashSet = new HashSet();
        int i = 0;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str6 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case Error.BAD_CVC /*3*/:
                    str5 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(3));
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    str4 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(4));
                    break;
                case Error.DECLINED /*5*/:
                    str3 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(5));
                    break;
                case Error.OTHER /*6*/:
                    str2 = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(6));
                    break;
                case Error.AVS_DECLINE /*7*/:
                    str = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(7));
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new C0754d(hashSet, i, str6, str5, str4, str3, str2, str);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public C0754d[] bL(int i) {
        return new C0754d[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aO(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bL(x0);
    }
}
