package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.location.LocationStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public class hk implements Creator<hj> {
    static void m2390a(hj hjVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m491a(parcel, 1, hjVar.getRequestId(), false);
        C0265b.m501c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, hjVar.getVersionCode());
        C0265b.m485a(parcel, 2, hjVar.getExpirationTime());
        C0265b.m493a(parcel, 3, hjVar.gn());
        C0265b.m483a(parcel, 4, hjVar.getLatitude());
        C0265b.m483a(parcel, 5, hjVar.getLongitude());
        C0265b.m484a(parcel, 6, hjVar.go());
        C0265b.m501c(parcel, 7, hjVar.gp());
        C0265b.m501c(parcel, 8, hjVar.getNotificationResponsiveness());
        C0265b.m501c(parcel, 9, hjVar.gq());
        C0265b.m481D(parcel, p);
    }

    public hj av(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        String str = null;
        int i2 = 0;
        short s = (short) 0;
        double d = 0.0d;
        double d2 = 0.0d;
        float f = 0.0f;
        long j = 0;
        int i3 = 0;
        int i4 = -1;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    j = C0264a.m458h(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    s = C0264a.m456f(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    d = C0264a.m461k(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    d2 = C0264a.m461k(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    f = C0264a.m460j(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    i3 = C0264a.m457g(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    i4 = C0264a.m457g(parcel, n);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new hj(i, str, i2, s, d, d2, f, j, i3, i4);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public hj[] bp(int i) {
        return new hj[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return av(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bp(x0);
    }
}
