package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.internal.cb.C0493a;
import com.google.android.gms.internal.cb.C0494b;

public final class ca {

    /* renamed from: com.google.android.gms.internal.ca.a */
    public interface C0481a {
        void m1084a(cf cfVar);
    }

    public static ct m1158a(Context context, cd cdVar, C0481a c0481a) {
        return cdVar.kN.pX ? m1159b(context, cdVar, c0481a) : m1160c(context, cdVar, c0481a);
    }

    private static ct m1159b(Context context, cd cdVar, C0481a c0481a) {
        da.m1269s("Fetching ad response from local ad request service.");
        ct c0493a = new C0493a(context, cdVar, c0481a);
        c0493a.start();
        return c0493a;
    }

    private static ct m1160c(Context context, cd cdVar, C0481a c0481a) {
        da.m1269s("Fetching ad response from remote ad request service.");
        if (GooglePlayServicesUtil.isGooglePlayServicesAvailable(context) == 0) {
            return new C0494b(context, cdVar, c0481a);
        }
        da.m1273w("Failed to connect to remote ad request service.");
        return null;
    }
}
