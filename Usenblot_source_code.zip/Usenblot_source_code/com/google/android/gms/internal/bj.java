package com.google.android.gms.internal;

import com.google.ads.AdRequest.ErrorCode;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;

public final class bj<NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> implements MediationBannerListener, MediationInterstitialListener {
    private final bh mT;

    /* renamed from: com.google.android.gms.internal.bj.10 */
    class AnonymousClass10 implements Runnable {
        final /* synthetic */ bj mU;
        final /* synthetic */ ErrorCode mV;

        AnonymousClass10(bj bjVar, ErrorCode errorCode) {
            this.mU = bjVar;
            this.mV = errorCode;
        }

        public void run() {
            try {
                this.mU.mT.onAdFailedToLoad(bk.m1035a(this.mV));
            } catch (Throwable e) {
                da.m1267b("Could not call onAdFailedToLoad.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bj.1 */
    class C04551 implements Runnable {
        final /* synthetic */ bj mU;

        C04551(bj bjVar) {
            this.mU = bjVar;
        }

        public void run() {
            try {
                this.mU.mT.m994O();
            } catch (Throwable e) {
                da.m1267b("Could not call onAdClicked.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bj.2 */
    class C04562 implements Runnable {
        final /* synthetic */ bj mU;

        C04562(bj bjVar) {
            this.mU = bjVar;
        }

        public void run() {
            try {
                this.mU.mT.onAdOpened();
            } catch (Throwable e) {
                da.m1267b("Could not call onAdOpened.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bj.3 */
    class C04573 implements Runnable {
        final /* synthetic */ bj mU;

        C04573(bj bjVar) {
            this.mU = bjVar;
        }

        public void run() {
            try {
                this.mU.mT.onAdLoaded();
            } catch (Throwable e) {
                da.m1267b("Could not call onAdLoaded.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bj.4 */
    class C04584 implements Runnable {
        final /* synthetic */ bj mU;

        C04584(bj bjVar) {
            this.mU = bjVar;
        }

        public void run() {
            try {
                this.mU.mT.onAdClosed();
            } catch (Throwable e) {
                da.m1267b("Could not call onAdClosed.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bj.5 */
    class C04595 implements Runnable {
        final /* synthetic */ bj mU;
        final /* synthetic */ ErrorCode mV;

        C04595(bj bjVar, ErrorCode errorCode) {
            this.mU = bjVar;
            this.mV = errorCode;
        }

        public void run() {
            try {
                this.mU.mT.onAdFailedToLoad(bk.m1035a(this.mV));
            } catch (Throwable e) {
                da.m1267b("Could not call onAdFailedToLoad.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bj.6 */
    class C04606 implements Runnable {
        final /* synthetic */ bj mU;

        C04606(bj bjVar) {
            this.mU = bjVar;
        }

        public void run() {
            try {
                this.mU.mT.onAdLeftApplication();
            } catch (Throwable e) {
                da.m1267b("Could not call onAdLeftApplication.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bj.7 */
    class C04617 implements Runnable {
        final /* synthetic */ bj mU;

        C04617(bj bjVar) {
            this.mU = bjVar;
        }

        public void run() {
            try {
                this.mU.mT.onAdOpened();
            } catch (Throwable e) {
                da.m1267b("Could not call onAdOpened.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bj.8 */
    class C04628 implements Runnable {
        final /* synthetic */ bj mU;

        C04628(bj bjVar) {
            this.mU = bjVar;
        }

        public void run() {
            try {
                this.mU.mT.onAdLoaded();
            } catch (Throwable e) {
                da.m1267b("Could not call onAdLoaded.", e);
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.bj.9 */
    class C04639 implements Runnable {
        final /* synthetic */ bj mU;

        C04639(bj bjVar) {
            this.mU = bjVar;
        }

        public void run() {
            try {
                this.mU.mT.onAdClosed();
            } catch (Throwable e) {
                da.m1267b("Could not call onAdClosed.", e);
            }
        }
    }

    public bj(bh bhVar) {
        this.mT = bhVar;
    }

    public void onClick(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        da.m1269s("Adapter called onClick.");
        if (cz.aX()) {
            try {
                this.mT.m994O();
                return;
            } catch (Throwable e) {
                da.m1267b("Could not call onAdClicked.", e);
                return;
            }
        }
        da.m1273w("onClick must be called on the main UI thread.");
        cz.pT.post(new C04551(this));
    }

    public void onDismissScreen(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        da.m1269s("Adapter called onDismissScreen.");
        if (cz.aX()) {
            try {
                this.mT.onAdClosed();
                return;
            } catch (Throwable e) {
                da.m1267b("Could not call onAdClosed.", e);
                return;
            }
        }
        da.m1273w("onDismissScreen must be called on the main UI thread.");
        cz.pT.post(new C04584(this));
    }

    public void onDismissScreen(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        da.m1269s("Adapter called onDismissScreen.");
        if (cz.aX()) {
            try {
                this.mT.onAdClosed();
                return;
            } catch (Throwable e) {
                da.m1267b("Could not call onAdClosed.", e);
                return;
            }
        }
        da.m1273w("onDismissScreen must be called on the main UI thread.");
        cz.pT.post(new C04639(this));
    }

    public void onFailedToReceiveAd(MediationBannerAdapter<?, ?> mediationBannerAdapter, ErrorCode errorCode) {
        da.m1269s("Adapter called onFailedToReceiveAd with error. " + errorCode);
        if (cz.aX()) {
            try {
                this.mT.onAdFailedToLoad(bk.m1035a(errorCode));
                return;
            } catch (Throwable e) {
                da.m1267b("Could not call onAdFailedToLoad.", e);
                return;
            }
        }
        da.m1273w("onFailedToReceiveAd must be called on the main UI thread.");
        cz.pT.post(new C04595(this, errorCode));
    }

    public void onFailedToReceiveAd(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter, ErrorCode errorCode) {
        da.m1269s("Adapter called onFailedToReceiveAd with error " + errorCode + ".");
        if (cz.aX()) {
            try {
                this.mT.onAdFailedToLoad(bk.m1035a(errorCode));
                return;
            } catch (Throwable e) {
                da.m1267b("Could not call onAdFailedToLoad.", e);
                return;
            }
        }
        da.m1273w("onFailedToReceiveAd must be called on the main UI thread.");
        cz.pT.post(new AnonymousClass10(this, errorCode));
    }

    public void onLeaveApplication(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        da.m1269s("Adapter called onLeaveApplication.");
        if (cz.aX()) {
            try {
                this.mT.onAdLeftApplication();
                return;
            } catch (Throwable e) {
                da.m1267b("Could not call onAdLeftApplication.", e);
                return;
            }
        }
        da.m1273w("onLeaveApplication must be called on the main UI thread.");
        cz.pT.post(new C04606(this));
    }

    public void onLeaveApplication(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        da.m1269s("Adapter called onLeaveApplication.");
        if (cz.aX()) {
            try {
                this.mT.onAdLeftApplication();
                return;
            } catch (Throwable e) {
                da.m1267b("Could not call onAdLeftApplication.", e);
                return;
            }
        }
        da.m1273w("onLeaveApplication must be called on the main UI thread.");
        cz.pT.post(new Runnable() {
            final /* synthetic */ bj mU;

            {
                this.mU = r1;
            }

            public void run() {
                try {
                    this.mU.mT.onAdLeftApplication();
                } catch (Throwable e) {
                    da.m1267b("Could not call onAdLeftApplication.", e);
                }
            }
        });
    }

    public void onPresentScreen(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        da.m1269s("Adapter called onPresentScreen.");
        if (cz.aX()) {
            try {
                this.mT.onAdOpened();
                return;
            } catch (Throwable e) {
                da.m1267b("Could not call onAdOpened.", e);
                return;
            }
        }
        da.m1273w("onPresentScreen must be called on the main UI thread.");
        cz.pT.post(new C04617(this));
    }

    public void onPresentScreen(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        da.m1269s("Adapter called onPresentScreen.");
        if (cz.aX()) {
            try {
                this.mT.onAdOpened();
                return;
            } catch (Throwable e) {
                da.m1267b("Could not call onAdOpened.", e);
                return;
            }
        }
        da.m1273w("onPresentScreen must be called on the main UI thread.");
        cz.pT.post(new C04562(this));
    }

    public void onReceivedAd(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        da.m1269s("Adapter called onReceivedAd.");
        if (cz.aX()) {
            try {
                this.mT.onAdLoaded();
                return;
            } catch (Throwable e) {
                da.m1267b("Could not call onAdLoaded.", e);
                return;
            }
        }
        da.m1273w("onReceivedAd must be called on the main UI thread.");
        cz.pT.post(new C04628(this));
    }

    public void onReceivedAd(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        da.m1269s("Adapter called onReceivedAd.");
        if (cz.aX()) {
            try {
                this.mT.onAdLoaded();
                return;
            } catch (Throwable e) {
                da.m1267b("Could not call onAdLoaded.", e);
                return;
            }
        }
        da.m1273w("onReceivedAd must be called on the main UI thread.");
        cz.pT.post(new C04573(this));
    }
}
