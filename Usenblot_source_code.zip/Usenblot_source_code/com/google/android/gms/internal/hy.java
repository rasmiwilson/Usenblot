package com.google.android.gms.internal;

import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.location.LocationStatusCodes;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.List;

public class hy implements Creator<hx> {
    static void m2399a(hx hxVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m491a(parcel, 1, hxVar.getId(), false);
        C0265b.m486a(parcel, 2, hxVar.gE(), false);
        C0265b.m489a(parcel, 3, hxVar.gF(), i, false);
        C0265b.m489a(parcel, 4, hxVar.gx(), i, false);
        C0265b.m484a(parcel, 5, hxVar.gy());
        C0265b.m489a(parcel, 6, hxVar.gz(), i, false);
        C0265b.m491a(parcel, 7, hxVar.gG(), false);
        C0265b.m489a(parcel, 8, hxVar.gA(), i, false);
        C0265b.m494a(parcel, 9, hxVar.gB());
        C0265b.m484a(parcel, 10, hxVar.getRating());
        C0265b.m501c(parcel, 11, hxVar.gC());
        C0265b.m485a(parcel, 12, hxVar.gD());
        C0265b.m500b(parcel, 13, hxVar.gw(), false);
        C0265b.m501c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, hxVar.wj);
        C0265b.m481D(parcel, p);
    }

    public hx aB(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        String str = null;
        List list = null;
        Bundle bundle = null;
        hz hzVar = null;
        LatLng latLng = null;
        float f = 0.0f;
        LatLngBounds latLngBounds = null;
        String str2 = null;
        Uri uri = null;
        boolean z = false;
        float f2 = 0.0f;
        int i2 = 0;
        long j = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    bundle = C0264a.m467o(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    hzVar = (hz) C0264a.m446a(parcel, n, hz.CREATOR);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    latLng = (LatLng) C0264a.m446a(parcel, n, LatLng.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    f = C0264a.m460j(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    latLngBounds = (LatLngBounds) C0264a.m446a(parcel, n, LatLngBounds.CREATOR);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    uri = (Uri) C0264a.m446a(parcel, n, Uri.CREATOR);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    z = C0264a.m453c(parcel, n);
                    break;
                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                    f2 = C0264a.m460j(parcel, n);
                    break;
                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case CommonStatusCodes.DATE_INVALID /*12*/:
                    j = C0264a.m458h(parcel, n);
                    break;
                case CommonStatusCodes.ERROR /*13*/:
                    list = C0264a.m452c(parcel, n, ht.CREATOR);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new hx(i, str, list, bundle, hzVar, latLng, f, latLngBounds, str2, uri, z, f2, i2, j);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public hx[] bw(int i) {
        return new hx[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aB(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bw(x0);
    }
}
