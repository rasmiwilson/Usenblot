package com.google.android.gms.internal;

public final class fz {
    private static final el Hy;

    static {
        Hy = new el("Games");
    }

    public static void m1915a(String str, String str2, Throwable th) {
        Hy.m1485a(str, str2, th);
    }

    public static void m1916f(String str, String str2) {
        Hy.m1486f(str, str2);
    }

    public static void m1917g(String str, String str2) {
        Hy.m1487g(str, str2);
    }

    public static void m1918h(String str, String str2) {
        Hy.m1488h(str, str2);
    }
}
