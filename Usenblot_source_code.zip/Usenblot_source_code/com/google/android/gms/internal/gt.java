package com.google.android.gms.internal;

import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;

public final class gt {
    public static boolean isValid(int outcome) {
        switch (outcome) {
            case Base64Encoder.DEFAULT /*0*/:
            case Base64Encoder.NO_PADDING /*1*/:
            case Base64Encoder.URL_SAFE /*2*/:
            case Error.BAD_CVC /*3*/:
                return true;
            default:
                return false;
        }
    }
}
