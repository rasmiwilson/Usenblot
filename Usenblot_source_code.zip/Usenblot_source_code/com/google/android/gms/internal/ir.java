package com.google.android.gms.internal;

import android.os.Parcel;
import android.support.v4.util.TimeUtils;
import com.google.analytics.midtier.proto.containertag.TypeSystem.Value.Escaping;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.fb.C0587a;
import com.google.android.gms.plus.PlusShare;
import com.google.android.gms.plus.model.people.Person;
import com.google.android.gms.plus.model.people.Person.AgeRange;
import com.google.android.gms.plus.model.people.Person.Cover;
import com.google.android.gms.plus.model.people.Person.Cover.CoverInfo;
import com.google.android.gms.plus.model.people.Person.Cover.CoverPhoto;
import com.google.android.gms.plus.model.people.Person.Image;
import com.google.android.gms.plus.model.people.Person.Name;
import com.google.android.gms.plus.model.people.Person.Organizations;
import com.google.android.gms.plus.model.people.Person.PlacesLived;
import com.google.android.gms.plus.model.people.Person.Urls;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class ir extends fb implements SafeParcelable, Person {
    public static final is CREATOR;
    private static final HashMap<String, C0587a<?, ?>> RL;
    private String FE;
    private final Set<Integer> RM;
    private String SK;
    private C0749a SL;
    private String SM;
    private String SN;
    private int SO;
    private C0752b SP;
    private String SQ;
    private C0753c SR;
    private boolean SS;
    private String ST;
    private C0754d SU;
    private String SV;
    private int SW;
    private List<C0756f> SX;
    private List<C0757g> SY;
    private int SZ;
    private int Ta;
    private String Tb;
    private List<C0758h> Tc;
    private boolean Td;
    private int lu;
    private String pS;
    private String uS;
    private final int wj;

    /* renamed from: com.google.android.gms.internal.ir.a */
    public static final class C0749a extends fb implements SafeParcelable, AgeRange {
        public static final it CREATOR;
        private static final HashMap<String, C0587a<?, ?>> RL;
        private final Set<Integer> RM;
        private int Te;
        private int Tf;
        private final int wj;

        static {
            CREATOR = new it();
            RL = new HashMap();
            RL.put("max", C0587a.m1597g("max", 2));
            RL.put("min", C0587a.m1597g("min", 3));
        }

        public C0749a() {
            this.wj = 1;
            this.RM = new HashSet();
        }

        C0749a(Set<Integer> set, int i, int i2, int i3) {
            this.RM = set;
            this.wj = i;
            this.Te = i2;
            this.Tf = i3;
        }

        protected boolean m2466a(C0587a c0587a) {
            return this.RM.contains(Integer.valueOf(c0587a.eu()));
        }

        protected Object ak(String str) {
            return null;
        }

        protected boolean al(String str) {
            return false;
        }

        protected Object m2467b(C0587a c0587a) {
            switch (c0587a.eu()) {
                case Base64Encoder.URL_SAFE /*2*/:
                    return Integer.valueOf(this.Te);
                case Error.BAD_CVC /*3*/:
                    return Integer.valueOf(this.Tf);
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + c0587a.eu());
            }
        }

        public int describeContents() {
            it itVar = CREATOR;
            return 0;
        }

        public HashMap<String, C0587a<?, ?>> en() {
            return RL;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof C0749a)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            C0749a c0749a = (C0749a) obj;
            for (C0587a c0587a : RL.values()) {
                if (m2466a(c0587a)) {
                    if (!c0749a.m2466a(c0587a)) {
                        return false;
                    }
                    if (!m2467b(c0587a).equals(c0749a.m2467b(c0587a))) {
                        return false;
                    }
                } else if (c0749a.m2466a(c0587a)) {
                    return false;
                }
            }
            return true;
        }

        public /* synthetic */ Object freeze() {
            return ie();
        }

        public int getMax() {
            return this.Te;
        }

        public int getMin() {
            return this.Tf;
        }

        int getVersionCode() {
            return this.wj;
        }

        Set<Integer> hB() {
            return this.RM;
        }

        public boolean hasMax() {
            return this.RM.contains(Integer.valueOf(2));
        }

        public boolean hasMin() {
            return this.RM.contains(Integer.valueOf(3));
        }

        public int hashCode() {
            int i = 0;
            for (C0587a c0587a : RL.values()) {
                int hashCode;
                if (m2466a(c0587a)) {
                    hashCode = m2467b(c0587a).hashCode() + (i + c0587a.eu());
                } else {
                    hashCode = i;
                }
                i = hashCode;
            }
            return i;
        }

        public C0749a ie() {
            return this;
        }

        public boolean isDataValid() {
            return true;
        }

        public void writeToParcel(Parcel out, int flags) {
            it itVar = CREATOR;
            it.m2489a(this, out, flags);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.b */
    public static final class C0752b extends fb implements SafeParcelable, Cover {
        public static final iu CREATOR;
        private static final HashMap<String, C0587a<?, ?>> RL;
        private final Set<Integer> RM;
        private C0750a Tg;
        private C0751b Th;
        private int Ti;
        private final int wj;

        /* renamed from: com.google.android.gms.internal.ir.b.a */
        public static final class C0750a extends fb implements SafeParcelable, CoverInfo {
            public static final iv CREATOR;
            private static final HashMap<String, C0587a<?, ?>> RL;
            private final Set<Integer> RM;
            private int Tj;
            private int Tk;
            private final int wj;

            static {
                CREATOR = new iv();
                RL = new HashMap();
                RL.put("leftImageOffset", C0587a.m1597g("leftImageOffset", 2));
                RL.put("topImageOffset", C0587a.m1597g("topImageOffset", 3));
            }

            public C0750a() {
                this.wj = 1;
                this.RM = new HashSet();
            }

            C0750a(Set<Integer> set, int i, int i2, int i3) {
                this.RM = set;
                this.wj = i;
                this.Tj = i2;
                this.Tk = i3;
            }

            protected boolean m2468a(C0587a c0587a) {
                return this.RM.contains(Integer.valueOf(c0587a.eu()));
            }

            protected Object ak(String str) {
                return null;
            }

            protected boolean al(String str) {
                return false;
            }

            protected Object m2469b(C0587a c0587a) {
                switch (c0587a.eu()) {
                    case Base64Encoder.URL_SAFE /*2*/:
                        return Integer.valueOf(this.Tj);
                    case Error.BAD_CVC /*3*/:
                        return Integer.valueOf(this.Tk);
                    default:
                        throw new IllegalStateException("Unknown safe parcelable id=" + c0587a.eu());
                }
            }

            public int describeContents() {
                iv ivVar = CREATOR;
                return 0;
            }

            public HashMap<String, C0587a<?, ?>> en() {
                return RL;
            }

            public boolean equals(Object obj) {
                if (!(obj instanceof C0750a)) {
                    return false;
                }
                if (this == obj) {
                    return true;
                }
                C0750a c0750a = (C0750a) obj;
                for (C0587a c0587a : RL.values()) {
                    if (m2468a(c0587a)) {
                        if (!c0750a.m2468a(c0587a)) {
                            return false;
                        }
                        if (!m2469b(c0587a).equals(c0750a.m2469b(c0587a))) {
                            return false;
                        }
                    } else if (c0750a.m2468a(c0587a)) {
                        return false;
                    }
                }
                return true;
            }

            public /* synthetic */ Object freeze() {
                return ii();
            }

            public int getLeftImageOffset() {
                return this.Tj;
            }

            public int getTopImageOffset() {
                return this.Tk;
            }

            int getVersionCode() {
                return this.wj;
            }

            Set<Integer> hB() {
                return this.RM;
            }

            public boolean hasLeftImageOffset() {
                return this.RM.contains(Integer.valueOf(2));
            }

            public boolean hasTopImageOffset() {
                return this.RM.contains(Integer.valueOf(3));
            }

            public int hashCode() {
                int i = 0;
                for (C0587a c0587a : RL.values()) {
                    int hashCode;
                    if (m2468a(c0587a)) {
                        hashCode = m2469b(c0587a).hashCode() + (i + c0587a.eu());
                    } else {
                        hashCode = i;
                    }
                    i = hashCode;
                }
                return i;
            }

            public C0750a ii() {
                return this;
            }

            public boolean isDataValid() {
                return true;
            }

            public void writeToParcel(Parcel out, int flags) {
                iv ivVar = CREATOR;
                iv.m2491a(this, out, flags);
            }
        }

        /* renamed from: com.google.android.gms.internal.ir.b.b */
        public static final class C0751b extends fb implements SafeParcelable, CoverPhoto {
            public static final iw CREATOR;
            private static final HashMap<String, C0587a<?, ?>> RL;
            private final Set<Integer> RM;
            private String pS;
            private int f71v;
            private int f72w;
            private final int wj;

            static {
                CREATOR = new iw();
                RL = new HashMap();
                RL.put("height", C0587a.m1597g("height", 2));
                RL.put(PlusShare.KEY_CALL_TO_ACTION_URL, C0587a.m1600j(PlusShare.KEY_CALL_TO_ACTION_URL, 3));
                RL.put("width", C0587a.m1597g("width", 4));
            }

            public C0751b() {
                this.wj = 1;
                this.RM = new HashSet();
            }

            C0751b(Set<Integer> set, int i, int i2, String str, int i3) {
                this.RM = set;
                this.wj = i;
                this.f71v = i2;
                this.pS = str;
                this.f72w = i3;
            }

            protected boolean m2470a(C0587a c0587a) {
                return this.RM.contains(Integer.valueOf(c0587a.eu()));
            }

            protected Object ak(String str) {
                return null;
            }

            protected boolean al(String str) {
                return false;
            }

            protected Object m2471b(C0587a c0587a) {
                switch (c0587a.eu()) {
                    case Base64Encoder.URL_SAFE /*2*/:
                        return Integer.valueOf(this.f71v);
                    case Error.BAD_CVC /*3*/:
                        return this.pS;
                    case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                        return Integer.valueOf(this.f72w);
                    default:
                        throw new IllegalStateException("Unknown safe parcelable id=" + c0587a.eu());
                }
            }

            public int describeContents() {
                iw iwVar = CREATOR;
                return 0;
            }

            public HashMap<String, C0587a<?, ?>> en() {
                return RL;
            }

            public boolean equals(Object obj) {
                if (!(obj instanceof C0751b)) {
                    return false;
                }
                if (this == obj) {
                    return true;
                }
                C0751b c0751b = (C0751b) obj;
                for (C0587a c0587a : RL.values()) {
                    if (m2470a(c0587a)) {
                        if (!c0751b.m2470a(c0587a)) {
                            return false;
                        }
                        if (!m2471b(c0587a).equals(c0751b.m2471b(c0587a))) {
                            return false;
                        }
                    } else if (c0751b.m2470a(c0587a)) {
                        return false;
                    }
                }
                return true;
            }

            public /* synthetic */ Object freeze() {
                return ij();
            }

            public int getHeight() {
                return this.f71v;
            }

            public String getUrl() {
                return this.pS;
            }

            int getVersionCode() {
                return this.wj;
            }

            public int getWidth() {
                return this.f72w;
            }

            Set<Integer> hB() {
                return this.RM;
            }

            public boolean hasHeight() {
                return this.RM.contains(Integer.valueOf(2));
            }

            public boolean hasUrl() {
                return this.RM.contains(Integer.valueOf(3));
            }

            public boolean hasWidth() {
                return this.RM.contains(Integer.valueOf(4));
            }

            public int hashCode() {
                int i = 0;
                for (C0587a c0587a : RL.values()) {
                    int hashCode;
                    if (m2470a(c0587a)) {
                        hashCode = m2471b(c0587a).hashCode() + (i + c0587a.eu());
                    } else {
                        hashCode = i;
                    }
                    i = hashCode;
                }
                return i;
            }

            public C0751b ij() {
                return this;
            }

            public boolean isDataValid() {
                return true;
            }

            public void writeToParcel(Parcel out, int flags) {
                iw iwVar = CREATOR;
                iw.m2492a(this, out, flags);
            }
        }

        static {
            CREATOR = new iu();
            RL = new HashMap();
            RL.put("coverInfo", C0587a.m1594a("coverInfo", 2, C0750a.class));
            RL.put("coverPhoto", C0587a.m1594a("coverPhoto", 3, C0751b.class));
            RL.put("layout", C0587a.m1593a("layout", 4, new ey().m1571f("banner", 0), false));
        }

        public C0752b() {
            this.wj = 1;
            this.RM = new HashSet();
        }

        C0752b(Set<Integer> set, int i, C0750a c0750a, C0751b c0751b, int i2) {
            this.RM = set;
            this.wj = i;
            this.Tg = c0750a;
            this.Th = c0751b;
            this.Ti = i2;
        }

        protected boolean m2472a(C0587a c0587a) {
            return this.RM.contains(Integer.valueOf(c0587a.eu()));
        }

        protected Object ak(String str) {
            return null;
        }

        protected boolean al(String str) {
            return false;
        }

        protected Object m2473b(C0587a c0587a) {
            switch (c0587a.eu()) {
                case Base64Encoder.URL_SAFE /*2*/:
                    return this.Tg;
                case Error.BAD_CVC /*3*/:
                    return this.Th;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    return Integer.valueOf(this.Ti);
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + c0587a.eu());
            }
        }

        public int describeContents() {
            iu iuVar = CREATOR;
            return 0;
        }

        public HashMap<String, C0587a<?, ?>> en() {
            return RL;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof C0752b)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            C0752b c0752b = (C0752b) obj;
            for (C0587a c0587a : RL.values()) {
                if (m2472a(c0587a)) {
                    if (!c0752b.m2472a(c0587a)) {
                        return false;
                    }
                    if (!m2473b(c0587a).equals(c0752b.m2473b(c0587a))) {
                        return false;
                    }
                } else if (c0752b.m2472a(c0587a)) {
                    return false;
                }
            }
            return true;
        }

        public /* synthetic */ Object freeze() {
            return ih();
        }

        public CoverInfo getCoverInfo() {
            return this.Tg;
        }

        public CoverPhoto getCoverPhoto() {
            return this.Th;
        }

        public int getLayout() {
            return this.Ti;
        }

        int getVersionCode() {
            return this.wj;
        }

        Set<Integer> hB() {
            return this.RM;
        }

        public boolean hasCoverInfo() {
            return this.RM.contains(Integer.valueOf(2));
        }

        public boolean hasCoverPhoto() {
            return this.RM.contains(Integer.valueOf(3));
        }

        public boolean hasLayout() {
            return this.RM.contains(Integer.valueOf(4));
        }

        public int hashCode() {
            int i = 0;
            for (C0587a c0587a : RL.values()) {
                int hashCode;
                if (m2472a(c0587a)) {
                    hashCode = m2473b(c0587a).hashCode() + (i + c0587a.eu());
                } else {
                    hashCode = i;
                }
                i = hashCode;
            }
            return i;
        }

        C0750a m2474if() {
            return this.Tg;
        }

        C0751b ig() {
            return this.Th;
        }

        public C0752b ih() {
            return this;
        }

        public boolean isDataValid() {
            return true;
        }

        public void writeToParcel(Parcel out, int flags) {
            iu iuVar = CREATOR;
            iu.m2490a(this, out, flags);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.c */
    public static final class C0753c extends fb implements SafeParcelable, Image {
        public static final ix CREATOR;
        private static final HashMap<String, C0587a<?, ?>> RL;
        private final Set<Integer> RM;
        private String pS;
        private final int wj;

        static {
            CREATOR = new ix();
            RL = new HashMap();
            RL.put(PlusShare.KEY_CALL_TO_ACTION_URL, C0587a.m1600j(PlusShare.KEY_CALL_TO_ACTION_URL, 2));
        }

        public C0753c() {
            this.wj = 1;
            this.RM = new HashSet();
        }

        public C0753c(String str) {
            this.RM = new HashSet();
            this.wj = 1;
            this.pS = str;
            this.RM.add(Integer.valueOf(2));
        }

        C0753c(Set<Integer> set, int i, String str) {
            this.RM = set;
            this.wj = i;
            this.pS = str;
        }

        protected boolean m2475a(C0587a c0587a) {
            return this.RM.contains(Integer.valueOf(c0587a.eu()));
        }

        protected Object ak(String str) {
            return null;
        }

        protected boolean al(String str) {
            return false;
        }

        protected Object m2476b(C0587a c0587a) {
            switch (c0587a.eu()) {
                case Base64Encoder.URL_SAFE /*2*/:
                    return this.pS;
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + c0587a.eu());
            }
        }

        public int describeContents() {
            ix ixVar = CREATOR;
            return 0;
        }

        public HashMap<String, C0587a<?, ?>> en() {
            return RL;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof C0753c)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            C0753c c0753c = (C0753c) obj;
            for (C0587a c0587a : RL.values()) {
                if (m2475a(c0587a)) {
                    if (!c0753c.m2475a(c0587a)) {
                        return false;
                    }
                    if (!m2476b(c0587a).equals(c0753c.m2476b(c0587a))) {
                        return false;
                    }
                } else if (c0753c.m2475a(c0587a)) {
                    return false;
                }
            }
            return true;
        }

        public /* synthetic */ Object freeze() {
            return ik();
        }

        public String getUrl() {
            return this.pS;
        }

        int getVersionCode() {
            return this.wj;
        }

        Set<Integer> hB() {
            return this.RM;
        }

        public boolean hasUrl() {
            return this.RM.contains(Integer.valueOf(2));
        }

        public int hashCode() {
            int i = 0;
            for (C0587a c0587a : RL.values()) {
                int hashCode;
                if (m2475a(c0587a)) {
                    hashCode = m2476b(c0587a).hashCode() + (i + c0587a.eu());
                } else {
                    hashCode = i;
                }
                i = hashCode;
            }
            return i;
        }

        public C0753c ik() {
            return this;
        }

        public boolean isDataValid() {
            return true;
        }

        public void writeToParcel(Parcel out, int flags) {
            ix ixVar = CREATOR;
            ix.m2493a(this, out, flags);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.d */
    public static final class C0754d extends fb implements SafeParcelable, Name {
        public static final iy CREATOR;
        private static final HashMap<String, C0587a<?, ?>> RL;
        private final Set<Integer> RM;
        private String Sk;
        private String Sn;
        private String Tl;
        private String Tm;
        private String Tn;
        private String To;
        private final int wj;

        static {
            CREATOR = new iy();
            RL = new HashMap();
            RL.put("familyName", C0587a.m1600j("familyName", 2));
            RL.put("formatted", C0587a.m1600j("formatted", 3));
            RL.put("givenName", C0587a.m1600j("givenName", 4));
            RL.put("honorificPrefix", C0587a.m1600j("honorificPrefix", 5));
            RL.put("honorificSuffix", C0587a.m1600j("honorificSuffix", 6));
            RL.put("middleName", C0587a.m1600j("middleName", 7));
        }

        public C0754d() {
            this.wj = 1;
            this.RM = new HashSet();
        }

        C0754d(Set<Integer> set, int i, String str, String str2, String str3, String str4, String str5, String str6) {
            this.RM = set;
            this.wj = i;
            this.Sk = str;
            this.Tl = str2;
            this.Sn = str3;
            this.Tm = str4;
            this.Tn = str5;
            this.To = str6;
        }

        protected boolean m2477a(C0587a c0587a) {
            return this.RM.contains(Integer.valueOf(c0587a.eu()));
        }

        protected Object ak(String str) {
            return null;
        }

        protected boolean al(String str) {
            return false;
        }

        protected Object m2478b(C0587a c0587a) {
            switch (c0587a.eu()) {
                case Base64Encoder.URL_SAFE /*2*/:
                    return this.Sk;
                case Error.BAD_CVC /*3*/:
                    return this.Tl;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    return this.Sn;
                case Error.DECLINED /*5*/:
                    return this.Tm;
                case Error.OTHER /*6*/:
                    return this.Tn;
                case Error.AVS_DECLINE /*7*/:
                    return this.To;
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + c0587a.eu());
            }
        }

        public int describeContents() {
            iy iyVar = CREATOR;
            return 0;
        }

        public HashMap<String, C0587a<?, ?>> en() {
            return RL;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof C0754d)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            C0754d c0754d = (C0754d) obj;
            for (C0587a c0587a : RL.values()) {
                if (m2477a(c0587a)) {
                    if (!c0754d.m2477a(c0587a)) {
                        return false;
                    }
                    if (!m2478b(c0587a).equals(c0754d.m2478b(c0587a))) {
                        return false;
                    }
                } else if (c0754d.m2477a(c0587a)) {
                    return false;
                }
            }
            return true;
        }

        public /* synthetic */ Object freeze() {
            return il();
        }

        public String getFamilyName() {
            return this.Sk;
        }

        public String getFormatted() {
            return this.Tl;
        }

        public String getGivenName() {
            return this.Sn;
        }

        public String getHonorificPrefix() {
            return this.Tm;
        }

        public String getHonorificSuffix() {
            return this.Tn;
        }

        public String getMiddleName() {
            return this.To;
        }

        int getVersionCode() {
            return this.wj;
        }

        Set<Integer> hB() {
            return this.RM;
        }

        public boolean hasFamilyName() {
            return this.RM.contains(Integer.valueOf(2));
        }

        public boolean hasFormatted() {
            return this.RM.contains(Integer.valueOf(3));
        }

        public boolean hasGivenName() {
            return this.RM.contains(Integer.valueOf(4));
        }

        public boolean hasHonorificPrefix() {
            return this.RM.contains(Integer.valueOf(5));
        }

        public boolean hasHonorificSuffix() {
            return this.RM.contains(Integer.valueOf(6));
        }

        public boolean hasMiddleName() {
            return this.RM.contains(Integer.valueOf(7));
        }

        public int hashCode() {
            int i = 0;
            for (C0587a c0587a : RL.values()) {
                int hashCode;
                if (m2477a(c0587a)) {
                    hashCode = m2478b(c0587a).hashCode() + (i + c0587a.eu());
                } else {
                    hashCode = i;
                }
                i = hashCode;
            }
            return i;
        }

        public C0754d il() {
            return this;
        }

        public boolean isDataValid() {
            return true;
        }

        public void writeToParcel(Parcel out, int flags) {
            iy iyVar = CREATOR;
            iy.m2494a(this, out, flags);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.e */
    public static class C0755e {
        public static int aT(String str) {
            if (str.equals("person")) {
                return 0;
            }
            if (str.equals("page")) {
                return 1;
            }
            throw new IllegalArgumentException("Unknown objectType string: " + str);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.f */
    public static final class C0756f extends fb implements SafeParcelable, Organizations {
        public static final iz CREATOR;
        private static final HashMap<String, C0587a<?, ?>> RL;
        private int AI;
        private String CX;
        private String FH;
        private final Set<Integer> RM;
        private String Sj;
        private String Sz;
        private String Tp;
        private String Tq;
        private boolean Tr;
        private String mName;
        private final int wj;

        static {
            CREATOR = new iz();
            RL = new HashMap();
            RL.put("department", C0587a.m1600j("department", 2));
            RL.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION, C0587a.m1600j(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_DESCRIPTION, 3));
            RL.put("endDate", C0587a.m1600j("endDate", 4));
            RL.put("location", C0587a.m1600j("location", 5));
            RL.put("name", C0587a.m1600j("name", 6));
            RL.put("primary", C0587a.m1599i("primary", 7));
            RL.put("startDate", C0587a.m1600j("startDate", 8));
            RL.put(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, C0587a.m1600j(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, 9));
            RL.put("type", C0587a.m1593a("type", 10, new ey().m1571f("work", 0).m1571f("school", 1), false));
        }

        public C0756f() {
            this.wj = 1;
            this.RM = new HashSet();
        }

        C0756f(Set<Integer> set, int i, String str, String str2, String str3, String str4, String str5, boolean z, String str6, String str7, int i2) {
            this.RM = set;
            this.wj = i;
            this.Tp = str;
            this.FH = str2;
            this.Sj = str3;
            this.Tq = str4;
            this.mName = str5;
            this.Tr = z;
            this.Sz = str6;
            this.CX = str7;
            this.AI = i2;
        }

        protected boolean m2479a(C0587a c0587a) {
            return this.RM.contains(Integer.valueOf(c0587a.eu()));
        }

        protected Object ak(String str) {
            return null;
        }

        protected boolean al(String str) {
            return false;
        }

        protected Object m2480b(C0587a c0587a) {
            switch (c0587a.eu()) {
                case Base64Encoder.URL_SAFE /*2*/:
                    return this.Tp;
                case Error.BAD_CVC /*3*/:
                    return this.FH;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    return this.Sj;
                case Error.DECLINED /*5*/:
                    return this.Tq;
                case Error.OTHER /*6*/:
                    return this.mName;
                case Error.AVS_DECLINE /*7*/:
                    return Boolean.valueOf(this.Tr);
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    return this.Sz;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    return this.CX;
                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                    return Integer.valueOf(this.AI);
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + c0587a.eu());
            }
        }

        public int describeContents() {
            iz izVar = CREATOR;
            return 0;
        }

        public HashMap<String, C0587a<?, ?>> en() {
            return RL;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof C0756f)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            C0756f c0756f = (C0756f) obj;
            for (C0587a c0587a : RL.values()) {
                if (m2479a(c0587a)) {
                    if (!c0756f.m2479a(c0587a)) {
                        return false;
                    }
                    if (!m2480b(c0587a).equals(c0756f.m2480b(c0587a))) {
                        return false;
                    }
                } else if (c0756f.m2479a(c0587a)) {
                    return false;
                }
            }
            return true;
        }

        public /* synthetic */ Object freeze() {
            return im();
        }

        public String getDepartment() {
            return this.Tp;
        }

        public String getDescription() {
            return this.FH;
        }

        public String getEndDate() {
            return this.Sj;
        }

        public String getLocation() {
            return this.Tq;
        }

        public String getName() {
            return this.mName;
        }

        public String getStartDate() {
            return this.Sz;
        }

        public String getTitle() {
            return this.CX;
        }

        public int getType() {
            return this.AI;
        }

        int getVersionCode() {
            return this.wj;
        }

        Set<Integer> hB() {
            return this.RM;
        }

        public boolean hasDepartment() {
            return this.RM.contains(Integer.valueOf(2));
        }

        public boolean hasDescription() {
            return this.RM.contains(Integer.valueOf(3));
        }

        public boolean hasEndDate() {
            return this.RM.contains(Integer.valueOf(4));
        }

        public boolean hasLocation() {
            return this.RM.contains(Integer.valueOf(5));
        }

        public boolean hasName() {
            return this.RM.contains(Integer.valueOf(6));
        }

        public boolean hasPrimary() {
            return this.RM.contains(Integer.valueOf(7));
        }

        public boolean hasStartDate() {
            return this.RM.contains(Integer.valueOf(8));
        }

        public boolean hasTitle() {
            return this.RM.contains(Integer.valueOf(9));
        }

        public boolean hasType() {
            return this.RM.contains(Integer.valueOf(10));
        }

        public int hashCode() {
            int i = 0;
            for (C0587a c0587a : RL.values()) {
                int hashCode;
                if (m2479a(c0587a)) {
                    hashCode = m2480b(c0587a).hashCode() + (i + c0587a.eu());
                } else {
                    hashCode = i;
                }
                i = hashCode;
            }
            return i;
        }

        public C0756f im() {
            return this;
        }

        public boolean isDataValid() {
            return true;
        }

        public boolean isPrimary() {
            return this.Tr;
        }

        public void writeToParcel(Parcel out, int flags) {
            iz izVar = CREATOR;
            iz.m2495a(this, out, flags);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.g */
    public static final class C0757g extends fb implements SafeParcelable, PlacesLived {
        public static final ja CREATOR;
        private static final HashMap<String, C0587a<?, ?>> RL;
        private final Set<Integer> RM;
        private boolean Tr;
        private String mValue;
        private final int wj;

        static {
            CREATOR = new ja();
            RL = new HashMap();
            RL.put("primary", C0587a.m1599i("primary", 2));
            RL.put("value", C0587a.m1600j("value", 3));
        }

        public C0757g() {
            this.wj = 1;
            this.RM = new HashSet();
        }

        C0757g(Set<Integer> set, int i, boolean z, String str) {
            this.RM = set;
            this.wj = i;
            this.Tr = z;
            this.mValue = str;
        }

        protected boolean m2481a(C0587a c0587a) {
            return this.RM.contains(Integer.valueOf(c0587a.eu()));
        }

        protected Object ak(String str) {
            return null;
        }

        protected boolean al(String str) {
            return false;
        }

        protected Object m2482b(C0587a c0587a) {
            switch (c0587a.eu()) {
                case Base64Encoder.URL_SAFE /*2*/:
                    return Boolean.valueOf(this.Tr);
                case Error.BAD_CVC /*3*/:
                    return this.mValue;
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + c0587a.eu());
            }
        }

        public int describeContents() {
            ja jaVar = CREATOR;
            return 0;
        }

        public HashMap<String, C0587a<?, ?>> en() {
            return RL;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof C0757g)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            C0757g c0757g = (C0757g) obj;
            for (C0587a c0587a : RL.values()) {
                if (m2481a(c0587a)) {
                    if (!c0757g.m2481a(c0587a)) {
                        return false;
                    }
                    if (!m2482b(c0587a).equals(c0757g.m2482b(c0587a))) {
                        return false;
                    }
                } else if (c0757g.m2481a(c0587a)) {
                    return false;
                }
            }
            return true;
        }

        public /* synthetic */ Object freeze() {
            return in();
        }

        public String getValue() {
            return this.mValue;
        }

        int getVersionCode() {
            return this.wj;
        }

        Set<Integer> hB() {
            return this.RM;
        }

        public boolean hasPrimary() {
            return this.RM.contains(Integer.valueOf(2));
        }

        public boolean hasValue() {
            return this.RM.contains(Integer.valueOf(3));
        }

        public int hashCode() {
            int i = 0;
            for (C0587a c0587a : RL.values()) {
                int hashCode;
                if (m2481a(c0587a)) {
                    hashCode = m2482b(c0587a).hashCode() + (i + c0587a.eu());
                } else {
                    hashCode = i;
                }
                i = hashCode;
            }
            return i;
        }

        public C0757g in() {
            return this;
        }

        public boolean isDataValid() {
            return true;
        }

        public boolean isPrimary() {
            return this.Tr;
        }

        public void writeToParcel(Parcel out, int flags) {
            ja jaVar = CREATOR;
            ja.m2508a(this, out, flags);
        }
    }

    /* renamed from: com.google.android.gms.internal.ir.h */
    public static final class C0758h extends fb implements SafeParcelable, Urls {
        public static final jb CREATOR;
        private static final HashMap<String, C0587a<?, ?>> RL;
        private int AI;
        private final Set<Integer> RM;
        private String Ts;
        private final int Tt;
        private String mValue;
        private final int wj;

        static {
            CREATOR = new jb();
            RL = new HashMap();
            RL.put(PlusShare.KEY_CALL_TO_ACTION_LABEL, C0587a.m1600j(PlusShare.KEY_CALL_TO_ACTION_LABEL, 5));
            RL.put("type", C0587a.m1593a("type", 6, new ey().m1571f("home", 0).m1571f("work", 1).m1571f("blog", 2).m1571f(Scopes.PROFILE, 3).m1571f("other", 4).m1571f("otherProfile", 5).m1571f("contributor", 6).m1571f("website", 7), false));
            RL.put("value", C0587a.m1600j("value", 4));
        }

        public C0758h() {
            this.Tt = 4;
            this.wj = 2;
            this.RM = new HashSet();
        }

        C0758h(Set<Integer> set, int i, String str, int i2, String str2, int i3) {
            this.Tt = 4;
            this.RM = set;
            this.wj = i;
            this.Ts = str;
            this.AI = i2;
            this.mValue = str2;
        }

        protected boolean m2483a(C0587a c0587a) {
            return this.RM.contains(Integer.valueOf(c0587a.eu()));
        }

        protected Object ak(String str) {
            return null;
        }

        protected boolean al(String str) {
            return false;
        }

        protected Object m2484b(C0587a c0587a) {
            switch (c0587a.eu()) {
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    return this.mValue;
                case Error.DECLINED /*5*/:
                    return this.Ts;
                case Error.OTHER /*6*/:
                    return Integer.valueOf(this.AI);
                default:
                    throw new IllegalStateException("Unknown safe parcelable id=" + c0587a.eu());
            }
        }

        public int describeContents() {
            jb jbVar = CREATOR;
            return 0;
        }

        public HashMap<String, C0587a<?, ?>> en() {
            return RL;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof C0758h)) {
                return false;
            }
            if (this == obj) {
                return true;
            }
            C0758h c0758h = (C0758h) obj;
            for (C0587a c0587a : RL.values()) {
                if (m2483a(c0587a)) {
                    if (!c0758h.m2483a(c0587a)) {
                        return false;
                    }
                    if (!m2484b(c0587a).equals(c0758h.m2484b(c0587a))) {
                        return false;
                    }
                } else if (c0758h.m2483a(c0587a)) {
                    return false;
                }
            }
            return true;
        }

        public /* synthetic */ Object freeze() {
            return ip();
        }

        public String getLabel() {
            return this.Ts;
        }

        public int getType() {
            return this.AI;
        }

        public String getValue() {
            return this.mValue;
        }

        int getVersionCode() {
            return this.wj;
        }

        Set<Integer> hB() {
            return this.RM;
        }

        public boolean hasLabel() {
            return this.RM.contains(Integer.valueOf(5));
        }

        public boolean hasType() {
            return this.RM.contains(Integer.valueOf(6));
        }

        public boolean hasValue() {
            return this.RM.contains(Integer.valueOf(4));
        }

        public int hashCode() {
            int i = 0;
            for (C0587a c0587a : RL.values()) {
                int hashCode;
                if (m2483a(c0587a)) {
                    hashCode = m2484b(c0587a).hashCode() + (i + c0587a.eu());
                } else {
                    hashCode = i;
                }
                i = hashCode;
            }
            return i;
        }

        @Deprecated
        public int io() {
            return 4;
        }

        public C0758h ip() {
            return this;
        }

        public boolean isDataValid() {
            return true;
        }

        public void writeToParcel(Parcel out, int flags) {
            jb jbVar = CREATOR;
            jb.m2509a(this, out, flags);
        }
    }

    static {
        CREATOR = new is();
        RL = new HashMap();
        RL.put("aboutMe", C0587a.m1600j("aboutMe", 2));
        RL.put("ageRange", C0587a.m1594a("ageRange", 3, C0749a.class));
        RL.put("birthday", C0587a.m1600j("birthday", 4));
        RL.put("braggingRights", C0587a.m1600j("braggingRights", 5));
        RL.put("circledByCount", C0587a.m1597g("circledByCount", 6));
        RL.put("cover", C0587a.m1594a("cover", 7, C0752b.class));
        RL.put("currentLocation", C0587a.m1600j("currentLocation", 8));
        RL.put("displayName", C0587a.m1600j("displayName", 9));
        RL.put("gender", C0587a.m1593a("gender", 12, new ey().m1571f("male", 0).m1571f("female", 1).m1571f("other", 2), false));
        RL.put("id", C0587a.m1600j("id", 14));
        RL.put("image", C0587a.m1594a("image", 15, C0753c.class));
        RL.put("isPlusUser", C0587a.m1599i("isPlusUser", 16));
        RL.put("language", C0587a.m1600j("language", 18));
        RL.put("name", C0587a.m1594a("name", 19, C0754d.class));
        RL.put("nickname", C0587a.m1600j("nickname", 20));
        RL.put("objectType", C0587a.m1593a("objectType", 21, new ey().m1571f("person", 0).m1571f("page", 1), false));
        RL.put("organizations", C0587a.m1595b("organizations", 22, C0756f.class));
        RL.put("placesLived", C0587a.m1595b("placesLived", 23, C0757g.class));
        RL.put("plusOneCount", C0587a.m1597g("plusOneCount", 24));
        RL.put("relationshipStatus", C0587a.m1593a("relationshipStatus", 25, new ey().m1571f("single", 0).m1571f("in_a_relationship", 1).m1571f("engaged", 2).m1571f("married", 3).m1571f("its_complicated", 4).m1571f("open_relationship", 5).m1571f("widowed", 6).m1571f("in_domestic_partnership", 7).m1571f("in_civil_union", 8), false));
        RL.put("tagline", C0587a.m1600j("tagline", 26));
        RL.put(PlusShare.KEY_CALL_TO_ACTION_URL, C0587a.m1600j(PlusShare.KEY_CALL_TO_ACTION_URL, 27));
        RL.put("urls", C0587a.m1595b("urls", 28, C0758h.class));
        RL.put("verified", C0587a.m1599i("verified", 29));
    }

    public ir() {
        this.wj = 2;
        this.RM = new HashSet();
    }

    public ir(String str, String str2, C0753c c0753c, int i, String str3) {
        this.wj = 2;
        this.RM = new HashSet();
        this.FE = str;
        this.RM.add(Integer.valueOf(9));
        this.uS = str2;
        this.RM.add(Integer.valueOf(14));
        this.SR = c0753c;
        this.RM.add(Integer.valueOf(15));
        this.SW = i;
        this.RM.add(Integer.valueOf(21));
        this.pS = str3;
        this.RM.add(Integer.valueOf(27));
    }

    ir(Set<Integer> set, int i, String str, C0749a c0749a, String str2, String str3, int i2, C0752b c0752b, String str4, String str5, int i3, String str6, C0753c c0753c, boolean z, String str7, C0754d c0754d, String str8, int i4, List<C0756f> list, List<C0757g> list2, int i5, int i6, String str9, String str10, List<C0758h> list3, boolean z2) {
        this.RM = set;
        this.wj = i;
        this.SK = str;
        this.SL = c0749a;
        this.SM = str2;
        this.SN = str3;
        this.SO = i2;
        this.SP = c0752b;
        this.SQ = str4;
        this.FE = str5;
        this.lu = i3;
        this.uS = str6;
        this.SR = c0753c;
        this.SS = z;
        this.ST = str7;
        this.SU = c0754d;
        this.SV = str8;
        this.SW = i4;
        this.SX = list;
        this.SY = list2;
        this.SZ = i5;
        this.Ta = i6;
        this.Tb = str9;
        this.pS = str10;
        this.Tc = list3;
        this.Td = z2;
    }

    public static ir m2485i(byte[] bArr) {
        Parcel obtain = Parcel.obtain();
        obtain.unmarshall(bArr, 0, bArr.length);
        obtain.setDataPosition(0);
        ir aI = CREATOR.aI(obtain);
        obtain.recycle();
        return aI;
    }

    protected boolean m2486a(C0587a c0587a) {
        return this.RM.contains(Integer.valueOf(c0587a.eu()));
    }

    protected Object ak(String str) {
        return null;
    }

    protected boolean al(String str) {
        return false;
    }

    protected Object m2487b(C0587a c0587a) {
        switch (c0587a.eu()) {
            case Base64Encoder.URL_SAFE /*2*/:
                return this.SK;
            case Error.BAD_CVC /*3*/:
                return this.SL;
            case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                return this.SM;
            case Error.DECLINED /*5*/:
                return this.SN;
            case Error.OTHER /*6*/:
                return Integer.valueOf(this.SO);
            case Error.AVS_DECLINE /*7*/:
                return this.SP;
            case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                return this.SQ;
            case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                return this.FE;
            case CommonStatusCodes.DATE_INVALID /*12*/:
                return Integer.valueOf(this.lu);
            case GamesStatusCodes.STATUS_INTERRUPTED /*14*/:
                return this.uS;
            case GamesStatusCodes.STATUS_TIMEOUT /*15*/:
                return this.SR;
            case Escaping.CONVERT_JS_VALUE_TO_EXPRESSION /*16*/:
                return Boolean.valueOf(this.SS);
            case 18:
                return this.ST;
            case TimeUtils.HUNDRED_DAY_FIELD_LEN /*19*/:
                return this.SU;
            case 20:
                return this.SV;
            case 21:
                return Integer.valueOf(this.SW);
            case 22:
                return this.SX;
            case 23:
                return this.SY;
            case 24:
                return Integer.valueOf(this.SZ);
            case 25:
                return Integer.valueOf(this.Ta);
            case 26:
                return this.Tb;
            case 27:
                return this.pS;
            case 28:
                return this.Tc;
            case 29:
                return Boolean.valueOf(this.Td);
            default:
                throw new IllegalStateException("Unknown safe parcelable id=" + c0587a.eu());
        }
    }

    public int describeContents() {
        is isVar = CREATOR;
        return 0;
    }

    public HashMap<String, C0587a<?, ?>> en() {
        return RL;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof ir)) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        ir irVar = (ir) obj;
        for (C0587a c0587a : RL.values()) {
            if (m2486a(c0587a)) {
                if (!irVar.m2486a(c0587a)) {
                    return false;
                }
                if (!m2487b(c0587a).equals(irVar.m2487b(c0587a))) {
                    return false;
                }
            } else if (irVar.m2486a(c0587a)) {
                return false;
            }
        }
        return true;
    }

    public /* synthetic */ Object freeze() {
        return id();
    }

    public String getAboutMe() {
        return this.SK;
    }

    public AgeRange getAgeRange() {
        return this.SL;
    }

    public String getBirthday() {
        return this.SM;
    }

    public String getBraggingRights() {
        return this.SN;
    }

    public int getCircledByCount() {
        return this.SO;
    }

    public Cover getCover() {
        return this.SP;
    }

    public String getCurrentLocation() {
        return this.SQ;
    }

    public String getDisplayName() {
        return this.FE;
    }

    public int getGender() {
        return this.lu;
    }

    public String getId() {
        return this.uS;
    }

    public Image getImage() {
        return this.SR;
    }

    public String getLanguage() {
        return this.ST;
    }

    public Name getName() {
        return this.SU;
    }

    public String getNickname() {
        return this.SV;
    }

    public int getObjectType() {
        return this.SW;
    }

    public List<Organizations> getOrganizations() {
        return (ArrayList) this.SX;
    }

    public List<PlacesLived> getPlacesLived() {
        return (ArrayList) this.SY;
    }

    public int getPlusOneCount() {
        return this.SZ;
    }

    public int getRelationshipStatus() {
        return this.Ta;
    }

    public String getTagline() {
        return this.Tb;
    }

    public String getUrl() {
        return this.pS;
    }

    public List<Urls> getUrls() {
        return (ArrayList) this.Tc;
    }

    int getVersionCode() {
        return this.wj;
    }

    Set<Integer> hB() {
        return this.RM;
    }

    C0749a hW() {
        return this.SL;
    }

    C0752b hX() {
        return this.SP;
    }

    C0753c hY() {
        return this.SR;
    }

    C0754d hZ() {
        return this.SU;
    }

    public boolean hasAboutMe() {
        return this.RM.contains(Integer.valueOf(2));
    }

    public boolean hasAgeRange() {
        return this.RM.contains(Integer.valueOf(3));
    }

    public boolean hasBirthday() {
        return this.RM.contains(Integer.valueOf(4));
    }

    public boolean hasBraggingRights() {
        return this.RM.contains(Integer.valueOf(5));
    }

    public boolean hasCircledByCount() {
        return this.RM.contains(Integer.valueOf(6));
    }

    public boolean hasCover() {
        return this.RM.contains(Integer.valueOf(7));
    }

    public boolean hasCurrentLocation() {
        return this.RM.contains(Integer.valueOf(8));
    }

    public boolean hasDisplayName() {
        return this.RM.contains(Integer.valueOf(9));
    }

    public boolean hasGender() {
        return this.RM.contains(Integer.valueOf(12));
    }

    public boolean hasId() {
        return this.RM.contains(Integer.valueOf(14));
    }

    public boolean hasImage() {
        return this.RM.contains(Integer.valueOf(15));
    }

    public boolean hasIsPlusUser() {
        return this.RM.contains(Integer.valueOf(16));
    }

    public boolean hasLanguage() {
        return this.RM.contains(Integer.valueOf(18));
    }

    public boolean hasName() {
        return this.RM.contains(Integer.valueOf(19));
    }

    public boolean hasNickname() {
        return this.RM.contains(Integer.valueOf(20));
    }

    public boolean hasObjectType() {
        return this.RM.contains(Integer.valueOf(21));
    }

    public boolean hasOrganizations() {
        return this.RM.contains(Integer.valueOf(22));
    }

    public boolean hasPlacesLived() {
        return this.RM.contains(Integer.valueOf(23));
    }

    public boolean hasPlusOneCount() {
        return this.RM.contains(Integer.valueOf(24));
    }

    public boolean hasRelationshipStatus() {
        return this.RM.contains(Integer.valueOf(25));
    }

    public boolean hasTagline() {
        return this.RM.contains(Integer.valueOf(26));
    }

    public boolean hasUrl() {
        return this.RM.contains(Integer.valueOf(27));
    }

    public boolean hasUrls() {
        return this.RM.contains(Integer.valueOf(28));
    }

    public boolean hasVerified() {
        return this.RM.contains(Integer.valueOf(29));
    }

    public int hashCode() {
        int i = 0;
        for (C0587a c0587a : RL.values()) {
            int hashCode;
            if (m2486a(c0587a)) {
                hashCode = m2487b(c0587a).hashCode() + (i + c0587a.eu());
            } else {
                hashCode = i;
            }
            i = hashCode;
        }
        return i;
    }

    List<C0756f> ia() {
        return this.SX;
    }

    List<C0757g> ib() {
        return this.SY;
    }

    List<C0758h> ic() {
        return this.Tc;
    }

    public ir id() {
        return this;
    }

    public boolean isDataValid() {
        return true;
    }

    public boolean isPlusUser() {
        return this.SS;
    }

    public boolean isVerified() {
        return this.Td;
    }

    public void writeToParcel(Parcel out, int flags) {
        is isVar = CREATOR;
        is.m2488a(this, out, flags);
    }
}
