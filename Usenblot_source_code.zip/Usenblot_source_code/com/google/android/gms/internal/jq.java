package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;

public class jq implements Creator<jp> {
    static void m2546a(jp jpVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, jpVar.getVersionCode());
        C0265b.m491a(parcel, 2, jpVar.ZK, false);
        C0265b.m491a(parcel, 3, jpVar.oi, false);
        C0265b.m481D(parcel, p);
    }

    public jp bk(Parcel parcel) {
        String str = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        String str2 = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new jp(i, str2, str);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public jp[] cq(int i) {
        return new jp[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return bk(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return cq(x0);
    }
}
