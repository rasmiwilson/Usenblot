package com.google.android.gms.internal;

/* renamed from: com.google.android.gms.internal.g */
class C0618g {
    C0618g() {
    }
}
