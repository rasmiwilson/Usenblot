package com.google.android.gms.internal;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.RemoteException;
import android.view.View;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.games.Game;
import com.google.android.gms.games.GameBuffer;
import com.google.android.gms.games.GameEntity;
import com.google.android.gms.games.GamesMetadata.LoadGamesResult;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.PlayerBuffer;
import com.google.android.gms.games.PlayerEntity;
import com.google.android.gms.games.Players.LoadPlayersResult;
import com.google.android.gms.games.achievement.AchievementBuffer;
import com.google.android.gms.games.achievement.Achievements.LoadAchievementsResult;
import com.google.android.gms.games.achievement.Achievements.UpdateAchievementResult;
import com.google.android.gms.games.leaderboard.C0398a;
import com.google.android.gms.games.leaderboard.C0401d;
import com.google.android.gms.games.leaderboard.Leaderboard;
import com.google.android.gms.games.leaderboard.LeaderboardBuffer;
import com.google.android.gms.games.leaderboard.LeaderboardScore;
import com.google.android.gms.games.leaderboard.LeaderboardScoreBuffer;
import com.google.android.gms.games.leaderboard.Leaderboards.LeaderboardMetadataResult;
import com.google.android.gms.games.leaderboard.Leaderboards.LoadPlayerScoreResult;
import com.google.android.gms.games.leaderboard.Leaderboards.LoadScoresResult;
import com.google.android.gms.games.leaderboard.Leaderboards.SubmitScoreResult;
import com.google.android.gms.games.leaderboard.ScoreSubmissionData;
import com.google.android.gms.games.multiplayer.Invitation;
import com.google.android.gms.games.multiplayer.InvitationBuffer;
import com.google.android.gms.games.multiplayer.Invitations.LoadInvitationsResult;
import com.google.android.gms.games.multiplayer.OnInvitationReceivedListener;
import com.google.android.gms.games.multiplayer.ParticipantResult;
import com.google.android.gms.games.multiplayer.ParticipantUtils;
import com.google.android.gms.games.multiplayer.realtime.C0415a;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessage;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessageReceivedListener;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMultiplayer.ReliableMessageSentCallback;
import com.google.android.gms.games.multiplayer.realtime.RealTimeSocket;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomConfig;
import com.google.android.gms.games.multiplayer.realtime.RoomEntity;
import com.google.android.gms.games.multiplayer.realtime.RoomStatusUpdateListener;
import com.google.android.gms.games.multiplayer.realtime.RoomUpdateListener;
import com.google.android.gms.games.multiplayer.turnbased.LoadMatchesResponse;
import com.google.android.gms.games.multiplayer.turnbased.OnTurnBasedMatchUpdateReceivedListener;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatch;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatchBuffer;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMatchConfig;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.CancelMatchResult;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.InitiateMatchResult;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.LeaveMatchResult;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.LoadMatchResult;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.LoadMatchesResult;
import com.google.android.gms.games.multiplayer.turnbased.TurnBasedMultiplayer.UpdateMatchResult;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.games.request.GameRequestBuffer;
import com.google.android.gms.games.request.OnRequestReceivedListener;
import com.google.android.gms.games.request.Requests.LoadRequestsResult;
import com.google.android.gms.games.request.Requests.UpdateRequestsResult;
import com.google.android.gms.internal.eh.C0523b;
import com.google.android.gms.internal.eh.C0526d;
import com.google.android.gms.internal.eh.C0556e;
import com.google.android.gms.internal.gb.C0621a;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class fx extends eh<gb> implements ConnectionCallbacks, OnConnectionFailedListener {
    private boolean GA;
    private boolean GB;
    private int GC;
    private final Binder GD;
    private final long GE;
    private final boolean GF;
    private final int GG;
    private final boolean GH;
    private final String Gv;
    private final Map<String, RealTimeSocket> Gw;
    private PlayerEntity Gx;
    private GameEntity Gy;
    private final gd Gz;
    private final String vi;

    /* renamed from: com.google.android.gms.internal.fx.c */
    abstract class C0592c extends C0526d<RoomStatusUpdateListener> {
        final /* synthetic */ fx GJ;

        C0592c(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder);
        }

        protected void m1746a(RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            m1747a(roomStatusUpdateListener, this.GJ.m1858G(dataHolder));
        }

        protected abstract void m1747a(RoomStatusUpdateListener roomStatusUpdateListener, Room room);
    }

    /* renamed from: com.google.android.gms.internal.fx.a */
    abstract class C0593a extends C0592c {
        private final ArrayList<String> GI;
        final /* synthetic */ fx GJ;

        C0593a(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder);
            this.GI = new ArrayList();
            for (Object add : strArr) {
                this.GI.add(add);
            }
        }

        protected void m1749a(RoomStatusUpdateListener roomStatusUpdateListener, Room room) {
            m1750a(roomStatusUpdateListener, room, this.GI);
        }

        protected abstract void m1750a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList);
    }

    final class aa extends C0523b<RoomStatusUpdateListener> {
        final /* synthetic */ fx GJ;
        private final String GZ;

        aa(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, String str) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener);
            this.GZ = str;
        }

        public void m1751a(RoomStatusUpdateListener roomStatusUpdateListener) {
            if (roomStatusUpdateListener != null) {
                roomStatusUpdateListener.onP2PConnected(this.GZ);
            }
        }

        protected void cP() {
        }
    }

    final class ab extends C0523b<RoomStatusUpdateListener> {
        final /* synthetic */ fx GJ;
        private final String GZ;

        ab(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, String str) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener);
            this.GZ = str;
        }

        public void m1753a(RoomStatusUpdateListener roomStatusUpdateListener) {
            if (roomStatusUpdateListener != null) {
                roomStatusUpdateListener.onP2PDisconnected(this.GZ);
            }
        }

        protected void cP() {
        }
    }

    final class ac extends C0593a {
        final /* synthetic */ fx GJ;

        ac(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder, strArr);
        }

        protected void m1755a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeersConnected(room, arrayList);
        }
    }

    final class ad extends C0593a {
        final /* synthetic */ fx GJ;

        ad(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder, strArr);
        }

        protected void m1756a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeerDeclined(room, arrayList);
        }
    }

    final class ae extends C0593a {
        final /* synthetic */ fx GJ;

        ae(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder, strArr);
        }

        protected void m1757a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeersDisconnected(room, arrayList);
        }
    }

    final class af extends C0593a {
        final /* synthetic */ fx GJ;

        af(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder, strArr);
        }

        protected void m1758a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeerInvitedToRoom(room, arrayList);
        }
    }

    final class ag extends C0593a {
        final /* synthetic */ fx GJ;

        ag(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder, strArr);
        }

        protected void m1759a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeerJoined(room, arrayList);
        }
    }

    final class ah extends C0593a {
        final /* synthetic */ fx GJ;

        ah(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder, String[] strArr) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder, strArr);
        }

        protected void m1760a(RoomStatusUpdateListener roomStatusUpdateListener, Room room, ArrayList<String> arrayList) {
            roomStatusUpdateListener.onPeerLeft(room, arrayList);
        }
    }

    final class ai extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<LoadPlayerScoreResult> vj;

        ai(fx fxVar, C0182c<LoadPlayerScoreResult> c0182c) {
            this.GJ = fxVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1761C(DataHolder dataHolder) {
            this.GJ.m620a(new aj(this.GJ, this.vj, dataHolder));
        }
    }

    final class aj extends C0526d<C0182c<LoadPlayerScoreResult>> implements LoadPlayerScoreResult {
        final /* synthetic */ fx GJ;
        private final C0401d Ha;
        private final Status vl;

        aj(fx fxVar, C0182c<LoadPlayerScoreResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
            this.vl = new Status(dataHolder.getStatusCode());
            LeaderboardScoreBuffer leaderboardScoreBuffer = new LeaderboardScoreBuffer(dataHolder);
            try {
                if (leaderboardScoreBuffer.getCount() > 0) {
                    this.Ha = (C0401d) leaderboardScoreBuffer.get(0).freeze();
                } else {
                    this.Ha = null;
                }
                leaderboardScoreBuffer.close();
            } catch (Throwable th) {
                leaderboardScoreBuffer.close();
            }
        }

        protected void m1762a(C0182c<LoadPlayerScoreResult> c0182c, DataHolder dataHolder) {
            c0182c.m196b(this);
        }

        public LeaderboardScore getScore() {
            return this.Ha;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    final class ak extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<LoadPlayersResult> vj;

        ak(fx fxVar, C0182c<LoadPlayersResult> c0182c) {
            this.GJ = fxVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1764e(DataHolder dataHolder) {
            this.GJ.m620a(new al(this.GJ, this.vj, dataHolder));
        }
    }

    abstract class av<R extends C0182c<?>> extends C0526d<R> implements Releasable, Result {
        final /* synthetic */ fx GJ;
        final Status vl;
        final DataHolder zU;

        public av(fx fxVar, R r, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, r, dataHolder);
            this.vl = new Status(dataHolder.getStatusCode());
            this.zU = dataHolder;
        }

        public Status getStatus() {
            return this.vl;
        }

        public void release() {
            if (this.zU != null) {
                this.zU.close();
            }
        }
    }

    final class al extends av<C0182c<LoadPlayersResult>> implements LoadPlayersResult {
        final /* synthetic */ fx GJ;
        private final PlayerBuffer Hb;

        al(fx fxVar, C0182c<LoadPlayersResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
            this.Hb = new PlayerBuffer(dataHolder);
        }

        protected void m1765a(C0182c<LoadPlayersResult> c0182c, DataHolder dataHolder) {
            c0182c.m196b(this);
        }

        public PlayerBuffer getPlayers() {
            return this.Hb;
        }
    }

    final class am extends C0523b<ReliableMessageSentCallback> {
        final /* synthetic */ fx GJ;
        private final String Hc;
        private final int Hd;
        private final int yJ;

        am(fx fxVar, ReliableMessageSentCallback reliableMessageSentCallback, int i, int i2, String str) {
            this.GJ = fxVar;
            super(fxVar, reliableMessageSentCallback);
            this.yJ = i;
            this.Hd = i2;
            this.Hc = str;
        }

        public void m1767a(ReliableMessageSentCallback reliableMessageSentCallback) {
            if (reliableMessageSentCallback != null) {
                reliableMessageSentCallback.onRealTimeMessageSent(this.yJ, this.Hd, this.Hc);
            }
        }

        protected void cP() {
        }
    }

    final class an extends fw {
        final /* synthetic */ fx GJ;
        final ReliableMessageSentCallback He;

        public an(fx fxVar, ReliableMessageSentCallback reliableMessageSentCallback) {
            this.GJ = fxVar;
            this.He = reliableMessageSentCallback;
        }

        public void m1769b(int i, int i2, String str) {
            this.GJ.m620a(new am(this.GJ, this.He, i, i2, str));
        }
    }

    final class ao extends fw {
        final /* synthetic */ fx GJ;
        private final OnRequestReceivedListener Hf;

        ao(fx fxVar, OnRequestReceivedListener onRequestReceivedListener) {
            this.GJ = fxVar;
            this.Hf = onRequestReceivedListener;
        }

        public void m1770m(DataHolder dataHolder) {
            GameRequestBuffer gameRequestBuffer = new GameRequestBuffer(dataHolder);
            GameRequest gameRequest = null;
            try {
                if (gameRequestBuffer.getCount() > 0) {
                    gameRequest = (GameRequest) ((GameRequest) gameRequestBuffer.get(0)).freeze();
                }
                gameRequestBuffer.close();
                if (gameRequest != null) {
                    this.GJ.m620a(new ap(this.GJ, this.Hf, gameRequest));
                }
            } catch (Throwable th) {
                gameRequestBuffer.close();
            }
        }

        public void onRequestRemoved(String requestId) {
            this.GJ.m620a(new aq(this.GJ, this.Hf, requestId));
        }
    }

    final class ap extends C0523b<OnRequestReceivedListener> {
        final /* synthetic */ fx GJ;
        private final GameRequest Hg;

        ap(fx fxVar, OnRequestReceivedListener onRequestReceivedListener, GameRequest gameRequest) {
            this.GJ = fxVar;
            super(fxVar, onRequestReceivedListener);
            this.Hg = gameRequest;
        }

        protected /* synthetic */ void m1771a(Object obj) {
            m1772b((OnRequestReceivedListener) obj);
        }

        protected void m1772b(OnRequestReceivedListener onRequestReceivedListener) {
            onRequestReceivedListener.onRequestReceived(this.Hg);
        }

        protected void cP() {
        }
    }

    final class aq extends C0523b<OnRequestReceivedListener> {
        final /* synthetic */ fx GJ;
        private final String Hh;

        aq(fx fxVar, OnRequestReceivedListener onRequestReceivedListener, String str) {
            this.GJ = fxVar;
            super(fxVar, onRequestReceivedListener);
            this.Hh = str;
        }

        protected /* synthetic */ void m1773a(Object obj) {
            m1774b((OnRequestReceivedListener) obj);
        }

        protected void m1774b(OnRequestReceivedListener onRequestReceivedListener) {
            onRequestReceivedListener.onRequestRemoved(this.Hh);
        }

        protected void cP() {
        }
    }

    final class ar extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<LoadRequestsResult> Hi;

        public ar(fx fxVar, C0182c<LoadRequestsResult> c0182c) {
            this.GJ = fxVar;
            this.Hi = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1775b(int i, Bundle bundle) {
            bundle.setClassLoader(getClass().getClassLoader());
            this.GJ.m620a(new as(this.GJ, this.Hi, new Status(i), bundle));
        }
    }

    final class as extends C0523b<C0182c<LoadRequestsResult>> implements LoadRequestsResult {
        final /* synthetic */ fx GJ;
        private final Bundle Hj;
        private final Status vl;

        as(fx fxVar, C0182c<LoadRequestsResult> c0182c, Status status, Bundle bundle) {
            this.GJ = fxVar;
            super(fxVar, c0182c);
            this.vl = status;
            this.Hj = bundle;
        }

        protected /* synthetic */ void m1776a(Object obj) {
            m1777c((C0182c) obj);
        }

        protected void m1777c(C0182c<LoadRequestsResult> c0182c) {
            c0182c.m196b(this);
        }

        protected void cP() {
            release();
        }

        public GameRequestBuffer getRequests(int requestType) {
            String aW = gs.aW(requestType);
            return !this.Hj.containsKey(aW) ? null : new GameRequestBuffer((DataHolder) this.Hj.get(aW));
        }

        public Status getStatus() {
            return this.vl;
        }

        public void release() {
            for (String parcelable : this.Hj.keySet()) {
                DataHolder dataHolder = (DataHolder) this.Hj.getParcelable(parcelable);
                if (dataHolder != null) {
                    dataHolder.close();
                }
            }
        }
    }

    final class at extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<UpdateRequestsResult> Hk;

        public at(fx fxVar, C0182c<UpdateRequestsResult> c0182c) {
            this.GJ = fxVar;
            this.Hk = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1778D(DataHolder dataHolder) {
            this.GJ.m620a(new au(this.GJ, this.Hk, dataHolder));
        }
    }

    final class au extends av<C0182c<UpdateRequestsResult>> implements UpdateRequestsResult {
        final /* synthetic */ fx GJ;
        private final hb Hl;

        au(fx fxVar, C0182c<UpdateRequestsResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
            this.Hl = hb.m2322H(dataHolder);
        }

        protected void m1779a(C0182c<UpdateRequestsResult> c0182c, DataHolder dataHolder) {
            c0182c.m196b(this);
        }

        public Set<String> getRequestIds() {
            return this.Hl.getRequestIds();
        }

        public int getRequestOutcome(String requestId) {
            return this.Hl.getRequestOutcome(requestId);
        }
    }

    final class aw extends C0592c {
        final /* synthetic */ fx GJ;

        aw(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder);
        }

        public void m1781a(RoomStatusUpdateListener roomStatusUpdateListener, Room room) {
            roomStatusUpdateListener.onRoomAutoMatching(room);
        }
    }

    final class ax extends fw {
        final /* synthetic */ fx GJ;
        private final RoomUpdateListener Hm;
        private final RoomStatusUpdateListener Hn;
        private final RealTimeMessageReceivedListener Ho;

        public ax(fx fxVar, RoomUpdateListener roomUpdateListener) {
            this.GJ = fxVar;
            this.Hm = (RoomUpdateListener) er.m1549b((Object) roomUpdateListener, (Object) "Callbacks must not be null");
            this.Hn = null;
            this.Ho = null;
        }

        public ax(fx fxVar, RoomUpdateListener roomUpdateListener, RoomStatusUpdateListener roomStatusUpdateListener, RealTimeMessageReceivedListener realTimeMessageReceivedListener) {
            this.GJ = fxVar;
            this.Hm = (RoomUpdateListener) er.m1549b((Object) roomUpdateListener, (Object) "Callbacks must not be null");
            this.Hn = roomStatusUpdateListener;
            this.Ho = realTimeMessageReceivedListener;
        }

        public void m1782a(DataHolder dataHolder, String[] strArr) {
            this.GJ.m620a(new af(this.GJ, this.Hn, dataHolder, strArr));
        }

        public void m1783b(DataHolder dataHolder, String[] strArr) {
            this.GJ.m620a(new ag(this.GJ, this.Hn, dataHolder, strArr));
        }

        public void m1784c(DataHolder dataHolder, String[] strArr) {
            this.GJ.m620a(new ah(this.GJ, this.Hn, dataHolder, strArr));
        }

        public void m1785d(DataHolder dataHolder, String[] strArr) {
            this.GJ.m620a(new ad(this.GJ, this.Hn, dataHolder, strArr));
        }

        public void m1786e(DataHolder dataHolder, String[] strArr) {
            this.GJ.m620a(new ac(this.GJ, this.Hn, dataHolder, strArr));
        }

        public void m1787f(DataHolder dataHolder, String[] strArr) {
            this.GJ.m620a(new ae(this.GJ, this.Hn, dataHolder, strArr));
        }

        public void onLeftRoom(int statusCode, String externalRoomId) {
            this.GJ.m620a(new C0613v(this.GJ, this.Hm, statusCode, externalRoomId));
        }

        public void onP2PConnected(String participantId) {
            this.GJ.m620a(new aa(this.GJ, this.Hn, participantId));
        }

        public void onP2PDisconnected(String participantId) {
            this.GJ.m620a(new ab(this.GJ, this.Hn, participantId));
        }

        public void onRealTimeMessageReceived(RealTimeMessage message) {
            this.GJ.m620a(new C0617z(this.GJ, this.Ho, message));
        }

        public void m1788s(DataHolder dataHolder) {
            this.GJ.m620a(new ba(this.GJ, this.Hm, dataHolder));
        }

        public void m1789t(DataHolder dataHolder) {
            this.GJ.m620a(new C0608q(this.GJ, this.Hm, dataHolder));
        }

        public void m1790u(DataHolder dataHolder) {
            this.GJ.m620a(new az(this.GJ, this.Hn, dataHolder));
        }

        public void m1791v(DataHolder dataHolder) {
            this.GJ.m620a(new aw(this.GJ, this.Hn, dataHolder));
        }

        public void m1792w(DataHolder dataHolder) {
            this.GJ.m620a(new ay(this.GJ, this.Hm, dataHolder));
        }

        public void m1793x(DataHolder dataHolder) {
            this.GJ.m620a(new C0599h(this.GJ, this.Hn, dataHolder));
        }

        public void m1794y(DataHolder dataHolder) {
            this.GJ.m620a(new C0600i(this.GJ, this.Hn, dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.b */
    abstract class C0594b extends C0526d<RoomUpdateListener> {
        final /* synthetic */ fx GJ;

        C0594b(fx fxVar, RoomUpdateListener roomUpdateListener, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, roomUpdateListener, dataHolder);
        }

        protected void m1795a(RoomUpdateListener roomUpdateListener, DataHolder dataHolder) {
            m1796a(roomUpdateListener, this.GJ.m1858G(dataHolder), dataHolder.getStatusCode());
        }

        protected abstract void m1796a(RoomUpdateListener roomUpdateListener, Room room, int i);
    }

    final class ay extends C0594b {
        final /* synthetic */ fx GJ;

        ay(fx fxVar, RoomUpdateListener roomUpdateListener, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, roomUpdateListener, dataHolder);
        }

        public void m1798a(RoomUpdateListener roomUpdateListener, Room room, int i) {
            roomUpdateListener.onRoomConnected(i, room);
        }
    }

    final class az extends C0592c {
        final /* synthetic */ fx GJ;

        az(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder);
        }

        public void m1799a(RoomStatusUpdateListener roomStatusUpdateListener, Room room) {
            roomStatusUpdateListener.onRoomConnecting(room);
        }
    }

    final class ba extends C0594b {
        final /* synthetic */ fx GJ;

        public ba(fx fxVar, RoomUpdateListener roomUpdateListener, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, roomUpdateListener, dataHolder);
        }

        public void m1800a(RoomUpdateListener roomUpdateListener, Room room, int i) {
            roomUpdateListener.onRoomCreated(i, room);
        }
    }

    final class bb extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<Status> vj;

        public bb(fx fxVar, C0182c<Status> c0182c) {
            this.GJ = fxVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void cM() {
            this.GJ.m620a(new bc(this.GJ, this.vj, new Status(0)));
        }
    }

    final class bc extends C0523b<C0182c<Status>> {
        final /* synthetic */ fx GJ;
        private final Status vl;

        public bc(fx fxVar, C0182c<Status> c0182c, Status status) {
            this.GJ = fxVar;
            super(fxVar, c0182c);
            this.vl = status;
        }

        public /* synthetic */ void m1801a(Object obj) {
            m1802c((C0182c) obj);
        }

        public void m1802c(C0182c<Status> c0182c) {
            c0182c.m196b(this.vl);
        }

        protected void cP() {
        }
    }

    final class bd extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<SubmitScoreResult> vj;

        public bd(fx fxVar, C0182c<SubmitScoreResult> c0182c) {
            this.GJ = fxVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1803d(DataHolder dataHolder) {
            this.GJ.m620a(new be(this.GJ, this.vj, dataHolder));
        }
    }

    final class be extends av<C0182c<SubmitScoreResult>> implements SubmitScoreResult {
        final /* synthetic */ fx GJ;
        private final ScoreSubmissionData Hp;

        public be(fx fxVar, C0182c<SubmitScoreResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
            try {
                this.Hp = new ScoreSubmissionData(dataHolder);
            } finally {
                dataHolder.close();
            }
        }

        public void m1804a(C0182c<SubmitScoreResult> c0182c, DataHolder dataHolder) {
            c0182c.m196b(this);
        }

        public ScoreSubmissionData getScoreData() {
            return this.Hp;
        }
    }

    abstract class bf<T extends C0182c<?>> extends av<T> {
        final /* synthetic */ fx GJ;
        final TurnBasedMatch GX;

        bf(fx fxVar, T t, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, t, dataHolder);
            TurnBasedMatchBuffer turnBasedMatchBuffer = new TurnBasedMatchBuffer(dataHolder);
            try {
                if (turnBasedMatchBuffer.getCount() > 0) {
                    this.GX = (TurnBasedMatch) ((TurnBasedMatch) turnBasedMatchBuffer.get(0)).freeze();
                } else {
                    this.GX = null;
                }
                turnBasedMatchBuffer.close();
            } catch (Throwable th) {
                turnBasedMatchBuffer.close();
            }
        }

        protected void m1806a(T t, DataHolder dataHolder) {
            m1808h(t);
        }

        public TurnBasedMatch getMatch() {
            return this.GX;
        }

        abstract void m1808h(T t);
    }

    final class bg extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<CancelMatchResult> Hq;

        public bg(fx fxVar, C0182c<CancelMatchResult> c0182c) {
            this.GJ = fxVar;
            this.Hq = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1809f(int i, String str) {
            this.GJ.m620a(new bh(this.GJ, this.Hq, new Status(i), str));
        }
    }

    final class bh extends C0523b<C0182c<CancelMatchResult>> implements CancelMatchResult {
        final /* synthetic */ fx GJ;
        private final String Hr;
        private final Status vl;

        bh(fx fxVar, C0182c<CancelMatchResult> c0182c, Status status, String str) {
            this.GJ = fxVar;
            super(fxVar, c0182c);
            this.vl = status;
            this.Hr = str;
        }

        public /* synthetic */ void m1810a(Object obj) {
            m1811c((C0182c) obj);
        }

        public void m1811c(C0182c<CancelMatchResult> c0182c) {
            c0182c.m196b(this);
        }

        protected void cP() {
        }

        public String getMatchId() {
            return this.Hr;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    final class bi extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<InitiateMatchResult> Hs;

        public bi(fx fxVar, C0182c<InitiateMatchResult> c0182c) {
            this.GJ = fxVar;
            this.Hs = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1812o(DataHolder dataHolder) {
            this.GJ.m620a(new bj(this.GJ, this.Hs, dataHolder));
        }
    }

    final class bj extends bf<C0182c<InitiateMatchResult>> implements InitiateMatchResult {
        final /* synthetic */ fx GJ;

        bj(fx fxVar, C0182c<InitiateMatchResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
        }

        protected void m1813h(C0182c<InitiateMatchResult> c0182c) {
            c0182c.m196b(this);
        }
    }

    final class bk extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<LeaveMatchResult> Ht;

        public bk(fx fxVar, C0182c<LeaveMatchResult> c0182c) {
            this.GJ = fxVar;
            this.Ht = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1814q(DataHolder dataHolder) {
            this.GJ.m620a(new bl(this.GJ, this.Ht, dataHolder));
        }
    }

    final class bl extends bf<C0182c<LeaveMatchResult>> implements LeaveMatchResult {
        final /* synthetic */ fx GJ;

        bl(fx fxVar, C0182c<LeaveMatchResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
        }

        protected void m1815h(C0182c<LeaveMatchResult> c0182c) {
            c0182c.m196b(this);
        }
    }

    final class bm extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<LoadMatchResult> Hu;

        public bm(fx fxVar, C0182c<LoadMatchResult> c0182c) {
            this.GJ = fxVar;
            this.Hu = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1816n(DataHolder dataHolder) {
            this.GJ.m620a(new bn(this.GJ, this.Hu, dataHolder));
        }
    }

    final class bn extends bf<C0182c<LoadMatchResult>> implements LoadMatchResult {
        final /* synthetic */ fx GJ;

        bn(fx fxVar, C0182c<LoadMatchResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
        }

        protected void m1817h(C0182c<LoadMatchResult> c0182c) {
            c0182c.m196b(this);
        }
    }

    final class bo extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<UpdateMatchResult> Hv;

        public bo(fx fxVar, C0182c<UpdateMatchResult> c0182c) {
            this.GJ = fxVar;
            this.Hv = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1818p(DataHolder dataHolder) {
            this.GJ.m620a(new bp(this.GJ, this.Hv, dataHolder));
        }
    }

    final class bp extends bf<C0182c<UpdateMatchResult>> implements UpdateMatchResult {
        final /* synthetic */ fx GJ;

        bp(fx fxVar, C0182c<UpdateMatchResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
        }

        protected void m1819h(C0182c<UpdateMatchResult> c0182c) {
            c0182c.m196b(this);
        }
    }

    final class bq extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<LoadMatchesResult> Hw;

        public bq(fx fxVar, C0182c<LoadMatchesResult> c0182c) {
            this.GJ = fxVar;
            this.Hw = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1820a(int i, Bundle bundle) {
            bundle.setClassLoader(getClass().getClassLoader());
            this.GJ.m620a(new br(this.GJ, this.Hw, new Status(i), bundle));
        }
    }

    final class br extends C0523b<C0182c<LoadMatchesResult>> implements LoadMatchesResult {
        final /* synthetic */ fx GJ;
        private final LoadMatchesResponse Hx;
        private final Status vl;

        br(fx fxVar, C0182c<LoadMatchesResult> c0182c, Status status, Bundle bundle) {
            this.GJ = fxVar;
            super(fxVar, c0182c);
            this.vl = status;
            this.Hx = new LoadMatchesResponse(bundle);
        }

        protected /* synthetic */ void m1821a(Object obj) {
            m1822c((C0182c) obj);
        }

        protected void m1822c(C0182c<LoadMatchesResult> c0182c) {
            c0182c.m196b(this);
        }

        protected void cP() {
        }

        public LoadMatchesResponse getMatches() {
            return this.Hx;
        }

        public Status getStatus() {
            return this.vl;
        }

        public void release() {
            this.Hx.close();
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.d */
    final class C0595d extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<UpdateAchievementResult> vj;

        C0595d(fx fxVar, C0182c<UpdateAchievementResult> c0182c) {
            this.GJ = fxVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1823e(int i, String str) {
            this.GJ.m620a(new C0596e(this.GJ, this.vj, i, str));
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.e */
    final class C0596e extends C0523b<C0182c<UpdateAchievementResult>> implements UpdateAchievementResult {
        final /* synthetic */ fx GJ;
        private final String GK;
        private final Status vl;

        C0596e(fx fxVar, C0182c<UpdateAchievementResult> c0182c, int i, String str) {
            this.GJ = fxVar;
            super(fxVar, c0182c);
            this.vl = new Status(i);
            this.GK = str;
        }

        protected /* synthetic */ void m1824a(Object obj) {
            m1825c((C0182c) obj);
        }

        protected void m1825c(C0182c<UpdateAchievementResult> c0182c) {
            c0182c.m196b(this);
        }

        protected void cP() {
        }

        public String getAchievementId() {
            return this.GK;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.f */
    final class C0597f extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<LoadAchievementsResult> vj;

        C0597f(fx fxVar, C0182c<LoadAchievementsResult> c0182c) {
            this.GJ = fxVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1826b(DataHolder dataHolder) {
            this.GJ.m620a(new C0598g(this.GJ, this.vj, dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.g */
    final class C0598g extends av<C0182c<LoadAchievementsResult>> implements LoadAchievementsResult {
        final /* synthetic */ fx GJ;
        private final AchievementBuffer GL;

        C0598g(fx fxVar, C0182c<LoadAchievementsResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
            this.GL = new AchievementBuffer(dataHolder);
        }

        protected void m1827a(C0182c<LoadAchievementsResult> c0182c, DataHolder dataHolder) {
            c0182c.m196b(this);
        }

        public AchievementBuffer getAchievements() {
            return this.GL;
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.h */
    final class C0599h extends C0592c {
        final /* synthetic */ fx GJ;

        C0599h(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder);
        }

        public void m1829a(RoomStatusUpdateListener roomStatusUpdateListener, Room room) {
            roomStatusUpdateListener.onConnectedToRoom(room);
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.i */
    final class C0600i extends C0592c {
        final /* synthetic */ fx GJ;

        C0600i(fx fxVar, RoomStatusUpdateListener roomStatusUpdateListener, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, roomStatusUpdateListener, dataHolder);
        }

        public void m1830a(RoomStatusUpdateListener roomStatusUpdateListener, Room room) {
            roomStatusUpdateListener.onDisconnectedFromRoom(room);
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.j */
    final class C0601j extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<LoadGamesResult> vj;

        C0601j(fx fxVar, C0182c<LoadGamesResult> c0182c) {
            this.GJ = fxVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1831g(DataHolder dataHolder) {
            this.GJ.m620a(new C0602k(this.GJ, this.vj, dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.k */
    final class C0602k extends av<C0182c<LoadGamesResult>> implements LoadGamesResult {
        final /* synthetic */ fx GJ;
        private final GameBuffer GM;

        C0602k(fx fxVar, C0182c<LoadGamesResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
            this.GM = new GameBuffer(dataHolder);
        }

        protected void m1832a(C0182c<LoadGamesResult> c0182c, DataHolder dataHolder) {
            c0182c.m196b(this);
        }

        public GameBuffer getGames() {
            return this.GM;
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.l */
    final class C0603l extends fw {
        final /* synthetic */ fx GJ;
        private final OnInvitationReceivedListener GN;

        C0603l(fx fxVar, OnInvitationReceivedListener onInvitationReceivedListener) {
            this.GJ = fxVar;
            this.GN = onInvitationReceivedListener;
        }

        public void m1834l(DataHolder dataHolder) {
            InvitationBuffer invitationBuffer = new InvitationBuffer(dataHolder);
            Invitation invitation = null;
            try {
                if (invitationBuffer.getCount() > 0) {
                    invitation = (Invitation) ((Invitation) invitationBuffer.get(0)).freeze();
                }
                invitationBuffer.close();
                if (invitation != null) {
                    this.GJ.m620a(new C0604m(this.GJ, this.GN, invitation));
                }
            } catch (Throwable th) {
                invitationBuffer.close();
            }
        }

        public void onInvitationRemoved(String invitationId) {
            this.GJ.m620a(new C0605n(this.GJ, this.GN, invitationId));
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.m */
    final class C0604m extends C0523b<OnInvitationReceivedListener> {
        final /* synthetic */ fx GJ;
        private final Invitation GO;

        C0604m(fx fxVar, OnInvitationReceivedListener onInvitationReceivedListener, Invitation invitation) {
            this.GJ = fxVar;
            super(fxVar, onInvitationReceivedListener);
            this.GO = invitation;
        }

        protected /* synthetic */ void m1835a(Object obj) {
            m1836b((OnInvitationReceivedListener) obj);
        }

        protected void m1836b(OnInvitationReceivedListener onInvitationReceivedListener) {
            onInvitationReceivedListener.onInvitationReceived(this.GO);
        }

        protected void cP() {
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.n */
    final class C0605n extends C0523b<OnInvitationReceivedListener> {
        final /* synthetic */ fx GJ;
        private final String GP;

        C0605n(fx fxVar, OnInvitationReceivedListener onInvitationReceivedListener, String str) {
            this.GJ = fxVar;
            super(fxVar, onInvitationReceivedListener);
            this.GP = str;
        }

        protected /* synthetic */ void m1837a(Object obj) {
            m1838b((OnInvitationReceivedListener) obj);
        }

        protected void m1838b(OnInvitationReceivedListener onInvitationReceivedListener) {
            onInvitationReceivedListener.onInvitationRemoved(this.GP);
        }

        protected void cP() {
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.o */
    final class C0606o extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<LoadInvitationsResult> vj;

        C0606o(fx fxVar, C0182c<LoadInvitationsResult> c0182c) {
            this.GJ = fxVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1839k(DataHolder dataHolder) {
            this.GJ.m620a(new C0607p(this.GJ, this.vj, dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.p */
    final class C0607p extends av<C0182c<LoadInvitationsResult>> implements LoadInvitationsResult {
        final /* synthetic */ fx GJ;
        private final InvitationBuffer GQ;

        C0607p(fx fxVar, C0182c<LoadInvitationsResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
            this.GQ = new InvitationBuffer(dataHolder);
        }

        protected void m1840a(C0182c<LoadInvitationsResult> c0182c, DataHolder dataHolder) {
            c0182c.m196b(this);
        }

        public InvitationBuffer getInvitations() {
            return this.GQ;
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.q */
    final class C0608q extends C0594b {
        final /* synthetic */ fx GJ;

        public C0608q(fx fxVar, RoomUpdateListener roomUpdateListener, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, roomUpdateListener, dataHolder);
        }

        public void m1842a(RoomUpdateListener roomUpdateListener, Room room, int i) {
            roomUpdateListener.onJoinedRoom(i, room);
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.r */
    final class C0609r extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<LoadScoresResult> vj;

        C0609r(fx fxVar, C0182c<LoadScoresResult> c0182c) {
            this.GJ = fxVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1843a(DataHolder dataHolder, DataHolder dataHolder2) {
            this.GJ.m620a(new C0610s(this.GJ, this.vj, dataHolder, dataHolder2));
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.s */
    final class C0610s extends av<C0182c<LoadScoresResult>> implements LoadScoresResult {
        final /* synthetic */ fx GJ;
        private final C0398a GR;
        private final LeaderboardScoreBuffer GS;

        C0610s(fx fxVar, C0182c<LoadScoresResult> c0182c, DataHolder dataHolder, DataHolder dataHolder2) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder2);
            LeaderboardBuffer leaderboardBuffer = new LeaderboardBuffer(dataHolder);
            try {
                if (leaderboardBuffer.getCount() > 0) {
                    this.GR = (C0398a) ((Leaderboard) leaderboardBuffer.get(0)).freeze();
                } else {
                    this.GR = null;
                }
                leaderboardBuffer.close();
                this.GS = new LeaderboardScoreBuffer(dataHolder2);
            } catch (Throwable th) {
                leaderboardBuffer.close();
            }
        }

        protected void m1844a(C0182c<LoadScoresResult> c0182c, DataHolder dataHolder) {
            c0182c.m196b(this);
        }

        public Leaderboard getLeaderboard() {
            return this.GR;
        }

        public LeaderboardScoreBuffer getScores() {
            return this.GS;
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.t */
    final class C0611t extends fw {
        final /* synthetic */ fx GJ;
        private final C0182c<LeaderboardMetadataResult> vj;

        C0611t(fx fxVar, C0182c<LeaderboardMetadataResult> c0182c) {
            this.GJ = fxVar;
            this.vj = (C0182c) er.m1549b((Object) c0182c, (Object) "Holder must not be null");
        }

        public void m1846c(DataHolder dataHolder) {
            this.GJ.m620a(new C0612u(this.GJ, this.vj, dataHolder));
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.u */
    final class C0612u extends av<C0182c<LeaderboardMetadataResult>> implements LeaderboardMetadataResult {
        final /* synthetic */ fx GJ;
        private final LeaderboardBuffer GT;

        C0612u(fx fxVar, C0182c<LeaderboardMetadataResult> c0182c, DataHolder dataHolder) {
            this.GJ = fxVar;
            super(fxVar, c0182c, dataHolder);
            this.GT = new LeaderboardBuffer(dataHolder);
        }

        protected void m1847a(C0182c<LeaderboardMetadataResult> c0182c, DataHolder dataHolder) {
            c0182c.m196b(this);
        }

        public LeaderboardBuffer getLeaderboards() {
            return this.GT;
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.v */
    final class C0613v extends C0523b<RoomUpdateListener> {
        final /* synthetic */ fx GJ;
        private final String GU;
        private final int yJ;

        C0613v(fx fxVar, RoomUpdateListener roomUpdateListener, int i, String str) {
            this.GJ = fxVar;
            super(fxVar, roomUpdateListener);
            this.yJ = i;
            this.GU = str;
        }

        public void m1849a(RoomUpdateListener roomUpdateListener) {
            roomUpdateListener.onLeftRoom(this.yJ, this.GU);
        }

        protected void cP() {
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.w */
    final class C0614w extends C0523b<OnTurnBasedMatchUpdateReceivedListener> {
        final /* synthetic */ fx GJ;
        private final String GV;

        C0614w(fx fxVar, OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchUpdateReceivedListener, String str) {
            this.GJ = fxVar;
            super(fxVar, onTurnBasedMatchUpdateReceivedListener);
            this.GV = str;
        }

        protected /* synthetic */ void m1851a(Object obj) {
            m1852b((OnTurnBasedMatchUpdateReceivedListener) obj);
        }

        protected void m1852b(OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchUpdateReceivedListener) {
            onTurnBasedMatchUpdateReceivedListener.onTurnBasedMatchRemoved(this.GV);
        }

        protected void cP() {
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.x */
    final class C0615x extends fw {
        final /* synthetic */ fx GJ;
        private final OnTurnBasedMatchUpdateReceivedListener GW;

        C0615x(fx fxVar, OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchUpdateReceivedListener) {
            this.GJ = fxVar;
            this.GW = onTurnBasedMatchUpdateReceivedListener;
        }

        public void onTurnBasedMatchRemoved(String matchId) {
            this.GJ.m620a(new C0614w(this.GJ, this.GW, matchId));
        }

        public void m1853r(DataHolder dataHolder) {
            TurnBasedMatchBuffer turnBasedMatchBuffer = new TurnBasedMatchBuffer(dataHolder);
            TurnBasedMatch turnBasedMatch = null;
            try {
                if (turnBasedMatchBuffer.getCount() > 0) {
                    turnBasedMatch = (TurnBasedMatch) ((TurnBasedMatch) turnBasedMatchBuffer.get(0)).freeze();
                }
                turnBasedMatchBuffer.close();
                if (turnBasedMatch != null) {
                    this.GJ.m620a(new C0616y(this.GJ, this.GW, turnBasedMatch));
                }
            } catch (Throwable th) {
                turnBasedMatchBuffer.close();
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.y */
    final class C0616y extends C0523b<OnTurnBasedMatchUpdateReceivedListener> {
        final /* synthetic */ fx GJ;
        private final TurnBasedMatch GX;

        C0616y(fx fxVar, OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchUpdateReceivedListener, TurnBasedMatch turnBasedMatch) {
            this.GJ = fxVar;
            super(fxVar, onTurnBasedMatchUpdateReceivedListener);
            this.GX = turnBasedMatch;
        }

        protected /* synthetic */ void m1854a(Object obj) {
            m1855b((OnTurnBasedMatchUpdateReceivedListener) obj);
        }

        protected void m1855b(OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchUpdateReceivedListener) {
            onTurnBasedMatchUpdateReceivedListener.onTurnBasedMatchReceived(this.GX);
        }

        protected void cP() {
        }
    }

    /* renamed from: com.google.android.gms.internal.fx.z */
    final class C0617z extends C0523b<RealTimeMessageReceivedListener> {
        final /* synthetic */ fx GJ;
        private final RealTimeMessage GY;

        C0617z(fx fxVar, RealTimeMessageReceivedListener realTimeMessageReceivedListener, RealTimeMessage realTimeMessage) {
            this.GJ = fxVar;
            super(fxVar, realTimeMessageReceivedListener);
            this.GY = realTimeMessage;
        }

        public void m1856a(RealTimeMessageReceivedListener realTimeMessageReceivedListener) {
            if (realTimeMessageReceivedListener != null) {
                realTimeMessageReceivedListener.onRealTimeMessageReceived(this.GY);
            }
        }

        protected void cP() {
        }
    }

    public fx(Context context, Looper looper, String str, String str2, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String[] strArr, int i, View view, boolean z, boolean z2, int i2, boolean z3, int i3) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, strArr);
        this.GA = false;
        this.GB = false;
        this.Gv = str;
        this.vi = (String) er.m1551f(str2);
        this.GD = new Binder();
        this.Gw = new HashMap();
        this.Gz = gd.m2201a(this, i);
        m1905e(view);
        this.GB = z2;
        this.GC = i2;
        this.GE = (long) hashCode();
        this.GF = z;
        this.GH = z3;
        this.GG = i3;
        registerConnectionCallbacks((ConnectionCallbacks) this);
        registerConnectionFailedListener((OnConnectionFailedListener) this);
    }

    private Room m1858G(DataHolder dataHolder) {
        C0415a c0415a = new C0415a(dataHolder);
        Room room = null;
        try {
            if (c0415a.getCount() > 0) {
                room = (Room) ((Room) c0415a.get(0)).freeze();
            }
            c0415a.close();
            return room;
        } catch (Throwable th) {
            c0415a.close();
        }
    }

    private RealTimeSocket aw(String str) {
        try {
            ParcelFileDescriptor aD = ((gb) eb()).aD(str);
            RealTimeSocket gcVar;
            if (aD != null) {
                fz.m1916f("GamesClientImpl", "Created native libjingle socket.");
                gcVar = new gc(aD);
                this.Gw.put(str, gcVar);
                return gcVar;
            }
            fz.m1916f("GamesClientImpl", "Unable to create native libjingle socket, resorting to old socket.");
            String ay = ((gb) eb()).ay(str);
            if (ay == null) {
                return null;
            }
            LocalSocket localSocket = new LocalSocket();
            try {
                localSocket.connect(new LocalSocketAddress(ay));
                gcVar = new ge(localSocket, str);
                this.Gw.put(str, gcVar);
                return gcVar;
            } catch (IOException e) {
                fz.m1918h("GamesClientImpl", "connect() call failed on socket: " + e.getMessage());
                return null;
            }
        } catch (RemoteException e2) {
            fz.m1918h("GamesClientImpl", "Unable to create socket. Service died.");
            return null;
        }
    }

    private void fG() {
        for (RealTimeSocket close : this.Gw.values()) {
            try {
                close.close();
            } catch (Throwable e) {
                fz.m1915a("GamesClientImpl", "IOException:", e);
            }
        }
        this.Gw.clear();
    }

    private void fm() {
        this.Gx = null;
    }

    protected gb m1860H(IBinder iBinder) {
        return C0621a.m2200J(iBinder);
    }

    public int m1861a(ReliableMessageSentCallback reliableMessageSentCallback, byte[] bArr, String str, String str2) {
        try {
            return ((gb) eb()).m1964a(new an(this, reliableMessageSentCallback), bArr, str, str2);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return -1;
        }
    }

    public int m1862a(byte[] bArr, String str, String[] strArr) {
        er.m1549b((Object) strArr, (Object) "Participant IDs must not be null");
        try {
            return ((gb) eb()).m2012b(bArr, str, strArr);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return -1;
        }
    }

    public Intent m1863a(int i, int i2, boolean z) {
        try {
            return ((gb) eb()).m1965a(i, i2, z);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public Intent m1864a(int i, byte[] bArr, int i2, Bitmap bitmap, String str) {
        try {
            Intent a = ((gb) eb()).m1966a(i, bArr, i2, str);
            er.m1549b((Object) bitmap, (Object) "Must provide a non null icon");
            a.putExtra("com.google.android.gms.games.REQUEST_ITEM_ICON", bitmap);
            return a;
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public Intent m1865a(Room room, int i) {
        try {
            return ((gb) eb()).m1967a((RoomEntity) room.freeze(), i);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    protected void m1866a(int i, IBinder iBinder, Bundle bundle) {
        if (i == 0 && bundle != null) {
            this.GA = bundle.getBoolean("show_welcome_popup");
        }
        super.m619a(i, iBinder, bundle);
    }

    public void m1867a(IBinder iBinder, Bundle bundle) {
        if (isConnected()) {
            try {
                ((gb) eb()).m1972a(iBinder, bundle);
            } catch (RemoteException e) {
                fz.m1917g("GamesClientImpl", "service died");
            }
        }
    }

    public void m1868a(C0182c<LoadRequestsResult> c0182c, int i, int i2, int i3) {
        try {
            ((gb) eb()).m1975a(new ar(this, c0182c), i, i2, i3);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1869a(C0182c<LoadPlayersResult> c0182c, int i, boolean z, boolean z2) {
        try {
            ((gb) eb()).m1978a(new ak(this, c0182c), i, z, z2);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1870a(C0182c<LoadMatchesResult> c0182c, int i, int[] iArr) {
        try {
            ((gb) eb()).m1979a(new bq(this, c0182c), i, iArr);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1871a(C0182c<LoadScoresResult> c0182c, LeaderboardScoreBuffer leaderboardScoreBuffer, int i, int i2) {
        try {
            ((gb) eb()).m1982a(new C0609r(this, c0182c), leaderboardScoreBuffer.fX().fY(), i, i2);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1872a(C0182c<InitiateMatchResult> c0182c, TurnBasedMatchConfig turnBasedMatchConfig) {
        try {
            ((gb) eb()).m1977a(new bi(this, c0182c), turnBasedMatchConfig.getVariant(), turnBasedMatchConfig.getMinPlayers(), turnBasedMatchConfig.getInvitedPlayerIds(), turnBasedMatchConfig.getAutoMatchCriteria());
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1873a(C0182c<LoadPlayersResult> c0182c, String str) {
        try {
            ((gb) eb()).m1985a(new ak(this, c0182c), str);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1874a(C0182c<UpdateAchievementResult> c0182c, String str, int i) {
        try {
            ((gb) eb()).m1988a(c0182c == null ? null : new C0595d(this, c0182c), str, i, this.Gz.fP(), this.Gz.fO());
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1875a(C0182c<LoadScoresResult> c0182c, String str, int i, int i2, int i3, boolean z) {
        try {
            ((gb) eb()).m1987a(new C0609r(this, c0182c), str, i, i2, i3, z);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1876a(C0182c<LoadPlayersResult> c0182c, String str, int i, boolean z, boolean z2) {
        if (str.equals("playedWith")) {
            try {
                ((gb) eb()).m2047d(new ak(this, c0182c), str, i, z, z2);
                return;
            } catch (RemoteException e) {
                fz.m1917g("GamesClientImpl", "service died");
                return;
            }
        }
        throw new IllegalArgumentException("Invalid player collection: " + str);
    }

    public void m1877a(C0182c<SubmitScoreResult> c0182c, String str, long j, String str2) {
        try {
            ((gb) eb()).m1994a(c0182c == null ? null : new bd(this, c0182c), str, j, str2);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1878a(C0182c<LeaveMatchResult> c0182c, String str, String str2) {
        try {
            ((gb) eb()).m2039c(new bk(this, c0182c), str, str2);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1879a(C0182c<LoadPlayerScoreResult> c0182c, String str, String str2, int i, int i2) {
        try {
            ((gb) eb()).m1997a(new ai(this, c0182c), str, str2, i, i2);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1880a(C0182c<LeaderboardMetadataResult> c0182c, String str, boolean z) {
        try {
            ((gb) eb()).m2040c(new C0611t(this, c0182c), str, z);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1881a(C0182c<UpdateMatchResult> c0182c, String str, byte[] bArr, String str2, ParticipantResult[] participantResultArr) {
        try {
            ((gb) eb()).m2004a(new bo(this, c0182c), str, bArr, str2, participantResultArr);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1882a(C0182c<UpdateMatchResult> c0182c, String str, byte[] bArr, ParticipantResult[] participantResultArr) {
        try {
            ((gb) eb()).m2005a(new bo(this, c0182c), str, bArr, participantResultArr);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1883a(C0182c<LoadPlayersResult> c0182c, boolean z) {
        try {
            ((gb) eb()).m2041c(new ak(this, c0182c), z);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1884a(C0182c<UpdateRequestsResult> c0182c, String[] strArr) {
        try {
            ((gb) eb()).m2011a(new at(this, c0182c), strArr);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1885a(OnInvitationReceivedListener onInvitationReceivedListener) {
        try {
            ((gb) eb()).m1980a(new C0603l(this, onInvitationReceivedListener), this.GE);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1886a(RoomConfig roomConfig) {
        try {
            ((gb) eb()).m1983a(new ax(this, roomConfig.getRoomUpdateListener(), roomConfig.getRoomStatusUpdateListener(), roomConfig.getMessageReceivedListener()), this.GD, roomConfig.getVariant(), roomConfig.getInvitedPlayerIds(), roomConfig.getAutoMatchCriteria(), roomConfig.isSocketEnabled(), this.GE);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1887a(RoomUpdateListener roomUpdateListener, String str) {
        try {
            ((gb) eb()).m2037c(new ax(this, roomUpdateListener), str);
            fG();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1888a(OnTurnBasedMatchUpdateReceivedListener onTurnBasedMatchUpdateReceivedListener) {
        try {
            ((gb) eb()).m2017b(new C0615x(this, onTurnBasedMatchUpdateReceivedListener), this.GE);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1889a(OnRequestReceivedListener onRequestReceivedListener) {
        try {
            ((gb) eb()).m2035c(new ao(this, onRequestReceivedListener), this.GE);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    protected void m1890a(en enVar, C0556e c0556e) throws RemoteException {
        String locale = getContext().getResources().getConfiguration().locale.toString();
        Bundle bundle = new Bundle();
        bundle.putBoolean("com.google.android.gms.games.key.isHeadless", this.GF);
        bundle.putBoolean("com.google.android.gms.games.key.showConnectingPopup", this.GB);
        bundle.putInt("com.google.android.gms.games.key.connectingPopupGravity", this.GC);
        bundle.putBoolean("com.google.android.gms.games.key.retryingSignIn", this.GH);
        bundle.putInt("com.google.android.gms.games.key.sdkVariant", this.GG);
        enVar.m1496a(c0556e, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), this.vi, ea(), this.Gv, this.Gz.fP(), locale, bundle);
    }

    protected String aF() {
        return "com.google.android.gms.games.service.START";
    }

    protected String aG() {
        return "com.google.android.gms.games.internal.IGamesService";
    }

    public void aT(int i) {
        this.Gz.setGravity(i);
    }

    public void aU(int i) {
        try {
            ((gb) eb()).aU(i);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public Intent au(String str) {
        try {
            return ((gb) eb()).au(str);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public void av(String str) {
        try {
            ((gb) eb()).aC(str);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public Intent m1891b(int i, int i2, boolean z) {
        try {
            return ((gb) eb()).m2013b(i, i2, z);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public void m1892b(C0182c<Status> c0182c) {
        try {
            ((gb) eb()).m1973a(new bb(this, c0182c));
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1893b(C0182c<UpdateAchievementResult> c0182c, String str) {
        if (c0182c == null) {
            ga gaVar = null;
        } else {
            Object c0595d = new C0595d(this, c0182c);
        }
        try {
            ((gb) eb()).m1995a(gaVar, str, this.Gz.fP(), this.Gz.fO());
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1894b(C0182c<UpdateAchievementResult> c0182c, String str, int i) {
        try {
            ((gb) eb()).m2021b(c0182c == null ? null : new C0595d(this, c0182c), str, i, this.Gz.fP(), this.Gz.fO());
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1895b(C0182c<LoadScoresResult> c0182c, String str, int i, int i2, int i3, boolean z) {
        try {
            ((gb) eb()).m2020b(new C0609r(this, c0182c), str, i, i2, i3, z);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1896b(C0182c<LeaderboardMetadataResult> c0182c, boolean z) {
        try {
            ((gb) eb()).m2029b(new C0611t(this, c0182c), z);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1897b(C0182c<UpdateRequestsResult> c0182c, String[] strArr) {
        try {
            ((gb) eb()).m2030b(new at(this, c0182c), strArr);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1898b(RoomConfig roomConfig) {
        try {
            ((gb) eb()).m1984a(new ax(this, roomConfig.getRoomUpdateListener(), roomConfig.getRoomStatusUpdateListener(), roomConfig.getMessageReceivedListener()), this.GD, roomConfig.getInvitationId(), roomConfig.isSocketEnabled(), this.GE);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    protected void m1899b(String... strArr) {
        int i = 0;
        boolean z = false;
        for (String str : strArr) {
            if (str.equals(Scopes.GAMES)) {
                z = true;
            } else if (str.equals("https://www.googleapis.com/auth/games.firstparty")) {
                i = 1;
            }
        }
        if (i != 0) {
            er.m1547a(!z, String.format("Cannot have both %s and %s!", new Object[]{Scopes.GAMES, "https://www.googleapis.com/auth/games.firstparty"}));
            return;
        }
        er.m1547a(z, String.format("Games APIs requires %s to function.", new Object[]{Scopes.GAMES}));
    }

    public void m1900c(C0182c<LoadInvitationsResult> c0182c, int i) {
        try {
            ((gb) eb()).m1974a(new C0606o(this, c0182c), i);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1901c(C0182c<UpdateAchievementResult> c0182c, String str) {
        if (c0182c == null) {
            ga gaVar = null;
        } else {
            Object c0595d = new C0595d(this, c0182c);
        }
        try {
            ((gb) eb()).m2024b(gaVar, str, this.Gz.fP(), this.Gz.fO());
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1902c(C0182c<LoadAchievementsResult> c0182c, boolean z) {
        try {
            ((gb) eb()).m2008a(new C0597f(this, c0182c), z);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public Bundle cY() {
        try {
            Bundle cY = ((gb) eb()).cY();
            if (cY == null) {
                return cY;
            }
            cY.setClassLoader(fx.class.getClassLoader());
            return cY;
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public void connect() {
        fm();
        super.connect();
    }

    public int m1903d(byte[] bArr, String str) {
        try {
            return ((gb) eb()).m2012b(bArr, str, null);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return -1;
        }
    }

    public void m1904d(C0182c<InitiateMatchResult> c0182c, String str) {
        try {
            ((gb) eb()).m2067l(new bi(this, c0182c), str);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void disconnect() {
        this.GA = false;
        if (isConnected()) {
            try {
                gb gbVar = (gb) eb();
                gbVar.fH();
                gbVar.m2071n(this.GE);
            } catch (RemoteException e) {
                fz.m1917g("GamesClientImpl", "Failed to notify client disconnect.");
            }
        }
        fG();
        super.disconnect();
    }

    public void m1905e(View view) {
        this.Gz.m2202f(view);
    }

    public void m1906e(C0182c<InitiateMatchResult> c0182c, String str) {
        try {
            ((gb) eb()).m2069m(new bi(this, c0182c), str);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1907f(C0182c<LeaveMatchResult> c0182c, String str) {
        try {
            ((gb) eb()).m2075o(new bk(this, c0182c), str);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public int fA() {
        try {
            return ((gb) eb()).fA();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return 4368;
        }
    }

    public String fB() {
        try {
            return ((gb) eb()).fB();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public int fC() {
        try {
            return ((gb) eb()).fC();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return 2;
        }
    }

    public Intent fD() {
        try {
            return ((gb) eb()).fD();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public int fE() {
        try {
            return ((gb) eb()).fE();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return 2;
        }
    }

    public int fF() {
        try {
            return ((gb) eb()).fF();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return 2;
        }
    }

    public void fH() {
        if (isConnected()) {
            try {
                ((gb) eb()).fH();
            } catch (RemoteException e) {
                fz.m1917g("GamesClientImpl", "service died");
            }
        }
    }

    public String fn() {
        try {
            return ((gb) eb()).fn();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public String fo() {
        try {
            return ((gb) eb()).fo();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public Player fp() {
        bm();
        synchronized (this) {
            if (this.Gx == null) {
                PlayerBuffer playerBuffer;
                try {
                    playerBuffer = new PlayerBuffer(((gb) eb()).fI());
                    if (playerBuffer.getCount() > 0) {
                        this.Gx = (PlayerEntity) playerBuffer.get(0).freeze();
                    }
                    playerBuffer.close();
                } catch (RemoteException e) {
                    fz.m1917g("GamesClientImpl", "service died");
                } catch (Throwable th) {
                    playerBuffer.close();
                }
            }
        }
        return this.Gx;
    }

    public Game fq() {
        GameBuffer gameBuffer;
        bm();
        synchronized (this) {
            if (this.Gy == null) {
                try {
                    gameBuffer = new GameBuffer(((gb) eb()).fK());
                    if (gameBuffer.getCount() > 0) {
                        this.Gy = (GameEntity) gameBuffer.get(0).freeze();
                    }
                    gameBuffer.close();
                } catch (RemoteException e) {
                    fz.m1917g("GamesClientImpl", "service died");
                } catch (Throwable th) {
                    gameBuffer.close();
                }
            }
        }
        return this.Gy;
    }

    public Intent fr() {
        try {
            return ((gb) eb()).fr();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public Intent fs() {
        try {
            return ((gb) eb()).fs();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public Intent ft() {
        try {
            return ((gb) eb()).ft();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public Intent fu() {
        try {
            return ((gb) eb()).fu();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public void fv() {
        try {
            ((gb) eb()).m2074o(this.GE);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void fw() {
        try {
            ((gb) eb()).m2077p(this.GE);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void fx() {
        try {
            ((gb) eb()).m2079q(this.GE);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public Intent fy() {
        try {
            return ((gb) eb()).fy();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public Intent fz() {
        try {
            return ((gb) eb()).fz();
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
            return null;
        }
    }

    public void m1908g(C0182c<LoadGamesResult> c0182c) {
        try {
            ((gb) eb()).m2044d(new C0601j(this, c0182c));
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1909g(C0182c<CancelMatchResult> c0182c, String str) {
        try {
            ((gb) eb()).m2072n(new bg(this, c0182c), str);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1910h(C0182c<LoadMatchResult> c0182c, String str) {
        try {
            ((gb) eb()).m2078p(new bm(this, c0182c), str);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public RealTimeSocket m1911i(String str, String str2) {
        if (str2 == null || !ParticipantUtils.aE(str2)) {
            throw new IllegalArgumentException("Bad participant ID");
        }
        RealTimeSocket realTimeSocket = (RealTimeSocket) this.Gw.get(str2);
        return (realTimeSocket == null || realTimeSocket.isClosed()) ? aw(str2) : realTimeSocket;
    }

    public void m1912l(String str, int i) {
        try {
            ((gb) eb()).m2068l(str, i);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void m1913m(String str, int i) {
        try {
            ((gb) eb()).m2070m(str, i);
        } catch (RemoteException e) {
            fz.m1917g("GamesClientImpl", "service died");
        }
    }

    public void onConnected(Bundle connectionHint) {
        if (this.GA) {
            this.Gz.fN();
            this.GA = false;
        }
    }

    public void onConnectionFailed(ConnectionResult result) {
        this.GA = false;
    }

    public void onConnectionSuspended(int cause) {
    }

    protected /* synthetic */ IInterface m1914p(IBinder iBinder) {
        return m1860H(iBinder);
    }
}
