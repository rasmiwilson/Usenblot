package com.google.android.gms.internal;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public class ce implements Creator<cd> {
    static void m1165a(cd cdVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, cdVar.versionCode);
        C0265b.m486a(parcel, 2, cdVar.ob, false);
        C0265b.m489a(parcel, 3, cdVar.oc, i, false);
        C0265b.m489a(parcel, 4, cdVar.kQ, i, false);
        C0265b.m491a(parcel, 5, cdVar.adUnitId, false);
        C0265b.m489a(parcel, 6, cdVar.applicationInfo, i, false);
        C0265b.m489a(parcel, 7, cdVar.od, i, false);
        C0265b.m491a(parcel, 8, cdVar.oe, false);
        C0265b.m491a(parcel, 9, cdVar.of, false);
        C0265b.m491a(parcel, 10, cdVar.og, false);
        C0265b.m489a(parcel, 11, cdVar.kN, i, false);
        C0265b.m486a(parcel, 12, cdVar.oh, false);
        C0265b.m481D(parcel, p);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1166f(x0);
    }

    public cd m1166f(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        Bundle bundle = null;
        C0790z c0790z = null;
        ab abVar = null;
        String str = null;
        ApplicationInfo applicationInfo = null;
        PackageInfo packageInfo = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        db dbVar = null;
        Bundle bundle2 = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    bundle = C0264a.m467o(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    c0790z = (C0790z) C0264a.m446a(parcel, n, C0790z.CREATOR);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    abVar = (ab) C0264a.m446a(parcel, n, ab.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    applicationInfo = (ApplicationInfo) C0264a.m446a(parcel, n, ApplicationInfo.CREATOR);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    packageInfo = (PackageInfo) C0264a.m446a(parcel, n, PackageInfo.CREATOR);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    str3 = C0264a.m463m(parcel, n);
                    break;
                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                    str4 = C0264a.m463m(parcel, n);
                    break;
                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                    dbVar = (db) C0264a.m446a(parcel, n, db.CREATOR);
                    break;
                case CommonStatusCodes.DATE_INVALID /*12*/:
                    bundle2 = C0264a.m467o(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new cd(i, bundle, c0790z, abVar, str, applicationInfo, packageInfo, str2, str3, str4, dbVar, bundle2);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public cd[] m1167k(int i) {
        return new cd[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1167k(x0);
    }
}
