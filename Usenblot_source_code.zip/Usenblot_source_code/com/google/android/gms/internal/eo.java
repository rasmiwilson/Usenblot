package com.google.android.gms.internal;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.C0380b;
import com.google.android.gms.dynamic.C0380b.C0382a;

public interface eo extends IInterface {

    /* renamed from: com.google.android.gms.internal.eo.a */
    public static abstract class C0567a extends Binder implements eo {

        /* renamed from: com.google.android.gms.internal.eo.a.a */
        private static class C0566a implements eo {
            private IBinder ky;

            C0566a(IBinder iBinder) {
                this.ky = iBinder;
            }

            public C0380b m1540a(C0380b c0380b, int i, int i2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.google.android.gms.common.internal.ISignInButtonCreator");
                    obtain.writeStrongBinder(c0380b != null ? c0380b.asBinder() : null);
                    obtain.writeInt(i);
                    obtain.writeInt(i2);
                    this.ky.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                    C0380b G = C0382a.m825G(obtain2.readStrongBinder());
                    return G;
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public IBinder asBinder() {
                return this.ky;
            }
        }

        public static eo m1541A(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.common.internal.ISignInButtonCreator");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof eo)) ? new C0566a(iBinder) : (eo) queryLocalInterface;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            switch (code) {
                case Base64Encoder.NO_PADDING /*1*/:
                    data.enforceInterface("com.google.android.gms.common.internal.ISignInButtonCreator");
                    C0380b a = m1539a(C0382a.m825G(data.readStrongBinder()), data.readInt(), data.readInt());
                    reply.writeNoException();
                    reply.writeStrongBinder(a != null ? a.asBinder() : null);
                    return true;
                case 1598968902:
                    reply.writeString("com.google.android.gms.common.internal.ISignInButtonCreator");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    C0380b m1539a(C0380b c0380b, int i, int i2) throws RemoteException;
}
