package com.google.android.gms.internal;

import android.util.Log;
import com.google.ads.AdRequest;

public final class da {
    public static void m1266a(String str, Throwable th) {
        if (m1268n(3)) {
            Log.d(AdRequest.LOGTAG, str, th);
        }
    }

    public static void m1267b(String str, Throwable th) {
        if (m1268n(5)) {
            Log.w(AdRequest.LOGTAG, str, th);
        }
    }

    public static boolean m1268n(int i) {
        return (i >= 5 || Log.isLoggable(AdRequest.LOGTAG, i)) && i != 2;
    }

    public static void m1269s(String str) {
        if (m1268n(3)) {
            Log.d(AdRequest.LOGTAG, str);
        }
    }

    public static void m1270t(String str) {
        if (m1268n(6)) {
            Log.e(AdRequest.LOGTAG, str);
        }
    }

    public static void m1271u(String str) {
        if (m1268n(4)) {
            Log.i(AdRequest.LOGTAG, str);
        }
    }

    public static void m1272v(String str) {
        if (m1268n(2)) {
            Log.v(AdRequest.LOGTAG, str);
        }
    }

    public static void m1273w(String str) {
        if (m1268n(5)) {
            Log.w(AdRequest.LOGTAG, str);
        }
    }
}
