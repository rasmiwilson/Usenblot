package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationStatusCodes;

public class hs implements Creator<hr> {
    static void m2393a(hr hrVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m489a(parcel, 1, hrVar.gu(), i, false);
        C0265b.m501c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, hrVar.wj);
        C0265b.m489a(parcel, 2, hrVar.gv(), i, false);
        C0265b.m481D(parcel, p);
    }

    public hr ay(Parcel parcel) {
        hn hnVar = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        LocationRequest locationRequest = null;
        while (parcel.dataPosition() < o) {
            int i2;
            hn hnVar2;
            LocationRequest locationRequest2;
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i2 = i;
                    LocationRequest locationRequest3 = (LocationRequest) C0264a.m446a(parcel, n, LocationRequest.CREATOR);
                    hnVar2 = hnVar;
                    locationRequest2 = locationRequest3;
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    hnVar2 = (hn) C0264a.m446a(parcel, n, hn.CREATOR);
                    locationRequest2 = locationRequest;
                    i2 = i;
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    hn hnVar3 = hnVar;
                    locationRequest2 = locationRequest;
                    i2 = C0264a.m457g(parcel, n);
                    hnVar2 = hnVar3;
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    hnVar2 = hnVar;
                    locationRequest2 = locationRequest;
                    i2 = i;
                    break;
            }
            i = i2;
            locationRequest = locationRequest2;
            hnVar = hnVar2;
        }
        if (parcel.dataPosition() == o) {
            return new hr(i, locationRequest, hnVar);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public hr[] bs(int i) {
        return new hr[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return ay(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bs(x0);
    }
}
