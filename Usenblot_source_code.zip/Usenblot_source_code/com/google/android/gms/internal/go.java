package com.google.android.gms.internal;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.Games.C0389a;
import com.google.android.gms.games.request.GameRequest;
import com.google.android.gms.games.request.GameRequestBuffer;
import com.google.android.gms.games.request.OnRequestReceivedListener;
import com.google.android.gms.games.request.Requests;
import com.google.android.gms.games.request.Requests.LoadRequestsResult;
import com.google.android.gms.games.request.Requests.UpdateRequestsResult;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public final class go implements Requests {

    /* renamed from: com.google.android.gms.internal.go.b */
    private static abstract class C0667b extends C0389a<UpdateRequestsResult> {

        /* renamed from: com.google.android.gms.internal.go.b.1 */
        class C06731 implements UpdateRequestsResult {
            final /* synthetic */ C0667b Io;
            final /* synthetic */ Status vb;

            C06731(C0667b c0667b, Status status) {
                this.Io = c0667b;
                this.vb = status;
            }

            public Set<String> getRequestIds() {
                return null;
            }

            public int getRequestOutcome(String requestId) {
                throw new IllegalArgumentException("Unknown request ID " + requestId);
            }

            public Status getStatus() {
                return this.vb;
            }

            public void release() {
            }
        }

        private C0667b() {
        }

        public UpdateRequestsResult m2272C(Status status) {
            return new C06731(this, status);
        }

        public /* synthetic */ Result m2273d(Status status) {
            return m2272C(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.go.1 */
    class C06681 extends C0667b {
        final /* synthetic */ String[] Ij;
        final /* synthetic */ go Ik;

        C06681(go goVar, String[] strArr) {
            this.Ik = goVar;
            this.Ij = strArr;
            super();
        }

        protected void m2275a(fx fxVar) {
            fxVar.m1884a((C0182c) this, this.Ij);
        }
    }

    /* renamed from: com.google.android.gms.internal.go.2 */
    class C06692 extends C0667b {
        final /* synthetic */ String[] Ij;
        final /* synthetic */ go Ik;

        C06692(go goVar, String[] strArr) {
            this.Ik = goVar;
            this.Ij = strArr;
            super();
        }

        protected void m2277a(fx fxVar) {
            fxVar.m1897b((C0182c) this, this.Ij);
        }
    }

    /* renamed from: com.google.android.gms.internal.go.a */
    private static abstract class C0670a extends C0389a<LoadRequestsResult> {

        /* renamed from: com.google.android.gms.internal.go.a.1 */
        class C06721 implements LoadRequestsResult {
            final /* synthetic */ C0670a In;
            final /* synthetic */ Status vb;

            C06721(C0670a c0670a, Status status) {
                this.In = c0670a;
                this.vb = status;
            }

            public GameRequestBuffer getRequests(int type) {
                return null;
            }

            public Status getStatus() {
                return this.vb;
            }

            public void release() {
            }
        }

        private C0670a() {
        }

        public LoadRequestsResult m2278B(Status status) {
            return new C06721(this, status);
        }

        public /* synthetic */ Result m2279d(Status status) {
            return m2278B(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.go.3 */
    class C06713 extends C0670a {
        final /* synthetic */ int HP;
        final /* synthetic */ go Ik;
        final /* synthetic */ int Il;
        final /* synthetic */ int Im;

        C06713(go goVar, int i, int i2, int i3) {
            this.Ik = goVar;
            this.Il = i;
            this.Im = i2;
            this.HP = i3;
            super();
        }

        protected void m2281a(fx fxVar) {
            fxVar.m1868a((C0182c) this, this.Il, this.Im, this.HP);
        }
    }

    public PendingResult<UpdateRequestsResult> acceptRequest(GoogleApiClient apiClient, String requestId) {
        List arrayList = new ArrayList();
        arrayList.add(requestId);
        return acceptRequests(apiClient, arrayList);
    }

    public PendingResult<UpdateRequestsResult> acceptRequests(GoogleApiClient apiClient, List<String> requestIds) {
        return apiClient.m366b(new C06681(this, requestIds == null ? null : (String[]) requestIds.toArray(new String[requestIds.size()])));
    }

    public PendingResult<UpdateRequestsResult> dismissRequest(GoogleApiClient apiClient, String requestId) {
        List arrayList = new ArrayList();
        arrayList.add(requestId);
        return dismissRequests(apiClient, arrayList);
    }

    public PendingResult<UpdateRequestsResult> dismissRequests(GoogleApiClient apiClient, List<String> requestIds) {
        return apiClient.m366b(new C06692(this, requestIds == null ? null : (String[]) requestIds.toArray(new String[requestIds.size()])));
    }

    public ArrayList<GameRequest> getGameRequestsFromBundle(Bundle extras) {
        if (extras == null || !extras.containsKey(Requests.EXTRA_REQUESTS)) {
            return new ArrayList();
        }
        ArrayList arrayList = (ArrayList) extras.get(Requests.EXTRA_REQUESTS);
        ArrayList<GameRequest> arrayList2 = new ArrayList();
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            arrayList2.add((GameRequest) arrayList.get(i));
        }
        return arrayList2;
    }

    public ArrayList<GameRequest> getGameRequestsFromInboxResponse(Intent response) {
        return response == null ? new ArrayList() : getGameRequestsFromBundle(response.getExtras());
    }

    public Intent getInboxIntent(GoogleApiClient apiClient) {
        return Games.m843c(apiClient).fD();
    }

    public int getMaxLifetimeDays(GoogleApiClient apiClient) {
        return Games.m843c(apiClient).fF();
    }

    public int getMaxPayloadSize(GoogleApiClient apiClient) {
        return Games.m843c(apiClient).fE();
    }

    public Intent getSendIntent(GoogleApiClient apiClient, int type, byte[] payload, int requestLifetimeDays, Bitmap icon, String description) {
        return Games.m843c(apiClient).m1864a(type, payload, requestLifetimeDays, icon, description);
    }

    public PendingResult<LoadRequestsResult> loadRequests(GoogleApiClient apiClient, int requestDirection, int types, int sortOrder) {
        return apiClient.m365a(new C06713(this, requestDirection, types, sortOrder));
    }

    public void registerRequestListener(GoogleApiClient apiClient, OnRequestReceivedListener listener) {
        Games.m843c(apiClient).m1889a(listener);
    }

    public void unregisterRequestListener(GoogleApiClient apiClient) {
        Games.m843c(apiClient).fx();
    }
}
