package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public class bm implements Creator<bn> {
    static void m1042a(bn bnVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, bnVar.versionCode);
        C0265b.m491a(parcel, 2, bnVar.mY, false);
        C0265b.m491a(parcel, 3, bnVar.mZ, false);
        C0265b.m491a(parcel, 4, bnVar.mimeType, false);
        C0265b.m491a(parcel, 5, bnVar.packageName, false);
        C0265b.m491a(parcel, 6, bnVar.na, false);
        C0265b.m491a(parcel, 7, bnVar.nb, false);
        C0265b.m491a(parcel, 8, bnVar.nc, false);
        C0265b.m481D(parcel, p);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1043d(x0);
    }

    public bn m1043d(Parcel parcel) {
        String str = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        String str7 = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str7 = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    str6 = C0264a.m463m(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    str5 = C0264a.m463m(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    str4 = C0264a.m463m(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    str3 = C0264a.m463m(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new bn(i, str7, str6, str5, str4, str3, str2, str);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public bn[] m1044i(int i) {
        return new bn[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1044i(x0);
    }
}
