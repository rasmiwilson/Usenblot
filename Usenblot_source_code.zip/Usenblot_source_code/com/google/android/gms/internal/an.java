package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public class an implements Creator<am> {
    static void m968a(am amVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, amVar.versionCode);
        C0265b.m501c(parcel, 2, amVar.lI);
        C0265b.m501c(parcel, 3, amVar.backgroundColor);
        C0265b.m501c(parcel, 4, amVar.lJ);
        C0265b.m501c(parcel, 5, amVar.lK);
        C0265b.m501c(parcel, 6, amVar.lL);
        C0265b.m501c(parcel, 7, amVar.lM);
        C0265b.m501c(parcel, 8, amVar.lN);
        C0265b.m501c(parcel, 9, amVar.lO);
        C0265b.m491a(parcel, 10, amVar.lP, false);
        C0265b.m501c(parcel, 11, amVar.lQ);
        C0265b.m491a(parcel, 12, amVar.lR, false);
        C0265b.m501c(parcel, 13, amVar.lS);
        C0265b.m501c(parcel, 14, amVar.lT);
        C0265b.m491a(parcel, 15, amVar.lU, false);
        C0265b.m481D(parcel, p);
    }

    public am m969c(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        int i9 = 0;
        String str = null;
        int i10 = 0;
        String str2 = null;
        int i11 = 0;
        int i12 = 0;
        String str3 = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    i3 = C0264a.m457g(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    i4 = C0264a.m457g(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    i5 = C0264a.m457g(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    i6 = C0264a.m457g(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    i7 = C0264a.m457g(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    i8 = C0264a.m457g(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    i9 = C0264a.m457g(parcel, n);
                    break;
                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                    i10 = C0264a.m457g(parcel, n);
                    break;
                case CommonStatusCodes.DATE_INVALID /*12*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case CommonStatusCodes.ERROR /*13*/:
                    i11 = C0264a.m457g(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_INTERRUPTED /*14*/:
                    i12 = C0264a.m457g(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_TIMEOUT /*15*/:
                    str3 = C0264a.m463m(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new am(i, i2, i3, i4, i5, i6, i7, i8, i9, str, i10, str2, i11, i12, str3);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m969c(x0);
    }

    public am[] m970e(int i) {
        return new am[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m970e(x0);
    }
}
