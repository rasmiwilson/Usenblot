package com.google.android.gms.internal;

import android.content.Context;
import android.location.Location;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.search.SearchAdRequest;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class aj {
    public static final String DEVICE_ID_EMULATOR;
    private final Date f67d;
    private final Set<String> f68f;
    private final int lA;
    private final Set<String> lB;
    private final String lt;
    private final int lu;
    private final Location lv;
    private final boolean lw;
    private final Map<Class<? extends NetworkExtras>, NetworkExtras> lx;
    private final String ly;
    private final SearchAdRequest lz;

    /* renamed from: com.google.android.gms.internal.aj.a */
    public static final class C0437a {
        private Date f66d;
        private int lA;
        private final HashSet<String> lC;
        private final HashMap<Class<? extends NetworkExtras>, NetworkExtras> lD;
        private final HashSet<String> lE;
        private String lt;
        private int lu;
        private Location lv;
        private boolean lw;
        private String ly;

        public C0437a() {
            this.lC = new HashSet();
            this.lD = new HashMap();
            this.lE = new HashSet();
            this.lu = -1;
            this.lw = false;
            this.lA = -1;
        }

        public void m953a(Location location) {
            this.lv = location;
        }

        public void m954a(NetworkExtras networkExtras) {
            this.lD.put(networkExtras.getClass(), networkExtras);
        }

        public void m955a(Date date) {
            this.f66d = date;
        }

        public void m956d(int i) {
            this.lu = i;
        }

        public void m957d(boolean z) {
            this.lw = z;
        }

        public void m958e(boolean z) {
            this.lA = z ? 1 : 0;
        }

        public void m959g(String str) {
            this.lC.add(str);
        }

        public void m960h(String str) {
            this.lE.add(str);
        }

        public void m961i(String str) {
            this.lt = str;
        }

        public void m962j(String str) {
            this.ly = str;
        }
    }

    static {
        DEVICE_ID_EMULATOR = cz.m1259r("emulator");
    }

    public aj(C0437a c0437a) {
        this(c0437a, null);
    }

    public aj(C0437a c0437a, SearchAdRequest searchAdRequest) {
        this.f67d = c0437a.f66d;
        this.lt = c0437a.lt;
        this.lu = c0437a.lu;
        this.f68f = Collections.unmodifiableSet(c0437a.lC);
        this.lv = c0437a.lv;
        this.lw = c0437a.lw;
        this.lx = Collections.unmodifiableMap(c0437a.lD);
        this.ly = c0437a.ly;
        this.lz = searchAdRequest;
        this.lA = c0437a.lA;
        this.lB = Collections.unmodifiableSet(c0437a.lE);
    }

    public SearchAdRequest aj() {
        return this.lz;
    }

    public Map<Class<? extends NetworkExtras>, NetworkExtras> ak() {
        return this.lx;
    }

    public int al() {
        return this.lA;
    }

    public Date getBirthday() {
        return this.f67d;
    }

    public String getContentUrl() {
        return this.lt;
    }

    public int getGender() {
        return this.lu;
    }

    public Set<String> getKeywords() {
        return this.f68f;
    }

    public Location getLocation() {
        return this.lv;
    }

    public boolean getManualImpressionsEnabled() {
        return this.lw;
    }

    public <T extends NetworkExtras> T getNetworkExtras(Class<T> networkExtrasClass) {
        return (NetworkExtras) this.lx.get(networkExtrasClass);
    }

    public String getPublisherProvidedId() {
        return this.ly;
    }

    public boolean isTestDevice(Context context) {
        return this.lB.contains(cz.m1258l(context));
    }
}
