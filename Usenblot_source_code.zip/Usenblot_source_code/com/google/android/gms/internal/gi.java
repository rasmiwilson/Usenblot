package com.google.android.gms.internal;

import android.content.Intent;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.Games.C0389a;
import com.google.android.gms.games.multiplayer.InvitationBuffer;
import com.google.android.gms.games.multiplayer.Invitations;
import com.google.android.gms.games.multiplayer.Invitations.LoadInvitationsResult;
import com.google.android.gms.games.multiplayer.OnInvitationReceivedListener;

public final class gi implements Invitations {

    /* renamed from: com.google.android.gms.internal.gi.a */
    private static abstract class C0641a extends C0389a<LoadInvitationsResult> {

        /* renamed from: com.google.android.gms.internal.gi.a.1 */
        class C06431 implements LoadInvitationsResult {
            final /* synthetic */ C0641a HR;
            final /* synthetic */ Status vb;

            C06431(C0641a c0641a, Status status) {
                this.HR = c0641a;
                this.vb = status;
            }

            public InvitationBuffer getInvitations() {
                return new InvitationBuffer(DataHolder.empty(14));
            }

            public Status getStatus() {
                return this.vb;
            }

            public void release() {
            }
        }

        private C0641a() {
        }

        public /* synthetic */ Result m2232d(Status status) {
            return m2233v(status);
        }

        public LoadInvitationsResult m2233v(Status status) {
            return new C06431(this, status);
        }
    }

    /* renamed from: com.google.android.gms.internal.gi.1 */
    class C06421 extends C0641a {
        final /* synthetic */ int HP;
        final /* synthetic */ gi HQ;

        C06421(gi giVar, int i) {
            this.HQ = giVar;
            this.HP = i;
            super();
        }

        protected void m2235a(fx fxVar) {
            fxVar.m1900c((C0182c) this, this.HP);
        }
    }

    public Intent getInvitationInboxIntent(GoogleApiClient apiClient) {
        return Games.m843c(apiClient).fu();
    }

    public PendingResult<LoadInvitationsResult> loadInvitations(GoogleApiClient apiClient) {
        return loadInvitations(apiClient, 0);
    }

    public PendingResult<LoadInvitationsResult> loadInvitations(GoogleApiClient apiClient, int sortOrder) {
        return apiClient.m365a(new C06421(this, sortOrder));
    }

    public void registerInvitationListener(GoogleApiClient apiClient, OnInvitationReceivedListener listener) {
        Games.m843c(apiClient).m1885a(listener);
    }

    public void unregisterInvitationListener(GoogleApiClient apiClient) {
        Games.m843c(apiClient).fv();
    }
}
