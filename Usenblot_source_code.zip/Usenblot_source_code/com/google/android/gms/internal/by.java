package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.internal.cd.C0495a;

public final class by {

    /* renamed from: com.google.android.gms.internal.by.a */
    public interface C0476a {
        void m1081a(cn cnVar);
    }

    public static ct m1082a(Context context, C0495a c0495a, C0770l c0770l, dd ddVar, bf bfVar, C0476a c0476a) {
        ct bzVar = new bz(context, c0495a, c0770l, ddVar, bfVar, c0476a);
        bzVar.start();
        return bzVar;
    }
}
