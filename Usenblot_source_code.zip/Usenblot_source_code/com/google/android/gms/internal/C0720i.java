package com.google.android.gms.internal;

import android.content.Context;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/* renamed from: com.google.android.gms.internal.i */
public abstract class C0720i implements C0695h {
    protected MotionEvent jY;
    protected DisplayMetrics jZ;
    protected C0546n ka;
    private C0772o kb;

    protected C0720i(Context context, C0546n c0546n, C0772o c0772o) {
        this.ka = c0546n;
        this.kb = c0772o;
        try {
            this.jZ = context.getResources().getDisplayMetrics();
        } catch (UnsupportedOperationException e) {
            this.jZ = new DisplayMetrics();
            this.jZ.density = 1.0f;
        }
    }

    private String m2400a(Context context, String str, boolean z) {
        try {
            byte[] u;
            synchronized (this) {
                m2401t();
                if (z) {
                    m2412c(context);
                } else {
                    m2411b(context);
                }
                u = m2402u();
            }
            return u.length == 0 ? Integer.toString(5) : m2405a(u, str);
        } catch (NoSuchAlgorithmException e) {
            return Integer.toString(7);
        } catch (UnsupportedEncodingException e2) {
            return Integer.toString(7);
        } catch (IOException e3) {
            return Integer.toString(3);
        }
    }

    private void m2401t() {
        this.kb.reset();
    }

    private byte[] m2402u() throws IOException {
        return this.kb.m2611z();
    }

    public String m2403a(Context context) {
        return m2400a(context, null, false);
    }

    public String m2404a(Context context, String str) {
        return m2400a(context, str, true);
    }

    String m2405a(byte[] bArr, String str) throws NoSuchAlgorithmException, UnsupportedEncodingException, IOException {
        byte[] bArr2;
        if (bArr.length > 239) {
            m2401t();
            m2407a(20, 1);
            bArr = m2402u();
        }
        if (bArr.length < 239) {
            bArr2 = new byte[(239 - bArr.length)];
            new SecureRandom().nextBytes(bArr2);
            bArr2 = ByteBuffer.allocate(240).put((byte) bArr.length).put(bArr).put(bArr2).array();
        } else {
            bArr2 = ByteBuffer.allocate(240).put((byte) bArr.length).put(bArr).array();
        }
        MessageDigest instance = MessageDigest.getInstance("MD5");
        instance.update(bArr2);
        bArr2 = ByteBuffer.allocate(AccessibilityNodeInfoCompat.ACTION_NEXT_AT_MOVEMENT_GRANULARITY).put(instance.digest()).put(bArr2).array();
        byte[] bArr3 = new byte[AccessibilityNodeInfoCompat.ACTION_NEXT_AT_MOVEMENT_GRANULARITY];
        new C0586f().m1589a(bArr2, bArr3);
        if (str != null && str.length() > 0) {
            m2410a(str, bArr3);
        }
        return this.ka.m1450a(bArr3, true);
    }

    public void m2406a(int i, int i2, int i3) {
        if (this.jY != null) {
            this.jY.recycle();
        }
        this.jY = MotionEvent.obtain(0, (long) i3, 1, ((float) i) * this.jZ.density, ((float) i2) * this.jZ.density, 0.0f, 0.0f, 0, 0.0f, 0.0f, 0, 0);
    }

    protected void m2407a(int i, long j) throws IOException {
        this.kb.m2609b(i, j);
    }

    protected void m2408a(int i, String str) throws IOException {
        this.kb.m2610b(i, str);
    }

    public void m2409a(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 1) {
            if (this.jY != null) {
                this.jY.recycle();
            }
            this.jY = MotionEvent.obtain(motionEvent);
        }
    }

    void m2410a(String str, byte[] bArr) throws UnsupportedEncodingException {
        if (str.length() > 32) {
            str = str.substring(0, 32);
        }
        new jx(str.getBytes("UTF-8")).m2550m(bArr);
    }

    protected abstract void m2411b(Context context);

    protected abstract void m2412c(Context context);
}
