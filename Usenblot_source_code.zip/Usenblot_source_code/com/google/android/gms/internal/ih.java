package com.google.android.gms.internal;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.C0721if.C0723a;
import com.google.android.gms.internal.eh.C0523b;
import com.google.android.gms.internal.eh.C0554c;
import com.google.android.gms.internal.eh.C0556e;
import com.google.android.gms.internal.eh.C0558g;
import com.google.android.gms.internal.ig.C0725a;
import com.google.android.gms.panorama.Panorama.C0726a;
import com.google.android.gms.panorama.Panorama.PanoramaResult;

public class ih extends eh<ig> {

    /* renamed from: com.google.android.gms.internal.ih.a */
    final class C0727a extends C0523b<C0182c<C0726a>> implements C0726a {
        public final Status QE;
        public final Intent QF;
        final /* synthetic */ ih QG;
        public final int type;

        public C0727a(ih ihVar, C0182c<C0726a> c0182c, Status status, int i, Intent intent) {
            this.QG = ihVar;
            super(ihVar, c0182c);
            this.QE = status;
            this.type = i;
            this.QF = intent;
        }

        protected /* synthetic */ void m2420a(Object obj) {
            m2421c((C0182c) obj);
        }

        protected void m2421c(C0182c<C0726a> c0182c) {
            c0182c.m196b(this);
        }

        protected void cP() {
        }

        public Status getStatus() {
            return this.QE;
        }

        public Intent getViewerIntent() {
            return this.QF;
        }
    }

    /* renamed from: com.google.android.gms.internal.ih.b */
    final class C0728b extends C0723a {
        final /* synthetic */ ih QG;
        private final C0182c<C0726a> QH;
        private final C0182c<PanoramaResult> QI;
        private final Uri QJ;

        public C0728b(ih ihVar, C0182c<C0726a> c0182c, C0182c<PanoramaResult> c0182c2, Uri uri) {
            this.QG = ihVar;
            this.QH = c0182c;
            this.QI = c0182c2;
            this.QJ = uri;
        }

        public void m2422a(int i, Bundle bundle, int i2, Intent intent) {
            if (this.QJ != null) {
                this.QG.getContext().revokeUriPermission(this.QJ, 1);
            }
            Status status = new Status(i, null, bundle != null ? (PendingIntent) bundle.getParcelable("pendingIntent") : null);
            if (this.QI != null) {
                this.QG.m620a(new C0729c(this.QG, this.QI, status, intent));
            } else if (this.QH != null) {
                this.QG.m620a(new C0727a(this.QG, this.QH, status, i2, intent));
            }
        }
    }

    /* renamed from: com.google.android.gms.internal.ih.c */
    final class C0729c extends C0523b<C0182c<PanoramaResult>> implements PanoramaResult {
        private final Status QE;
        private final Intent QF;
        final /* synthetic */ ih QG;

        public C0729c(ih ihVar, C0182c<PanoramaResult> c0182c, Status status, Intent intent) {
            this.QG = ihVar;
            super(ihVar, c0182c);
            this.QE = status;
            this.QF = intent;
        }

        protected /* synthetic */ void m2423a(Object obj) {
            m2424c((C0182c) obj);
        }

        protected void m2424c(C0182c<PanoramaResult> c0182c) {
            c0182c.m196b(this);
        }

        protected void cP() {
        }

        public Status getStatus() {
            return this.QE;
        }

        public Intent getViewerIntent() {
            return this.QF;
        }
    }

    public ih(Context context, Looper looper, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
        super(context, looper, connectionCallbacks, onConnectionFailedListener, (String[]) null);
    }

    @Deprecated
    public ih(Context context, GooglePlayServicesClient.ConnectionCallbacks connectionCallbacks, GooglePlayServicesClient.OnConnectionFailedListener onConnectionFailedListener) {
        this(context, context.getMainLooper(), new C0554c(connectionCallbacks), new C0558g(onConnectionFailedListener));
    }

    public void m2425a(C0182c<PanoramaResult> c0182c, Uri uri, boolean z) {
        m2427a(new C0728b(this, null, c0182c, z ? uri : null), uri, null, z);
    }

    protected void m2426a(en enVar, C0556e c0556e) throws RemoteException {
        enVar.m1492a(c0556e, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, getContext().getPackageName(), new Bundle());
    }

    public void m2427a(C0728b c0728b, Uri uri, Bundle bundle, boolean z) {
        bm();
        if (z) {
            getContext().grantUriPermission(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, uri, 1);
        }
        try {
            ((ig) eb()).m2418a(c0728b, uri, bundle, z);
        } catch (RemoteException e) {
            c0728b.m2422a(8, null, 0, null);
        }
    }

    protected String aF() {
        return "com.google.android.gms.panorama.service.START";
    }

    protected String aG() {
        return "com.google.android.gms.panorama.internal.IPanoramaService";
    }

    public ig ax(IBinder iBinder) {
        return C0725a.aw(iBinder);
    }

    public /* synthetic */ IInterface m2428p(IBinder iBinder) {
        return ax(iBinder);
    }
}
