package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public class jw implements Creator<jv> {
    static void m2549a(jv jvVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, jvVar.getVersionCode());
        C0265b.m491a(parcel, 2, jvVar.ZK, false);
        C0265b.m491a(parcel, 3, jvVar.oi, false);
        C0265b.m489a(parcel, 4, jvVar.ZO, i, false);
        C0265b.m489a(parcel, 5, jvVar.ZP, i, false);
        C0265b.m489a(parcel, 6, jvVar.ZQ, i, false);
        C0265b.m481D(parcel, p);
    }

    public jv bn(Parcel parcel) {
        jt jtVar = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        jt jtVar2 = null;
        jr jrVar = null;
        String str = null;
        String str2 = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    jrVar = (jr) C0264a.m446a(parcel, n, jr.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    jtVar2 = (jt) C0264a.m446a(parcel, n, jt.CREATOR);
                    break;
                case Error.OTHER /*6*/:
                    jtVar = (jt) C0264a.m446a(parcel, n, jt.CREATOR);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new jv(i, str2, str, jrVar, jtVar2, jtVar);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return bn(x0);
    }

    public jv[] ct(int i) {
        return new jv[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return ct(x0);
    }
}
