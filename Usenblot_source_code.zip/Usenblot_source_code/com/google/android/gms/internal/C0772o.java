package com.google.android.gms.internal;

import java.io.IOException;

/* renamed from: com.google.android.gms.internal.o */
interface C0772o {
    void m2609b(int i, long j) throws IOException;

    void m2610b(int i, String str) throws IOException;

    void reset();

    byte[] m2611z() throws IOException;
}
