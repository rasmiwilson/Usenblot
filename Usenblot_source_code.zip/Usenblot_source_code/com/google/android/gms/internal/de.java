package com.google.android.gms.internal;

import android.net.Uri;
import android.net.UrlQuerySanitizer;
import android.net.UrlQuerySanitizer.ParameterValuePair;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.HashMap;
import java.util.Map;

public class de extends WebViewClient {
    private ap lV;
    private final Object mg;
    protected final dd ng;
    private final HashMap<String, ar> qf;
    private C0783u qg;
    private br qh;
    private C0465a qi;
    private boolean qj;
    private boolean qk;
    private bu ql;

    /* renamed from: com.google.android.gms.internal.de.a */
    public interface C0465a {
        void m1045a(dd ddVar);
    }

    /* renamed from: com.google.android.gms.internal.de.1 */
    class C05101 implements Runnable {
        final /* synthetic */ bo qm;
        final /* synthetic */ de qn;

        C05101(de deVar, bo boVar) {
            this.qn = deVar;
            this.qm = boVar;
        }

        public void run() {
            this.qm.ar();
        }
    }

    public de(dd ddVar, boolean z) {
        this.qf = new HashMap();
        this.mg = new Object();
        this.qj = false;
        this.ng = ddVar;
        this.qk = z;
    }

    private void m1284a(bq bqVar) {
        bo.m1049a(this.ng.getContext(), bqVar);
    }

    private static boolean m1285b(Uri uri) {
        String scheme = uri.getScheme();
        return "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme);
    }

    private void m1286c(Uri uri) {
        String path = uri.getPath();
        ar arVar = (ar) this.qf.get(path);
        if (arVar != null) {
            Map hashMap = new HashMap();
            UrlQuerySanitizer urlQuerySanitizer = new UrlQuerySanitizer();
            urlQuerySanitizer.setAllowUnregisteredParamaters(true);
            urlQuerySanitizer.setUnregisteredParameterValueSanitizer(UrlQuerySanitizer.getAllButNulLegal());
            urlQuerySanitizer.parseUrl(uri.toString());
            for (ParameterValuePair parameterValuePair : urlQuerySanitizer.getParameterList()) {
                hashMap.put(parameterValuePair.mParameter, parameterValuePair.mValue);
            }
            if (da.m1268n(2)) {
                da.m1272v("Received GMSG: " + path);
                for (String str : hashMap.keySet()) {
                    da.m1272v("  " + str + ": " + ((String) hashMap.get(str)));
                }
            }
            arVar.m971a(this.ng, hashMap);
            return;
        }
        da.m1273w("No GMSG handler found for GMSG: " + uri);
    }

    public final void m1287a(bn bnVar) {
        br brVar = null;
        boolean be = this.ng.be();
        C0783u c0783u = (!be || this.ng.m1278Q().lo) ? this.qg : null;
        if (!be) {
            brVar = this.qh;
        }
        m1284a(new bq(bnVar, c0783u, brVar, this.ql, this.ng.bd()));
    }

    public final void m1288a(C0465a c0465a) {
        this.qi = c0465a;
    }

    public void m1289a(C0783u c0783u, br brVar, ap apVar, bu buVar, boolean z) {
        m1290a("/appEvent", new ao(apVar));
        m1290a("/canOpenURLs", aq.lW);
        m1290a("/click", aq.lX);
        m1290a("/close", aq.lY);
        m1290a("/customClose", aq.lZ);
        m1290a("/httpTrack", aq.ma);
        m1290a("/log", aq.mb);
        m1290a("/open", aq.mc);
        m1290a("/touch", aq.md);
        m1290a("/video", aq.me);
        this.qg = c0783u;
        this.qh = brVar;
        this.lV = apVar;
        this.ql = buVar;
        m1294o(z);
    }

    public final void m1290a(String str, ar arVar) {
        this.qf.put(str, arVar);
    }

    public final void m1291a(boolean z, int i) {
        C0783u c0783u = (!this.ng.be() || this.ng.m1278Q().lo) ? this.qg : null;
        m1284a(new bq(c0783u, this.qh, this.ql, this.ng, z, i, this.ng.bd()));
    }

    public final void m1292a(boolean z, int i, String str) {
        br brVar = null;
        boolean be = this.ng.be();
        C0783u c0783u = (!be || this.ng.m1278Q().lo) ? this.qg : null;
        if (!be) {
            brVar = this.qh;
        }
        m1284a(new bq(c0783u, brVar, this.lV, this.ql, this.ng, z, i, str, this.ng.bd()));
    }

    public final void m1293a(boolean z, int i, String str, String str2) {
        br brVar = null;
        boolean be = this.ng.be();
        C0783u c0783u = (!be || this.ng.m1278Q().lo) ? this.qg : null;
        if (!be) {
            brVar = this.qh;
        }
        m1284a(new bq(c0783u, brVar, this.lV, this.ql, this.ng, z, i, str, str2, this.ng.bd()));
    }

    public final void ar() {
        synchronized (this.mg) {
            this.qj = false;
            this.qk = true;
            bo ba = this.ng.ba();
            if (ba != null) {
                if (cz.aX()) {
                    ba.ar();
                } else {
                    cz.pT.post(new C05101(this, ba));
                }
            }
        }
    }

    public boolean bi() {
        boolean z;
        synchronized (this.mg) {
            z = this.qk;
        }
        return z;
    }

    public final void m1294o(boolean z) {
        this.qj = z;
    }

    public final void onPageFinished(WebView webView, String url) {
        if (this.qi != null) {
            this.qi.m1045a(this.ng);
            this.qi = null;
        }
    }

    public final void reset() {
        synchronized (this.mg) {
            this.qf.clear();
            this.qg = null;
            this.qh = null;
            this.qi = null;
            this.lV = null;
            this.qj = false;
            this.qk = false;
            this.ql = null;
        }
    }

    public final boolean shouldOverrideUrlLoading(WebView webView, String url) {
        da.m1272v("AdWebView shouldOverrideUrlLoading: " + url);
        Uri parse = Uri.parse(url);
        if ("gmsg".equalsIgnoreCase(parse.getScheme()) && "mobileads.google.com".equalsIgnoreCase(parse.getHost())) {
            m1286c(parse);
        } else if (this.qj && webView == this.ng && m1285b(parse)) {
            return super.shouldOverrideUrlLoading(webView, url);
        } else {
            if (this.ng.willNotDraw()) {
                da.m1273w("AdWebView unable to handle URL: " + url);
            } else {
                Uri uri;
                try {
                    C0770l bc = this.ng.bc();
                    if (bc != null && bc.m2607a(parse)) {
                        parse = bc.m2605a(parse, this.ng.getContext());
                    }
                    uri = parse;
                } catch (C0771m e) {
                    da.m1273w("Unable to append parameter to URL: " + url);
                    uri = parse;
                }
                m1287a(new bn("android.intent.action.VIEW", uri.toString(), null, null, null, null, null));
            }
        }
        return true;
    }
}
