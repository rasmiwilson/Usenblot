package com.google.android.gms.internal;

import java.io.IOException;

public abstract class ke {
    protected int DY;

    public ke() {
        this.DY = -1;
    }

    public static final <T extends ke> T m727a(T t, byte[] bArr) throws kd {
        return m729b(t, bArr, 0, bArr.length);
    }

    public static final void m728a(ke keVar, byte[] bArr, int i, int i2) {
        try {
            jz b = jz.m2564b(bArr, i, i2);
            keVar.m731a(b);
            b.kN();
        } catch (Throwable e) {
            throw new RuntimeException("Serializing to a byte array threw an IOException (should never happen).", e);
        }
    }

    public static final <T extends ke> T m729b(T t, byte[] bArr, int i, int i2) throws kd {
        try {
            jy a = jy.m2551a(bArr, i, i2);
            t.m732b(a);
            a.cu(0);
            return t;
        } catch (kd e) {
            throw e;
        } catch (IOException e2) {
            throw new RuntimeException("Reading from a byte array threw an IOException (should never happen).");
        }
    }

    public static final byte[] m730d(ke keVar) {
        byte[] bArr = new byte[keVar.m733c()];
        m728a(keVar, bArr, 0, bArr.length);
        return bArr;
    }

    public void m731a(jz jzVar) throws IOException {
    }

    public abstract ke m732b(jy jyVar) throws IOException;

    public int m733c() {
        this.DY = 0;
        return 0;
    }

    public int eW() {
        if (this.DY < 0) {
            m733c();
        }
        return this.DY;
    }

    public String toString() {
        return kf.m2599e(this);
    }
}
