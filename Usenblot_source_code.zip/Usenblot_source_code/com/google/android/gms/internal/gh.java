package com.google.android.gms.internal;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.games.Game;
import com.google.android.gms.games.GameBuffer;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.Games.C0389a;
import com.google.android.gms.games.GamesMetadata;
import com.google.android.gms.games.GamesMetadata.LoadGamesResult;

public final class gh implements GamesMetadata {

    /* renamed from: com.google.android.gms.internal.gh.a */
    private static abstract class C0638a extends C0389a<LoadGamesResult> {

        /* renamed from: com.google.android.gms.internal.gh.a.1 */
        class C06401 implements LoadGamesResult {
            final /* synthetic */ C0638a HO;
            final /* synthetic */ Status vb;

            C06401(C0638a c0638a, Status status) {
                this.HO = c0638a;
                this.vb = status;
            }

            public GameBuffer getGames() {
                return new GameBuffer(DataHolder.empty(14));
            }

            public Status getStatus() {
                return this.vb;
            }

            public void release() {
            }
        }

        private C0638a() {
        }

        public /* synthetic */ Result m2228d(Status status) {
            return m2229u(status);
        }

        public LoadGamesResult m2229u(Status status) {
            return new C06401(this, status);
        }
    }

    /* renamed from: com.google.android.gms.internal.gh.1 */
    class C06391 extends C0638a {
        final /* synthetic */ gh HN;

        C06391(gh ghVar) {
            this.HN = ghVar;
            super();
        }

        protected void m2231a(fx fxVar) {
            fxVar.m1908g(this);
        }
    }

    public Game getCurrentGame(GoogleApiClient apiClient) {
        return Games.m843c(apiClient).fq();
    }

    public PendingResult<LoadGamesResult> loadGame(GoogleApiClient apiClient) {
        return apiClient.m365a(new C06391(this));
    }
}
