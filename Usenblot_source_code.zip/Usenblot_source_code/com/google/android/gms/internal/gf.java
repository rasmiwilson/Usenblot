package com.google.android.gms.internal;

import android.content.Intent;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.Games.C0389a;
import com.google.android.gms.games.achievement.AchievementBuffer;
import com.google.android.gms.games.achievement.Achievements;
import com.google.android.gms.games.achievement.Achievements.LoadAchievementsResult;
import com.google.android.gms.games.achievement.Achievements.UpdateAchievementResult;

public final class gf implements Achievements {

    /* renamed from: com.google.android.gms.internal.gf.a */
    private static abstract class C0625a extends C0389a<LoadAchievementsResult> {

        /* renamed from: com.google.android.gms.internal.gf.a.1 */
        class C06361 implements LoadAchievementsResult {
            final /* synthetic */ C0625a HL;
            final /* synthetic */ Status vb;

            C06361(C0625a c0625a, Status status) {
                this.HL = c0625a;
                this.vb = status;
            }

            public AchievementBuffer getAchievements() {
                return new AchievementBuffer(DataHolder.empty(14));
            }

            public Status getStatus() {
                return this.vb;
            }

            public void release() {
            }
        }

        private C0625a() {
        }

        public /* synthetic */ Result m2205d(Status status) {
            return m2206s(status);
        }

        public LoadAchievementsResult m2206s(Status status) {
            return new C06361(this, status);
        }
    }

    /* renamed from: com.google.android.gms.internal.gf.1 */
    class C06261 extends C0625a {
        final /* synthetic */ boolean HH;
        final /* synthetic */ gf HI;

        C06261(gf gfVar, boolean z) {
            this.HI = gfVar;
            this.HH = z;
            super();
        }

        public void m2208a(fx fxVar) {
            fxVar.m1902c((C0182c) this, this.HH);
        }
    }

    /* renamed from: com.google.android.gms.internal.gf.b */
    private static abstract class C0627b extends C0389a<UpdateAchievementResult> {
        private final String uS;

        /* renamed from: com.google.android.gms.internal.gf.b.1 */
        class C06371 implements UpdateAchievementResult {
            final /* synthetic */ C0627b HM;
            final /* synthetic */ Status vb;

            C06371(C0627b c0627b, Status status) {
                this.HM = c0627b;
                this.vb = status;
            }

            public String getAchievementId() {
                return this.HM.uS;
            }

            public Status getStatus() {
                return this.vb;
            }
        }

        public C0627b(String str) {
            this.uS = str;
        }

        public /* synthetic */ Result m2210d(Status status) {
            return m2211t(status);
        }

        public UpdateAchievementResult m2211t(Status status) {
            return new C06371(this, status);
        }
    }

    /* renamed from: com.google.android.gms.internal.gf.2 */
    class C06282 extends C0627b {
        final /* synthetic */ gf HI;
        final /* synthetic */ String HJ;

        C06282(gf gfVar, String str, String str2) {
            this.HI = gfVar;
            this.HJ = str2;
            super(str);
        }

        public void m2213a(fx fxVar) {
            fxVar.m1893b(null, this.HJ);
        }
    }

    /* renamed from: com.google.android.gms.internal.gf.3 */
    class C06293 extends C0627b {
        final /* synthetic */ gf HI;
        final /* synthetic */ String HJ;

        C06293(gf gfVar, String str, String str2) {
            this.HI = gfVar;
            this.HJ = str2;
            super(str);
        }

        public void m2215a(fx fxVar) {
            fxVar.m1893b((C0182c) this, this.HJ);
        }
    }

    /* renamed from: com.google.android.gms.internal.gf.4 */
    class C06304 extends C0627b {
        final /* synthetic */ gf HI;
        final /* synthetic */ String HJ;

        C06304(gf gfVar, String str, String str2) {
            this.HI = gfVar;
            this.HJ = str2;
            super(str);
        }

        public void m2217a(fx fxVar) {
            fxVar.m1901c(null, this.HJ);
        }
    }

    /* renamed from: com.google.android.gms.internal.gf.5 */
    class C06315 extends C0627b {
        final /* synthetic */ gf HI;
        final /* synthetic */ String HJ;

        C06315(gf gfVar, String str, String str2) {
            this.HI = gfVar;
            this.HJ = str2;
            super(str);
        }

        public void m2219a(fx fxVar) {
            fxVar.m1901c((C0182c) this, this.HJ);
        }
    }

    /* renamed from: com.google.android.gms.internal.gf.6 */
    class C06326 extends C0627b {
        final /* synthetic */ gf HI;
        final /* synthetic */ String HJ;
        final /* synthetic */ int HK;

        C06326(gf gfVar, String str, String str2, int i) {
            this.HI = gfVar;
            this.HJ = str2;
            this.HK = i;
            super(str);
        }

        public void m2221a(fx fxVar) {
            fxVar.m1874a(null, this.HJ, this.HK);
        }
    }

    /* renamed from: com.google.android.gms.internal.gf.7 */
    class C06337 extends C0627b {
        final /* synthetic */ gf HI;
        final /* synthetic */ String HJ;
        final /* synthetic */ int HK;

        C06337(gf gfVar, String str, String str2, int i) {
            this.HI = gfVar;
            this.HJ = str2;
            this.HK = i;
            super(str);
        }

        public void m2223a(fx fxVar) {
            fxVar.m1874a((C0182c) this, this.HJ, this.HK);
        }
    }

    /* renamed from: com.google.android.gms.internal.gf.8 */
    class C06348 extends C0627b {
        final /* synthetic */ gf HI;
        final /* synthetic */ String HJ;
        final /* synthetic */ int HK;

        C06348(gf gfVar, String str, String str2, int i) {
            this.HI = gfVar;
            this.HJ = str2;
            this.HK = i;
            super(str);
        }

        public void m2225a(fx fxVar) {
            fxVar.m1894b(null, this.HJ, this.HK);
        }
    }

    /* renamed from: com.google.android.gms.internal.gf.9 */
    class C06359 extends C0627b {
        final /* synthetic */ gf HI;
        final /* synthetic */ String HJ;
        final /* synthetic */ int HK;

        C06359(gf gfVar, String str, String str2, int i) {
            this.HI = gfVar;
            this.HJ = str2;
            this.HK = i;
            super(str);
        }

        public void m2227a(fx fxVar) {
            fxVar.m1894b((C0182c) this, this.HJ, this.HK);
        }
    }

    public Intent getAchievementsIntent(GoogleApiClient apiClient) {
        return Games.m843c(apiClient).fs();
    }

    public void increment(GoogleApiClient apiClient, String id, int numSteps) {
        apiClient.m366b(new C06326(this, id, id, numSteps));
    }

    public PendingResult<UpdateAchievementResult> incrementImmediate(GoogleApiClient apiClient, String id, int numSteps) {
        return apiClient.m366b(new C06337(this, id, id, numSteps));
    }

    public PendingResult<LoadAchievementsResult> load(GoogleApiClient apiClient, boolean forceReload) {
        return apiClient.m365a(new C06261(this, forceReload));
    }

    public void reveal(GoogleApiClient apiClient, String id) {
        apiClient.m366b(new C06282(this, id, id));
    }

    public PendingResult<UpdateAchievementResult> revealImmediate(GoogleApiClient apiClient, String id) {
        return apiClient.m366b(new C06293(this, id, id));
    }

    public void setSteps(GoogleApiClient apiClient, String id, int numSteps) {
        apiClient.m366b(new C06348(this, id, id, numSteps));
    }

    public PendingResult<UpdateAchievementResult> setStepsImmediate(GoogleApiClient apiClient, String id, int numSteps) {
        return apiClient.m366b(new C06359(this, id, id, numSteps));
    }

    public void unlock(GoogleApiClient apiClient, String id) {
        apiClient.m366b(new C06304(this, id, id));
    }

    public PendingResult<UpdateAchievementResult> unlockImmediate(GoogleApiClient apiClient, String id) {
        return apiClient.m366b(new C06315(this, id, id));
    }
}
