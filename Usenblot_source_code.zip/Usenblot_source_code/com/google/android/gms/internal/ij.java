package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api.C0179b;
import com.google.android.gms.plus.C0733a;
import com.google.android.gms.plus.internal.C0946e;

public final class ij implements C0733a {
    private final C0179b<C0946e> Rw;

    public ij(C0179b<C0946e> c0179b) {
        this.Rw = c0179b;
    }
}
