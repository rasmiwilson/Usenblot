package com.google.android.gms.internal;

import android.content.Context;
import android.os.RemoteException;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.doubleclick.AppEventListener;

public final class al {
    private final be lF;
    private ag lG;
    private AdListener lc;
    private AppEventListener lq;
    private String ls;
    private final Context mContext;

    public al(Context context) {
        this.lF = new be();
        this.mContext = context;
    }

    private void m965k(String str) throws RemoteException {
        if (this.ls == null) {
            m966l(str);
        }
        this.lG = C0789y.m2672a(this.mContext, new ab(), this.ls, this.lF);
        if (this.lc != null) {
            this.lG.m929a(new C0788x(this.lc));
        }
        if (this.lq != null) {
            this.lG.m930a(new ad(this.lq));
        }
    }

    private void m966l(String str) {
        if (this.lG == null) {
            throw new IllegalStateException("The ad unit ID must be set on InterstitialAd before " + str + " is called.");
        }
    }

    public void m967a(aj ajVar) {
        try {
            if (this.lG == null) {
                m965k("loadAd");
            }
            if (this.lG.m931a(new C0790z(this.mContext, ajVar))) {
                this.lF.m1016c(ajVar.ak());
            }
        } catch (Throwable e) {
            da.m1267b("Failed to load ad.", e);
        }
    }

    public AdListener getAdListener() {
        return this.lc;
    }

    public String getAdUnitId() {
        return this.ls;
    }

    public AppEventListener getAppEventListener() {
        return this.lq;
    }

    public boolean isLoaded() {
        boolean z = false;
        try {
            if (this.lG != null) {
                z = this.lG.isReady();
            }
        } catch (Throwable e) {
            da.m1267b("Failed to check if ad is ready.", e);
        }
        return z;
    }

    public void setAdListener(AdListener adListener) {
        try {
            this.lc = adListener;
            if (this.lG != null) {
                this.lG.m929a(adListener != null ? new C0788x(adListener) : null);
            }
        } catch (Throwable e) {
            da.m1267b("Failed to set the AdListener.", e);
        }
    }

    public void setAdUnitId(String adUnitId) {
        if (this.ls != null) {
            throw new IllegalStateException("The ad unit ID can only be set once on InterstitialAd.");
        }
        this.ls = adUnitId;
    }

    public void setAppEventListener(AppEventListener appEventListener) {
        try {
            this.lq = appEventListener;
            if (this.lG != null) {
                this.lG.m930a(appEventListener != null ? new ad(appEventListener) : null);
            }
        } catch (Throwable e) {
            da.m1267b("Failed to set the AppEventListener.", e);
        }
    }

    public void show() {
        try {
            m966l("show");
            this.lG.showInterstitial();
        } catch (Throwable e) {
            da.m1267b("Failed to show interstitial.", e);
        }
    }
}
