package com.google.android.gms.internal;

import android.content.Context;
import android.os.IBinder;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.dynamic.C0383c;
import com.google.android.gms.dynamic.C0385e;
import com.google.android.gms.internal.ag.C0433a;
import com.google.android.gms.internal.ah.C0435a;

/* renamed from: com.google.android.gms.internal.y */
public final class C0789y extends C0385e<ah> {
    private static final C0789y ld;

    static {
        ld = new C0789y();
    }

    private C0789y() {
        super("com.google.android.gms.ads.AdManagerCreatorImpl");
    }

    public static ag m2672a(Context context, ab abVar, String str, be beVar) {
        if (GooglePlayServicesUtil.isGooglePlayServicesAvailable(context) == 0) {
            ag b = ld.m2673b(context, abVar, str, beVar);
            if (b != null) {
                return b;
            }
        }
        da.m1269s("Using AdManager from the client jar.");
        return new C0785v(context, abVar, str, beVar, new db(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE, true));
    }

    private ag m2673b(Context context, ab abVar, String str, be beVar) {
        try {
            return C0433a.m939f(((ah) m829z(context)).m940a(C0383c.m827h(context), abVar, str, beVar, GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_VERSION_CODE));
        } catch (Throwable e) {
            da.m1267b("Could not create remote AdManager.", e);
            return null;
        } catch (Throwable e2) {
            da.m1267b("Could not create remote AdManager.", e2);
            return null;
        }
    }

    protected ah m2674c(IBinder iBinder) {
        return C0435a.m942g(iBinder);
    }

    protected /* synthetic */ Object m2675d(IBinder iBinder) {
        return m2674c(iBinder);
    }
}
