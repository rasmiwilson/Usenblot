package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.List;

public class cg implements Creator<cf> {
    static void m1168a(cf cfVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, cfVar.versionCode);
        C0265b.m491a(parcel, 2, cfVar.nw, false);
        C0265b.m491a(parcel, 3, cfVar.oi, false);
        C0265b.m492a(parcel, 4, cfVar.mt, false);
        C0265b.m501c(parcel, 5, cfVar.errorCode);
        C0265b.m492a(parcel, 6, cfVar.mu, false);
        C0265b.m485a(parcel, 7, cfVar.oj);
        C0265b.m494a(parcel, 8, cfVar.ok);
        C0265b.m485a(parcel, 9, cfVar.ol);
        C0265b.m492a(parcel, 10, cfVar.om, false);
        C0265b.m485a(parcel, 11, cfVar.mx);
        C0265b.m501c(parcel, 12, cfVar.orientation);
        C0265b.m491a(parcel, 13, cfVar.on, false);
        C0265b.m485a(parcel, 14, cfVar.oo);
        C0265b.m481D(parcel, p);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1169g(x0);
    }

    public cf m1169g(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        int i = 0;
        String str = null;
        String str2 = null;
        List list = null;
        int i2 = 0;
        List list2 = null;
        long j = 0;
        boolean z = false;
        long j2 = 0;
        List list3 = null;
        long j3 = 0;
        int i3 = 0;
        String str3 = null;
        long j4 = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    list = C0264a.m477y(parcel, n);
                    break;
                case Error.DECLINED /*5*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    list2 = C0264a.m477y(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    j = C0264a.m458h(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                    z = C0264a.m453c(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                    j2 = C0264a.m458h(parcel, n);
                    break;
                case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                    list3 = C0264a.m477y(parcel, n);
                    break;
                case CommonStatusCodes.LICENSE_CHECK_FAILED /*11*/:
                    j3 = C0264a.m458h(parcel, n);
                    break;
                case CommonStatusCodes.DATE_INVALID /*12*/:
                    i3 = C0264a.m457g(parcel, n);
                    break;
                case CommonStatusCodes.ERROR /*13*/:
                    str3 = C0264a.m463m(parcel, n);
                    break;
                case GamesStatusCodes.STATUS_INTERRUPTED /*14*/:
                    j4 = C0264a.m458h(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new cf(i, str, str2, list, i2, list2, j, z, j2, list3, j3, i3, str3, j4);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public cf[] m1170l(int i) {
        return new cf[i];
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m1170l(x0);
    }
}
