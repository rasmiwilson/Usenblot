package com.google.android.gms.internal;

public abstract class fy extends eg {
    protected static boolean m832c(Integer num) {
        return num == null ? false : fo.ab(num.intValue());
    }
}
