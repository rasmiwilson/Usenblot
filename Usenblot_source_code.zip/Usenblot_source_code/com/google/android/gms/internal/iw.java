package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.internal.ir.C0752b.C0751b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.HashSet;
import java.util.Set;

public class iw implements Creator<C0751b> {
    static void m2492a(C0751b c0751b, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        Set hB = c0751b.hB();
        if (hB.contains(Integer.valueOf(1))) {
            C0265b.m501c(parcel, 1, c0751b.getVersionCode());
        }
        if (hB.contains(Integer.valueOf(2))) {
            C0265b.m501c(parcel, 2, c0751b.getHeight());
        }
        if (hB.contains(Integer.valueOf(3))) {
            C0265b.m491a(parcel, 3, c0751b.getUrl(), true);
        }
        if (hB.contains(Integer.valueOf(4))) {
            C0265b.m501c(parcel, 4, c0751b.getWidth());
        }
        C0265b.m481D(parcel, p);
    }

    public C0751b aM(Parcel parcel) {
        int i = 0;
        int o = C0264a.m466o(parcel);
        Set hashSet = new HashSet();
        String str = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i3 = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    i2 = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case Error.BAD_CVC /*3*/:
                    str = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(3));
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    i = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(4));
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new C0751b(hashSet, i3, i2, str, i);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public C0751b[] bJ(int i) {
        return new C0751b[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aM(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bJ(x0);
    }
}
