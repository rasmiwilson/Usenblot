package com.google.android.gms.internal;

import java.util.Map;

public interface ar {
    void m971a(dd ddVar, Map<String, String> map);
}
