package com.google.android.gms.internal;

public final class gg implements gw {
}
