package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.internal.ir.C0753c;
import java.util.HashSet;
import java.util.Set;

public class ix implements Creator<C0753c> {
    static void m2493a(C0753c c0753c, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        Set hB = c0753c.hB();
        if (hB.contains(Integer.valueOf(1))) {
            C0265b.m501c(parcel, 1, c0753c.getVersionCode());
        }
        if (hB.contains(Integer.valueOf(2))) {
            C0265b.m491a(parcel, 2, c0753c.getUrl(), true);
        }
        C0265b.m481D(parcel, p);
    }

    public C0753c aN(Parcel parcel) {
        int o = C0264a.m466o(parcel);
        Set hashSet = new HashSet();
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str = C0264a.m463m(parcel, n);
                    hashSet.add(Integer.valueOf(2));
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new C0753c(hashSet, i, str);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public C0753c[] bK(int i) {
        return new C0753c[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aN(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bK(x0);
    }
}
