package com.google.android.gms.internal;

import android.content.Intent;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.Games.C0389a;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.PlayerBuffer;
import com.google.android.gms.games.Players;
import com.google.android.gms.games.Players.LoadPlayersResult;

public final class gm implements Players {

    /* renamed from: com.google.android.gms.internal.gm.a */
    private static abstract class C0659a extends C0389a<LoadPlayersResult> {

        /* renamed from: com.google.android.gms.internal.gm.a.1 */
        class C06661 implements LoadPlayersResult {
            final /* synthetic */ C0659a Ii;
            final /* synthetic */ Status vb;

            C06661(C0659a c0659a, Status status) {
                this.Ii = c0659a;
                this.vb = status;
            }

            public PlayerBuffer getPlayers() {
                return new PlayerBuffer(DataHolder.empty(14));
            }

            public Status getStatus() {
                return this.vb;
            }

            public void release() {
            }
        }

        private C0659a() {
        }

        public LoadPlayersResult m2258A(Status status) {
            return new C06661(this, status);
        }

        public /* synthetic */ Result m2259d(Status status) {
            return m2258A(status);
        }
    }

    /* renamed from: com.google.android.gms.internal.gm.1 */
    class C06601 extends C0659a {
        final /* synthetic */ String If;
        final /* synthetic */ gm Ig;

        C06601(gm gmVar, String str) {
            this.Ig = gmVar;
            this.If = str;
            super();
        }

        protected void m2261a(fx fxVar) {
            fxVar.m1873a((C0182c) this, this.If);
        }
    }

    /* renamed from: com.google.android.gms.internal.gm.2 */
    class C06612 extends C0659a {
        final /* synthetic */ boolean HH;
        final /* synthetic */ gm Ig;
        final /* synthetic */ int Ih;

        C06612(gm gmVar, int i, boolean z) {
            this.Ig = gmVar;
            this.Ih = i;
            this.HH = z;
            super();
        }

        protected void m2263a(fx fxVar) {
            fxVar.m1869a((C0182c) this, this.Ih, false, this.HH);
        }
    }

    /* renamed from: com.google.android.gms.internal.gm.3 */
    class C06623 extends C0659a {
        final /* synthetic */ gm Ig;
        final /* synthetic */ int Ih;

        C06623(gm gmVar, int i) {
            this.Ig = gmVar;
            this.Ih = i;
            super();
        }

        protected void m2265a(fx fxVar) {
            fxVar.m1869a((C0182c) this, this.Ih, true, false);
        }
    }

    /* renamed from: com.google.android.gms.internal.gm.4 */
    class C06634 extends C0659a {
        final /* synthetic */ boolean HH;
        final /* synthetic */ gm Ig;
        final /* synthetic */ int Ih;

        C06634(gm gmVar, int i, boolean z) {
            this.Ig = gmVar;
            this.Ih = i;
            this.HH = z;
            super();
        }

        protected void m2267a(fx fxVar) {
            fxVar.m1876a((C0182c) this, "playedWith", this.Ih, false, this.HH);
        }
    }

    /* renamed from: com.google.android.gms.internal.gm.5 */
    class C06645 extends C0659a {
        final /* synthetic */ gm Ig;
        final /* synthetic */ int Ih;

        C06645(gm gmVar, int i) {
            this.Ig = gmVar;
            this.Ih = i;
            super();
        }

        protected void m2269a(fx fxVar) {
            fxVar.m1876a((C0182c) this, "playedWith", this.Ih, true, false);
        }
    }

    /* renamed from: com.google.android.gms.internal.gm.6 */
    class C06656 extends C0659a {
        final /* synthetic */ boolean HH;
        final /* synthetic */ gm Ig;

        C06656(gm gmVar, boolean z) {
            this.Ig = gmVar;
            this.HH = z;
            super();
        }

        protected void m2271a(fx fxVar) {
            fxVar.m1883a((C0182c) this, this.HH);
        }
    }

    public Player getCurrentPlayer(GoogleApiClient apiClient) {
        return Games.m843c(apiClient).fp();
    }

    public String getCurrentPlayerId(GoogleApiClient apiClient) {
        return Games.m843c(apiClient).fo();
    }

    public Intent getPlayerSearchIntent(GoogleApiClient apiClient) {
        return Games.m843c(apiClient).fy();
    }

    public PendingResult<LoadPlayersResult> loadConnectedPlayers(GoogleApiClient apiClient, boolean forceReload) {
        return apiClient.m365a(new C06656(this, forceReload));
    }

    public PendingResult<LoadPlayersResult> loadInvitablePlayers(GoogleApiClient apiClient, int pageSize, boolean forceReload) {
        return apiClient.m365a(new C06612(this, pageSize, forceReload));
    }

    public PendingResult<LoadPlayersResult> loadMoreInvitablePlayers(GoogleApiClient apiClient, int pageSize) {
        return apiClient.m365a(new C06623(this, pageSize));
    }

    public PendingResult<LoadPlayersResult> loadMoreRecentlyPlayedWithPlayers(GoogleApiClient apiClient, int pageSize) {
        return apiClient.m365a(new C06645(this, pageSize));
    }

    public PendingResult<LoadPlayersResult> loadPlayer(GoogleApiClient apiClient, String playerId) {
        return apiClient.m365a(new C06601(this, playerId));
    }

    public PendingResult<LoadPlayersResult> loadRecentlyPlayedWithPlayers(GoogleApiClient apiClient, int pageSize, boolean forceReload) {
        return apiClient.m365a(new C06634(this, pageSize, forceReload));
    }
}
