package com.google.android.gms.internal;

import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.internal.dm.C0521a;

public abstract class dk extends C0521a {
    public void m1310a(int i, DataHolder dataHolder) {
    }

    public void m1311a(DataHolder dataHolder) {
    }

    public void m1312b(int i, int i2) {
    }

    public void cM() {
    }

    public void m1313v(int i) {
    }
}
