package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.internal.ir.C0752b.C0750a;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import java.util.HashSet;
import java.util.Set;

public class iv implements Creator<C0750a> {
    static void m2491a(C0750a c0750a, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        Set hB = c0750a.hB();
        if (hB.contains(Integer.valueOf(1))) {
            C0265b.m501c(parcel, 1, c0750a.getVersionCode());
        }
        if (hB.contains(Integer.valueOf(2))) {
            C0265b.m501c(parcel, 2, c0750a.getLeftImageOffset());
        }
        if (hB.contains(Integer.valueOf(3))) {
            C0265b.m501c(parcel, 3, c0750a.getTopImageOffset());
        }
        C0265b.m481D(parcel, p);
    }

    public C0750a aL(Parcel parcel) {
        int i = 0;
        int o = C0264a.m466o(parcel);
        Set hashSet = new HashSet();
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i3 = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(1));
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    i2 = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(2));
                    break;
                case Error.BAD_CVC /*3*/:
                    i = C0264a.m457g(parcel, n);
                    hashSet.add(Integer.valueOf(3));
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new C0750a(hashSet, i3, i2, i);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public C0750a[] bI(int i) {
        return new C0750a[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return aL(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return bI(x0);
    }
}
