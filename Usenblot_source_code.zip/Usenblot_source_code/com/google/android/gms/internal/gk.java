package com.google.android.gms.internal;

import com.google.android.gms.games.multiplayer.Multiplayer;

public final class gk implements Multiplayer {
}
