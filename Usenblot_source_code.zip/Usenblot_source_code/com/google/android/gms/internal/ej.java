package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.IBinder;
import android.os.Message;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.internal.eh.C0557f;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public final class ej implements Callback {
    private static final Object BQ;
    private static ej BR;
    private final HashMap<String, C0562a> BS;
    private final Handler mHandler;
    private final Context qe;

    /* renamed from: com.google.android.gms.internal.ej.a */
    final class C0562a {
        private final String BT;
        private final C0561a BU;
        private final HashSet<C0557f> BV;
        private boolean BW;
        private IBinder BX;
        private ComponentName BY;
        final /* synthetic */ ej BZ;
        private int mState;

        /* renamed from: com.google.android.gms.internal.ej.a.a */
        public class C0561a implements ServiceConnection {
            final /* synthetic */ C0562a Ca;

            public C0561a(C0562a c0562a) {
                this.Ca = c0562a;
            }

            public void onServiceConnected(ComponentName component, IBinder binder) {
                synchronized (this.Ca.BZ.BS) {
                    this.Ca.BX = binder;
                    this.Ca.BY = component;
                    Iterator it = this.Ca.BV.iterator();
                    while (it.hasNext()) {
                        ((C0557f) it.next()).onServiceConnected(component, binder);
                    }
                    this.Ca.mState = 1;
                }
            }

            public void onServiceDisconnected(ComponentName component) {
                synchronized (this.Ca.BZ.BS) {
                    this.Ca.BX = null;
                    this.Ca.BY = component;
                    Iterator it = this.Ca.BV.iterator();
                    while (it.hasNext()) {
                        ((C0557f) it.next()).onServiceDisconnected(component);
                    }
                    this.Ca.mState = 2;
                }
            }
        }

        public C0562a(ej ejVar, String str) {
            this.BZ = ejVar;
            this.BT = str;
            this.BU = new C0561a(this);
            this.BV = new HashSet();
            this.mState = 0;
        }

        public void m1476a(C0557f c0557f) {
            this.BV.add(c0557f);
        }

        public void m1477b(C0557f c0557f) {
            this.BV.remove(c0557f);
        }

        public boolean m1478c(C0557f c0557f) {
            return this.BV.contains(c0557f);
        }

        public C0561a ee() {
            return this.BU;
        }

        public String ef() {
            return this.BT;
        }

        public boolean eg() {
            return this.BV.isEmpty();
        }

        public IBinder getBinder() {
            return this.BX;
        }

        public ComponentName getComponentName() {
            return this.BY;
        }

        public int getState() {
            return this.mState;
        }

        public boolean isBound() {
            return this.BW;
        }

        public void m1479w(boolean z) {
            this.BW = z;
        }
    }

    static {
        BQ = new Object();
    }

    private ej(Context context) {
        this.mHandler = new Handler(context.getMainLooper(), this);
        this.BS = new HashMap();
        this.qe = context.getApplicationContext();
    }

    public static ej m1481y(Context context) {
        synchronized (BQ) {
            if (BR == null) {
                BR = new ej(context.getApplicationContext());
            }
        }
        return BR;
    }

    public boolean m1482a(String str, C0557f c0557f) {
        boolean isBound;
        synchronized (this.BS) {
            C0562a c0562a = (C0562a) this.BS.get(str);
            if (c0562a != null) {
                this.mHandler.removeMessages(0, c0562a);
                if (!c0562a.m1478c(c0557f)) {
                    c0562a.m1476a((C0557f) c0557f);
                    switch (c0562a.getState()) {
                        case Base64Encoder.NO_PADDING /*1*/:
                            c0557f.onServiceConnected(c0562a.getComponentName(), c0562a.getBinder());
                            break;
                        case Base64Encoder.URL_SAFE /*2*/:
                            c0562a.m1479w(this.qe.bindService(new Intent(str).setPackage(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE), c0562a.ee(), 129));
                            break;
                        default:
                            break;
                    }
                }
                throw new IllegalStateException("Trying to bind a GmsServiceConnection that was already connected before.  startServiceAction=" + str);
            }
            c0562a = new C0562a(this, str);
            c0562a.m1476a((C0557f) c0557f);
            c0562a.m1479w(this.qe.bindService(new Intent(str).setPackage(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE), c0562a.ee(), 129));
            this.BS.put(str, c0562a);
            isBound = c0562a.isBound();
        }
        return isBound;
    }

    public void m1483b(String str, C0557f c0557f) {
        synchronized (this.BS) {
            C0562a c0562a = (C0562a) this.BS.get(str);
            if (c0562a == null) {
                throw new IllegalStateException("Nonexistent connection status for service action: " + str);
            } else if (c0562a.m1478c(c0557f)) {
                c0562a.m1477b(c0557f);
                if (c0562a.eg()) {
                    this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(0, c0562a), 5000);
                }
            } else {
                throw new IllegalStateException("Trying to unbind a GmsServiceConnection  that was not bound before.  startServiceAction=" + str);
            }
        }
    }

    public boolean handleMessage(Message msg) {
        switch (msg.what) {
            case Base64Encoder.DEFAULT /*0*/:
                C0562a c0562a = (C0562a) msg.obj;
                synchronized (this.BS) {
                    if (c0562a.eg()) {
                        this.qe.unbindService(c0562a.ee());
                        this.BS.remove(c0562a.ef());
                    }
                    break;
                }
                return true;
            default:
                return false;
        }
    }
}
