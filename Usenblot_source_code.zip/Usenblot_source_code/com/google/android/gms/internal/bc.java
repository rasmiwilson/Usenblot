package com.google.android.gms.internal;

public final class bc {
    public final int mL;
    public final ax mM;
    public final bg mN;
    public final String mO;
    public final ba mP;

    /* renamed from: com.google.android.gms.internal.bc.a */
    public interface C0449a {
        void m999f(int i);
    }

    public bc(int i) {
        this(null, null, null, null, i);
    }

    public bc(ax axVar, bg bgVar, String str, ba baVar, int i) {
        this.mM = axVar;
        this.mN = bgVar;
        this.mO = str;
        this.mP = baVar;
        this.mL = i;
    }
}
