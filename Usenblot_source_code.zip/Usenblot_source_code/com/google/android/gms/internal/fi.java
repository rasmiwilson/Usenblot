package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;

public class fi implements Creator<fh> {
    static void m1637a(fh fhVar, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, fhVar.getVersionCode());
        C0265b.m488a(parcel, 2, fhVar.eF(), false);
        C0265b.m489a(parcel, 3, fhVar.eG(), i, false);
        C0265b.m481D(parcel, p);
    }

    public fh[] aa(int i) {
        return new fh[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m1638x(x0);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return aa(x0);
    }

    public fh m1638x(Parcel parcel) {
        fe feVar = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        Parcel parcel2 = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    parcel2 = C0264a.m478z(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    feVar = (fe) C0264a.m446a(parcel, n, fe.CREATOR);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new fh(i, parcel2, feVar);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }
}
