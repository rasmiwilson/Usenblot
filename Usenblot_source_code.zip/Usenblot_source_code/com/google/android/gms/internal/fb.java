package com.google.android.gms.internal;

import android.os.Parcel;
import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public abstract class fb {

    /* renamed from: com.google.android.gms.internal.fb.b */
    public interface C0571b<I, O> {
        int el();

        int em();

        I m1568g(O o);
    }

    /* renamed from: com.google.android.gms.internal.fb.a */
    public static class C0587a<I, O> implements SafeParcelable {
        public static final fc CREATOR;
        protected final Class<? extends fb> CA;
        protected final String CB;
        private fe CC;
        private C0571b<I, O> CD;
        protected final int Cu;
        protected final boolean Cv;
        protected final int Cw;
        protected final boolean Cx;
        protected final String Cy;
        protected final int Cz;
        private final int wj;

        static {
            CREATOR = new fc();
        }

        C0587a(int i, int i2, boolean z, int i3, boolean z2, String str, int i4, String str2, ew ewVar) {
            this.wj = i;
            this.Cu = i2;
            this.Cv = z;
            this.Cw = i3;
            this.Cx = z2;
            this.Cy = str;
            this.Cz = i4;
            if (str2 == null) {
                this.CA = null;
                this.CB = null;
            } else {
                this.CA = fh.class;
                this.CB = str2;
            }
            if (ewVar == null) {
                this.CD = null;
            } else {
                this.CD = ewVar.ej();
            }
        }

        protected C0587a(int i, boolean z, int i2, boolean z2, String str, int i3, Class<? extends fb> cls, C0571b<I, O> c0571b) {
            this.wj = 1;
            this.Cu = i;
            this.Cv = z;
            this.Cw = i2;
            this.Cx = z2;
            this.Cy = str;
            this.Cz = i3;
            this.CA = cls;
            if (cls == null) {
                this.CB = null;
            } else {
                this.CB = cls.getCanonicalName();
            }
            this.CD = c0571b;
        }

        public static C0587a m1593a(String str, int i, C0571b<?, ?> c0571b, boolean z) {
            return new C0587a(c0571b.el(), z, c0571b.em(), false, str, i, null, c0571b);
        }

        public static <T extends fb> C0587a<T, T> m1594a(String str, int i, Class<T> cls) {
            return new C0587a(11, false, 11, false, str, i, cls, null);
        }

        public static <T extends fb> C0587a<ArrayList<T>, ArrayList<T>> m1595b(String str, int i, Class<T> cls) {
            return new C0587a(11, true, 11, true, str, i, cls, null);
        }

        public static C0587a<Integer, Integer> m1597g(String str, int i) {
            return new C0587a(0, false, 0, false, str, i, null, null);
        }

        public static C0587a<Double, Double> m1598h(String str, int i) {
            return new C0587a(4, false, 4, false, str, i, null, null);
        }

        public static C0587a<Boolean, Boolean> m1599i(String str, int i) {
            return new C0587a(6, false, 6, false, str, i, null, null);
        }

        public static C0587a<String, String> m1600j(String str, int i) {
            return new C0587a(7, false, 7, false, str, i, null, null);
        }

        public static C0587a<ArrayList<String>, ArrayList<String>> m1601k(String str, int i) {
            return new C0587a(7, true, 7, true, str, i, null, null);
        }

        public void m1602a(fe feVar) {
            this.CC = feVar;
        }

        public int describeContents() {
            fc fcVar = CREATOR;
            return 0;
        }

        public int el() {
            return this.Cu;
        }

        public int em() {
            return this.Cw;
        }

        public C0587a<I, O> eq() {
            return new C0587a(this.wj, this.Cu, this.Cv, this.Cw, this.Cx, this.Cy, this.Cz, this.CB, ey());
        }

        public boolean er() {
            return this.Cv;
        }

        public boolean es() {
            return this.Cx;
        }

        public String et() {
            return this.Cy;
        }

        public int eu() {
            return this.Cz;
        }

        public Class<? extends fb> ev() {
            return this.CA;
        }

        String ew() {
            return this.CB == null ? null : this.CB;
        }

        public boolean ex() {
            return this.CD != null;
        }

        ew ey() {
            return this.CD == null ? null : ew.m1564a(this.CD);
        }

        public HashMap<String, C0587a<?, ?>> ez() {
            er.m1551f(this.CB);
            er.m1551f(this.CC);
            return this.CC.ao(this.CB);
        }

        public I m1603g(O o) {
            return this.CD.m1568g(o);
        }

        public int getVersionCode() {
            return this.wj;
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Field\n");
            stringBuilder.append("            versionCode=").append(this.wj).append('\n');
            stringBuilder.append("                 typeIn=").append(this.Cu).append('\n');
            stringBuilder.append("            typeInArray=").append(this.Cv).append('\n');
            stringBuilder.append("                typeOut=").append(this.Cw).append('\n');
            stringBuilder.append("           typeOutArray=").append(this.Cx).append('\n');
            stringBuilder.append("        outputFieldName=").append(this.Cy).append('\n');
            stringBuilder.append("      safeParcelFieldId=").append(this.Cz).append('\n');
            stringBuilder.append("       concreteTypeName=").append(ew()).append('\n');
            if (ev() != null) {
                stringBuilder.append("     concreteType.class=").append(ev().getCanonicalName()).append('\n');
            }
            stringBuilder.append("          converterName=").append(this.CD == null ? "null" : this.CD.getClass().getCanonicalName()).append('\n');
            return stringBuilder.toString();
        }

        public void writeToParcel(Parcel out, int flags) {
            fc fcVar = CREATOR;
            fc.m1609a(this, out, flags);
        }
    }

    private void m1604a(StringBuilder stringBuilder, C0587a c0587a, Object obj) {
        if (c0587a.el() == 11) {
            stringBuilder.append(((fb) c0587a.ev().cast(obj)).toString());
        } else if (c0587a.el() == 7) {
            stringBuilder.append("\"");
            stringBuilder.append(fp.ap((String) obj));
            stringBuilder.append("\"");
        } else {
            stringBuilder.append(obj);
        }
    }

    private void m1605a(StringBuilder stringBuilder, C0587a c0587a, ArrayList<Object> arrayList) {
        stringBuilder.append("[");
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (i > 0) {
                stringBuilder.append(",");
            }
            Object obj = arrayList.get(i);
            if (obj != null) {
                m1604a(stringBuilder, c0587a, obj);
            }
        }
        stringBuilder.append("]");
    }

    protected <O, I> I m1606a(C0587a<I, O> c0587a, Object obj) {
        return c0587a.CD != null ? c0587a.m1603g(obj) : obj;
    }

    protected boolean m1607a(C0587a c0587a) {
        return c0587a.em() == 11 ? c0587a.es() ? an(c0587a.et()) : am(c0587a.et()) : al(c0587a.et());
    }

    protected abstract Object ak(String str);

    protected abstract boolean al(String str);

    protected boolean am(String str) {
        throw new UnsupportedOperationException("Concrete types not supported");
    }

    protected boolean an(String str) {
        throw new UnsupportedOperationException("Concrete type arrays not supported");
    }

    protected Object m1608b(C0587a c0587a) {
        boolean z = true;
        String et = c0587a.et();
        if (c0587a.ev() == null) {
            return ak(c0587a.et());
        }
        if (ak(c0587a.et()) != null) {
            z = false;
        }
        er.m1547a(z, "Concrete field shouldn't be value object: " + c0587a.et());
        Map ep = c0587a.es() ? ep() : eo();
        if (ep != null) {
            return ep.get(et);
        }
        try {
            return getClass().getMethod("get" + Character.toUpperCase(et.charAt(0)) + et.substring(1), new Class[0]).invoke(this, new Object[0]);
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public abstract HashMap<String, C0587a<?, ?>> en();

    public HashMap<String, Object> eo() {
        return null;
    }

    public HashMap<String, Object> ep() {
        return null;
    }

    public String toString() {
        HashMap en = en();
        StringBuilder stringBuilder = new StringBuilder(100);
        for (String str : en.keySet()) {
            C0587a c0587a = (C0587a) en.get(str);
            if (m1607a(c0587a)) {
                Object a = m1606a(c0587a, m1608b(c0587a));
                if (stringBuilder.length() == 0) {
                    stringBuilder.append("{");
                } else {
                    stringBuilder.append(",");
                }
                stringBuilder.append("\"").append(str).append("\":");
                if (a != null) {
                    switch (c0587a.em()) {
                        case CodedOutputByteBufferNano.LITTLE_ENDIAN_64_SIZE /*8*/:
                            stringBuilder.append("\"").append(fk.m1646d((byte[]) a)).append("\"");
                            break;
                        case GamesStatusCodes.STATUS_GAME_NOT_FOUND /*9*/:
                            stringBuilder.append("\"").append(fk.m1647e((byte[]) a)).append("\"");
                            break;
                        case CommonStatusCodes.DEVELOPER_ERROR /*10*/:
                            fq.m1650a(stringBuilder, (HashMap) a);
                            break;
                        default:
                            if (!c0587a.er()) {
                                m1604a(stringBuilder, c0587a, a);
                                break;
                            }
                            m1605a(stringBuilder, c0587a, (ArrayList) a);
                            break;
                    }
                }
                stringBuilder.append("null");
            }
        }
        if (stringBuilder.length() > 0) {
            stringBuilder.append("}");
        } else {
            stringBuilder.append("{}");
        }
        return stringBuilder.toString();
    }
}
