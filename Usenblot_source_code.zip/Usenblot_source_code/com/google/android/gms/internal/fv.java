package com.google.android.gms.internal;

import com.google.android.gms.drive.metadata.MetadataField;
import com.google.android.gms.drive.metadata.internal.C0352a;
import com.google.android.gms.drive.metadata.internal.C0355d;

public class fv {
    public static final MetadataField<Integer> EJ;
    public static final MetadataField<Boolean> EK;

    static {
        EJ = new C0355d("contentAvailability", 4300000);
        EK = new C0352a("isPinnable", 4300000);
    }
}
