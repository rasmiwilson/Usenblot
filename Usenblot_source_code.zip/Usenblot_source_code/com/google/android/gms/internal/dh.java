package com.google.android.gms.internal;

import android.view.View;
import android.webkit.WebChromeClient.CustomViewCallback;

public final class dh extends df {
    public dh(dd ddVar) {
        super(ddVar);
    }

    public void onShowCustomView(View view, int requestedOrientation, CustomViewCallback customViewCallback) {
        m1298a(view, requestedOrientation, customViewCallback);
    }
}
